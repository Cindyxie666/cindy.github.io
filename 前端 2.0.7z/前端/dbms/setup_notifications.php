<?php
// 数据库连接信息 - 根据你的配置修改
$host = 'localhost';
$username = 'root';
$password = '';  // XAMPP默认密码为空
$database = 'course_management_system';

// 连接数据库
$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

echo "<h1>📧 创建 Notifications 表</h1>";

// 创建表
$sql = "CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    notification_content TEXT NOT NULL,
    notification_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read TINYINT(1) DEFAULT 0,
    student_id INT NOT NULL,
    instructor_id INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color:green; font-size:20px;'>✅ 表创建成功！</p>";
    
    // 检查是否有学生数据
    $checkStudents = $conn->query("SELECT student_id, name FROM students LIMIT 5");
    
    if ($checkStudents && $checkStudents->num_rows > 0) {
        // 为每个学生插入欢迎通知
        $insertStmt = $conn->prepare("INSERT INTO notifications (notification_content, notification_time, is_read, student_id) VALUES (?, NOW(), 0, ?)");
        
        $count = 0;
        while ($student = $checkStudents->fetch_assoc()) {
            $content = "Welcome to the Course Management System, " . $student['name'] . "! This is your notification center.";
            $insertStmt->bind_param("si", $content, $student['student_id']);
            if ($insertStmt->execute()) {
                $count++;
            }
        }
        $insertStmt->close();
        
        echo "<p style='color:blue;'>📬 已为 $count 名学生创建欢迎通知</p>";
    }
    
    // 显示表结构
    echo "<h3>表结构：</h3>";
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
    echo "<tr style='background:#f0f0f0;'><th>字段</th><th>类型</th><th>说明</th></tr>";
    
    $result = $conn->query("DESCRIBE notifications");
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td><strong>" . $row['Field'] . "</strong></td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>";
        switch($row['Field']) {
            case 'notification_id': echo '主键'; break;
            case 'notification_content': echo '通知内容'; break;
            case 'notification_time': echo '发送时间'; break;
            case 'is_read': echo '是否已读 (0=未读, 1=已读)'; break;
            case 'student_id': echo '学生ID'; break;
            case 'instructor_id': echo '教师ID'; break;
        }
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 显示数据
    $dataResult = $conn->query("SELECT * FROM notifications LIMIT 5");
    if ($dataResult && $dataResult->num_rows > 0) {
        echo "<h3>通知数据 (前5条)：</h3>";
        echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
        echo "<tr style='background:#e0f0ff;'><th>ID</th><th>内容</th><th>时间</th><th>已读</th><th>学生ID</th></tr>";
        while ($row = $dataResult->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['notification_id'] . "</td>";
            echo "<td>" . htmlspecialchars(substr($row['notification_content'], 0, 50)) . "...</td>";
            echo "<td>" . $row['notification_time'] . "</td>";
            echo "<td>" . ($row['is_read'] ? '是' : '否') . "</td>";
            echo "<td>" . $row['student_id'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<br><br>";
    echo "<a href='student_notifications.php' style='display:inline-block; padding:15px 30px; background:#4CAF50; color:white; text-decoration:none; border-radius:5px; font-size:18px;'>✅ 前往通知页面</a>";
    
} else {
    echo "<p style='color:red; font-size:20px;'>❌ 创建失败: " . $conn->error . "</p>";
}

$conn->close();
?>

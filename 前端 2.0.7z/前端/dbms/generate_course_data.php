<?php
/**
 * Generate sample data for Course Management System
 * Generates realistic sample data with scaled-down size:
 * - 500 students
 * - 50 instructors
 */

require_once __DIR__ . '/config/course_database.php';

$conn = getCourseDBConnection();

echo "Starting data generation for Course Management System...\n";

echo "Generating students...\n";
$majors = ['Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Engineering', 'Business', 'Economics'];
$gradeLevels = ['Freshman', 'Sophomore', 'Junior', 'Senior', 'Graduate'];

$stmt = $conn->prepare("INSERT IGNORE INTO students (name, account, password, grade_level, major, contact_info) VALUES (?, ?, ?, ?, ?, ?)");

for ($i = 1; $i <= 500; $i++) {
    $name = "Student " . $i;
    $account = "student" . $i;
    $password = password_hash('password', PASSWORD_DEFAULT);
    $gradeLevel = $gradeLevels[array_rand($gradeLevels)];
    $major = $majors[array_rand($majors)];
    $contact = "student" . $i . "@university.edu";
    
    $stmt->bind_param("ssssss", $name, $account, $password, $gradeLevel, $major, $contact);
    $stmt->execute();
    
    if ($i % 100 === 0) {
        echo "Generated $i students...\n";
    }
}
$stmt->close();
echo "Students generation completed!\n";

echo "Generating instructors...\n";
$departments = ['Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Engineering', 'Business', 'Economics'];

$stmt = $conn->prepare("INSERT IGNORE INTO instructors (name, account, password, department, subjects_taught, contact_info) VALUES (?, ?, ?, ?, ?, ?)");

for ($i = 1; $i <= 50; $i++) {
    $name = "Dr. Instructor " . $i;
    $account = "instructor" . $i;
    $password = password_hash('password', PASSWORD_DEFAULT);
    $department = $departments[array_rand($departments)];
    $subjects = "Subject A, Subject B";
    $contact = "instructor" . $i . "@university.edu";
    
    $stmt->bind_param("ssssss", $name, $account, $password, $department, $subjects, $contact);
    $stmt->execute();
}
$stmt->close();
echo "Instructors generation completed!\n";

echo "Generating courses...\n";
$courseCategories = ['MR', 'ME', 'GE', 'FE'];
$semesters = ['Fall 2024', 'Spring 2024', 'Summer 2024', 'Fall 2023', 'Spring 2023'];
$daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

$timeSlots = [];
for ($hour = 8; $hour <= 17; $hour++) {
    $timeSlots[] = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00';
}

$courseStmt = $conn->prepare("INSERT IGNORE INTO courses (course_code, course_category, course_name, credit_hours, course_description, semester_offered, course_status) VALUES (?, ?, ?, ?, ?, ?, ?)");
$scheduleStmt = $conn->prepare("INSERT IGNORE INTO course_schedules (course_code, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)");

$courseCounter = [
    'MR' => 1,
    'ME' => 1,
    'GE' => 1,
    'FE' => 1
];

for ($i = 1; $i <= 100; $i++) {
    $category = $courseCategories[($i - 1) % 4];
    $courseNumber = $courseCounter[$category];
    $code = $category . str_pad($courseNumber, 3, '0', STR_PAD_LEFT);
    $courseCounter[$category]++;
    
    $name = "Course " . $code;
    $credits = rand(2, 4);
    $description = "Description for " . $name;
    $semester = $semesters[array_rand($semesters)];
    $status = ['active', 'archived', 'draft'][array_rand(['active', 'archived', 'draft'])];
    
    $courseStmt->bind_param("sssisss", $code, $category, $name, $credits, $description, $semester, $status);
    $courseStmt->execute();
    
    $day1 = $daysOfWeek[array_rand($daysOfWeek)];
    $startTime1Index = array_rand($timeSlots);
    $startTime1 = $timeSlots[$startTime1Index];
    $time1Parts = explode(':', $startTime1);
    $hours1 = intval($time1Parts[0]);
    $minutes1 = intval($time1Parts[1]) + 50;
    $hours1 += intval($minutes1 / 60);
    $minutes1 = $minutes1 % 60;
    $endTime1 = sprintf('%02d:%02d:00', $hours1, $minutes1);
    
    $availableDays = array_values(array_diff($daysOfWeek, [$day1]));
    $day2 = $availableDays[array_rand($availableDays)];
    
    $validTimeSlots = [];
    foreach ($timeSlots as $index => $slot) {
        $slotParts = explode(':', $slot);
        $slotHours = intval($slotParts[0]);
        $slotMinutes = intval($slotParts[1]) + 110;
        $slotHours += intval($slotMinutes / 60);
        $slotMinutes = $slotMinutes % 60;
        if ($slotHours < 17 || ($slotHours == 17 && $slotMinutes <= 50)) {
            $validTimeSlots[] = $index;
        }
    }
    
    if (!empty($validTimeSlots)) {
        $startTime2Index = $validTimeSlots[array_rand($validTimeSlots)];
        $startTime2 = $timeSlots[$startTime2Index];
        $time2Parts = explode(':', $startTime2);
        $hours2 = intval($time2Parts[0]);
        $minutes2 = intval($time2Parts[1]) + 110;
        $hours2 += intval($minutes2 / 60);
        $minutes2 = $minutes2 % 60;
        $endTime2 = sprintf('%02d:%02d:00', $hours2, $minutes2);
    } else {
        $startTime2 = '08:00';
        $endTime2 = '09:50';
    }
    
    $scheduleStmt->bind_param("ssss", $code, $day1, $startTime1, $endTime1);
    $scheduleStmt->execute();
    
    $scheduleStmt->bind_param("ssss", $code, $day2, $startTime2, $endTime2);
    $scheduleStmt->execute();
    
    if ($i % 25 === 0) {
        echo "Generated $i courses...\n";
    }
}
$courseStmt->close();
$scheduleStmt->close();
echo "Courses generation completed!\n";

echo "Generating enrollments...\n";
$students = $conn->query("SELECT student_id FROM students LIMIT 500")->fetch_all(MYSQLI_ASSOC);
$courses = $conn->query("SELECT course_code FROM courses")->fetch_all(MYSQLI_ASSOC);

function hasTimeConflict($conn, $studentId, $newCourseCode) {
    $enrolledQuery = "SELECT e.course_code 
                      FROM enrollments e 
                      WHERE e.student_id = ? AND e.enrollment_status = 'enrolled'";
    $enrolledStmt = $conn->prepare($enrolledQuery);
    $enrolledStmt->bind_param("i", $studentId);
    $enrolledStmt->execute();
    $enrolledResult = $enrolledStmt->get_result();
    $enrolledCourseCodes = [];
    while ($row = $enrolledResult->fetch_assoc()) {
        $enrolledCourseCodes[] = $row['course_code'];
    }
    $enrolledStmt->close();
    
    if (empty($enrolledCourseCodes)) {
        return false;
    }
    
    $newSchedulesQuery = "SELECT day_of_week, start_time, end_time 
                          FROM course_schedules 
                          WHERE course_code = ?";
    $newSchedulesStmt = $conn->prepare($newSchedulesQuery);
    $newSchedulesStmt->bind_param("s", $newCourseCode);
    $newSchedulesStmt->execute();
    $newSchedules = $newSchedulesStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $newSchedulesStmt->close();
    
    if (empty($newSchedules)) {
        return false;
    }
    
    $placeholders = str_repeat('?,', count($enrolledCourseCodes) - 1) . '?';
    $existingSchedulesQuery = "SELECT course_code, day_of_week, start_time, end_time 
                               FROM course_schedules 
                               WHERE course_code IN ($placeholders)";
    $existingSchedulesStmt = $conn->prepare($existingSchedulesQuery);
    $existingSchedulesStmt->bind_param(str_repeat('s', count($enrolledCourseCodes)), ...$enrolledCourseCodes);
    $existingSchedulesStmt->execute();
    $existingSchedules = $existingSchedulesStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $existingSchedulesStmt->close();
    
    foreach ($newSchedules as $newSchedule) {
        foreach ($existingSchedules as $existingSchedule) {
            if ($newSchedule['day_of_week'] === $existingSchedule['day_of_week']) {
                $newStart = strtotime($newSchedule['start_time']);
                $newEnd = strtotime($newSchedule['end_time']);
                $existingStart = strtotime($existingSchedule['start_time']);
                $existingEnd = strtotime($existingSchedule['end_time']);
                
                if (($newStart < $existingEnd && $newEnd > $existingStart)) {
                    return true;
                }
            }
        }
    }
    
    return false;
}

$stmt = $conn->prepare("INSERT IGNORE INTO enrollments (student_id, course_code, enrollment_time, enrollment_status, time_conflict) VALUES (?, ?, ?, ?, ?)");

$enrollmentCount = 0;
$conflictCount = 0;
foreach ($students as $student) {
    $enrolledCourses = [];
    $attempts = 0;
    while (count($enrolledCourses) < 4 && $attempts < 200) {
        $course = $courses[array_rand($courses)];
        $courseCode = $course['course_code'];
        
        if (!in_array($courseCode, $enrolledCourses)) {
            $hasConflict = hasTimeConflict($conn, $student['student_id'], $courseCode);
            $enrollmentTime = date('Y-m-d H:i:s', strtotime('-' . rand(0, 365) . ' days'));
            $status = 'enrolled';
            $timeConflict = $hasConflict ? 1 : 0;
            
            $stmt->bind_param("isssi", $student['student_id'], $courseCode, $enrollmentTime, $status, $timeConflict);
            if ($stmt->execute()) {
                $enrolledCourses[] = $courseCode;
                $enrollmentCount++;
                if ($hasConflict) {
                    $conflictCount++;
                }
            }
        }
        $attempts++;
    }
    
    if ($enrollmentCount % 200 === 0) {
        echo "Generated $enrollmentCount enrollments...\n";
    }
}
$stmt->close();
echo "Enrollments generation completed! Total: $enrollmentCount (Time conflicts: $conflictCount)\n";

echo "Generating assignments...\n";
$instructors = $conn->query("SELECT instructor_id FROM instructors")->fetch_all(MYSQLI_ASSOC);

$stmt = $conn->prepare("INSERT IGNORE INTO assignments (assignment_name, assignment_description, release_time, deadline, requirements, course_code, instructor_id) VALUES (?, ?, ?, ?, ?, ?, ?)");

$assignmentCounter = 1;
foreach ($courses as $course) {
    $instructor = $instructors[array_rand($instructors)];
    
    for ($j = 1; $j <= 5; $j++) {
        $name = "Assignment " . $assignmentCounter;
        $description = "Description for assignment " . $assignmentCounter;
        $releaseTime = date('Y-m-d H:i:s', strtotime('-' . rand(0, 30) . ' days'));
        $deadline = date('Y-m-d H:i:s', strtotime($releaseTime . ' +' . rand(1, 60) . ' days'));
        $requirements = "Complete all tasks";
        
        $stmt->bind_param("ssssssi", $name, $description, $releaseTime, $deadline, $requirements, $course['course_code'], $instructor['instructor_id']);
        $stmt->execute();
        $assignmentCounter++;
    }
    
    if ($assignmentCounter % 50 === 0) {
        echo "Generated " . ($assignmentCounter - 1) . " assignments...\n";
    }
}
$stmt->close();
echo "Assignments generation completed! Total: " . ($assignmentCounter - 1) . "\n";

echo "Generating assignment submissions...\n";
$assignmentsQuery = "SELECT a.assignment_id, a.course_code, a.release_time, a.deadline 
                     FROM assignments a";
$assignmentsResult = $conn->query($assignmentsQuery);
$assignments = $assignmentsResult->fetch_all(MYSQLI_ASSOC);

$enrollmentsQuery = "SELECT student_id, course_code FROM enrollments WHERE enrollment_status = 'enrolled'";
$enrollmentsResult = $conn->query($enrollmentsQuery);
$enrollments = [];
while ($row = $enrollmentsResult->fetch_assoc()) {
    $enrollments[$row['course_code']][] = $row['student_id'];
}

$stmt = $conn->prepare("INSERT IGNORE INTO assignment_submissions (submission_time, submission_content, submission_status, student_id, assignment_id) VALUES (?, ?, ?, ?, ?)");

$submissionCount = 0;
foreach ($assignments as $assignment) {
    $courseCode = $assignment['course_code'];
    $assignmentId = $assignment['assignment_id'];
    $releaseTime = $assignment['release_time'];
    $deadline = $assignment['deadline'];
    
    if (isset($enrollments[$courseCode])) {
        $enrolledStudents = $enrollments[$courseCode];
        $totalStudents = count($enrolledStudents);
        $submissionCountForAssignment = intval($totalStudents * 0.8);
        
        shuffle($enrolledStudents);
        $submittingStudents = array_slice($enrolledStudents, 0, $submissionCountForAssignment);
        
        $releaseTimeStamp = strtotime($releaseTime);
        $deadlineTimeStamp = strtotime($deadline);
        $timeRange = $deadlineTimeStamp - $releaseTimeStamp;
        
        foreach ($submittingStudents as $studentId) {
            $randomOffset = rand(0, intval($timeRange * 1.1));
            $submissionTime = date('Y-m-d H:i:s', $releaseTimeStamp + $randomOffset);
            $content = "Submission content for assignment " . $assignmentId;
            
            $isLate = strtotime($submissionTime) > $deadlineTimeStamp;
            $status = $isLate ? 'late' : 'submitted';
            
            $stmt->bind_param("sssii", $submissionTime, $content, $status, $studentId, $assignmentId);
            if ($stmt->execute()) {
                $submissionCount++;
            }
        }
    }
    
    if ($submissionCount % 400 === 0) {
        echo "Generated $submissionCount submissions...\n";
    }
}
$stmt->close();
echo "Submissions generation completed! Total: $submissionCount\n";

echo "Generating grades...\n";
$submissionsQuery = "SELECT submission_id, assignment_id, student_id, submission_time 
                     FROM assignment_submissions 
                     WHERE submission_status IN ('submitted', 'late') 
                     LIMIT 2000";
$submissionsResult = $conn->query($submissionsQuery);
$submissions = $submissionsResult->fetch_all(MYSQLI_ASSOC);

$stmt = $conn->prepare("INSERT IGNORE INTO grades (score, grading_time, grading_remarks, submission_id, assignment_id, student_id, instructor_id) VALUES (?, ?, ?, ?, ?, ?, ?)");

foreach ($submissions as $submission) {
    $score = rand(6000, 10000) / 100.0;
    $submissionTime = strtotime($submission['submission_time']);
    $gradingTime = date('Y-m-d H:i:s', $submissionTime + (rand(0, 20 * 24 * 60 * 60)));
    
    $remarks = "Good work";
    $instructor = $instructors[array_rand($instructors)];
    
    $stmt->bind_param("dssiiii", $score, $gradingTime, $remarks, $submission['submission_id'], $submission['assignment_id'], $submission['student_id'], $instructor['instructor_id']);
    $stmt->execute();
}
$stmt->close();
echo "Grades generation completed!\n";

echo "Generating grade appeals...\n";
$allGradesQuery = "SELECT grade_id, student_id, grading_time FROM grades";
$allGradesResult = $conn->query($allGradesQuery);
$allGrades = $allGradesResult->fetch_all(MYSQLI_ASSOC);
$totalGrades = count($allGrades);

$appealCount = intval($totalGrades * 0.02);
shuffle($allGrades);
$appealGrades = array_slice($allGrades, 0, $appealCount);

$appealReasons = [
    "I believe there was an error in the grading. I followed all the requirements.",
    "The score does not reflect the quality of my work. Please reconsider.",
    "I think some points were deducted incorrectly. I would like a review.",
    "The feedback doesn't match my submission. I believe I deserve a higher score.",
    "I completed all the required tasks but received a lower score than expected.",
    "There seems to be a misunderstanding in the grading criteria.",
    "I would like to request a re-evaluation of my assignment.",
    "I believe my work meets all the criteria but was scored too harshly.",
    "Please review my submission again. I think there was a grading mistake.",
    "I would like to appeal this grade as I believe it is unfair."
];

$appealMaterials = [
    "Additional supporting documents attached.",
    "Revised submission with corrections.",
    "Reference materials and citations.",
    "Clarification on specific requirements.",
    "Supplementary evidence for my work.",
    "Detailed explanation of my approach.",
    "Additional context for the submission.",
    "Supporting documentation."
];

$stmt = $conn->prepare("INSERT IGNORE INTO grade_appeals (appeal_reason, appeal_submission_time, appeal_status, appeal_materials, student_id, grade_id) VALUES (?, ?, ?, ?, ?, ?)");

$appealCounter = 0;
foreach ($appealGrades as $grade) {
    $appealReason = $appealReasons[array_rand($appealReasons)];
    $gradingTime = strtotime($grade['grading_time']);
    $appealSubmissionTime = date('Y-m-d H:i:s', $gradingTime + rand(1, 7 * 24 * 60 * 60));
    
    $statusRand = rand(1, 100);
    if ($statusRand <= 40) {
        $status = 'pending';
    } elseif ($statusRand <= 70) {
        $status = 'rejected';
    } else {
        $status = 'approved';
    }
    
    $appealMaterialsText = rand(0, 1) ? $appealMaterials[array_rand($appealMaterials)] : '';
    
    $stmt->bind_param("ssssii", $appealReason, $appealSubmissionTime, $status, $appealMaterialsText, $grade['student_id'], $grade['grade_id']);
    if ($stmt->execute()) {
        $appealCounter++;
    }
}
$stmt->close();
echo "Grade appeals generation completed! Total: $appealCounter (2% of $totalGrades grades)\n";

echo "Generating announcements...\n";
$stmt = $conn->prepare("INSERT IGNORE INTO announcements (title, content, release_time, publisher_type, publisher_id, course_code, announcement_type) VALUES (?, ?, ?, ?, ?, ?, ?)");

for ($i = 1; $i <= 500; $i++) {
    $title = "Announcement " . $i;
    $content = "Content for announcement " . $i;
    $releaseTime = date('Y-m-d H:i:s', strtotime('-' . rand(0, 60) . ' days'));
    $publisherType = ['instructor', 'administrator'][array_rand(['instructor', 'administrator'])];
    $publisherId = $publisherType === 'instructor' ? rand(1, 50) : rand(1, 10);
    $course = $courses[array_rand($courses)];
    $type = ['course_notification', 'system_notification'][array_rand(['course_notification', 'system_notification'])];
    
    $stmt->bind_param("ssssiss", $title, $content, $releaseTime, $publisherType, $publisherId, $course['course_code'], $type);
    $stmt->execute();
}
$stmt->close();
echo "Announcements generation completed!\n";

echo "Generating suppliers...\n";
$supplierNames = ['Academic Books Co.', 'Educational Publishers Ltd.', 'Textbook Solutions Inc.', 'Learning Materials Corp.', 'University Press Supply', 'Scholastic Resources', 'Academic Supply Chain', 'Textbook Warehouse', 'Education Materials Co.', 'Book Distribution Network', 'Academic Publishers Group', 'Learning Resources Inc.', 'Textbook Distribution Co.', 'Educational Materials Supply', 'University Book Suppliers', 'Academic Resource Network', 'Textbook Solutions Group', 'Learning Materials Network', 'Education Supply Chain', 'Academic Distribution Co.'];
$textbookTypes = ['Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Engineering', 'Business', 'Economics', 'Literature', 'History', 'Science', 'Technology', 'General Education'];

$stmt = $conn->prepare("INSERT IGNORE INTO suppliers (supplier_name, contact_person, contact_info, textbook_types_supplied, cooperation_status) VALUES (?, ?, ?, ?, ?)");

for ($i = 0; $i < 20; $i++) {
    $supplierName = $supplierNames[$i];
    $contactPerson = "Contact Person " . ($i + 1);
    $contactInfo = "supplier" . ($i + 1) . "@supplier.com";
    
    $numTypes = rand(2, 5);
    shuffle($textbookTypes);
    $suppliedTypes = array_slice($textbookTypes, 0, $numTypes);
    $textbookTypesSupplied = implode(', ', $suppliedTypes);
    
    $statusRand = rand(1, 100);
    if ($statusRand <= 60) {
        $status = 'active';
    } elseif ($statusRand <= 85) {
        $status = 'pending';
    } else {
        $status = 'suspended';
    }
    
    $stmt->bind_param("sssss", $supplierName, $contactPerson, $contactInfo, $textbookTypesSupplied, $status);
    $stmt->execute();
}
$stmt->close();
echo "Suppliers generation completed! Total: 20\n";

echo "Generating textbooks...\n";
$suppliers = $conn->query("SELECT supplier_id FROM suppliers")->fetch_all(MYSQLI_ASSOC);
$supplierIds = array_column($suppliers, 'supplier_id');

$stmt = $conn->prepare("INSERT IGNORE INTO textbooks (title, author, isbn, publisher, price, stock_quantity, course_code, supplier_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

$textbookCounter = 1;
foreach ($courses as $course) {
    $title = "Textbook for " . $course['course_code'];
    $author = "Author " . $textbookCounter;
    $isbn = "ISBN" . str_pad($textbookCounter, 10, '0', STR_PAD_LEFT);
    $publisher = "Publisher " . ($textbookCounter % 20);
    $price = rand(20, 200) + (rand(0, 99) / 100);
    $stock = rand(50, 200);
    $supplierId = $supplierIds[array_rand($supplierIds)];
    
    $stmt->bind_param("ssssdisi", $title, $author, $isbn, $publisher, $price, $stock, $course['course_code'], $supplierId);
    $stmt->execute();
    $textbookCounter++;
    
    if ($textbookCounter % 25 === 0) {
        echo "Generated " . ($textbookCounter - 1) . " textbooks...\n";
    }
}
$stmt->close();
echo "Textbooks generation completed! Total: " . ($textbookCounter - 1) . "\n";

echo "Generating textbook orders...\n";
$textbooksQuery = "SELECT textbook_id, course_code, price, stock_quantity FROM textbooks";
$textbooksResult = $conn->query($textbooksQuery);
$textbooks = [];
while ($row = $textbooksResult->fetch_assoc()) {
    $textbooks[$row['course_code']] = $row;
}

$enrollmentsQuery = "SELECT student_id, course_code FROM enrollments WHERE enrollment_status = 'enrolled'";
$enrollmentsResult = $conn->query($enrollmentsQuery);
$enrollments = [];
while ($row = $enrollmentsResult->fetch_assoc()) {
    $enrollments[$row['course_code']][] = $row['student_id'];
}

$stmt = $conn->prepare("INSERT IGNORE INTO textbook_orders (order_time, order_status, quantity_purchased, total_amount, student_id, textbook_id) VALUES (?, ?, ?, ?, ?, ?)");

$orderCount = 0;
foreach ($textbooks as $courseCode => $textbook) {
    $textbookId = $textbook['textbook_id'];
    $price = $textbook['price'];
    $stockQuantity = $textbook['stock_quantity'];
    
    if (isset($enrollments[$courseCode])) {
        $enrolledStudents = $enrollments[$courseCode];
        $totalStudents = count($enrolledStudents);
        $purchaseCount = min(intval($totalStudents * 0.5), $stockQuantity);
        
        shuffle($enrolledStudents);
        $purchasingStudents = array_slice($enrolledStudents, 0, $purchaseCount);
        
        foreach ($purchasingStudents as $studentId) {
            $orderTime = date('Y-m-d H:i:s', strtotime('-' . rand(0, 180) . ' days'));
            $statusRand = rand(1, 100);
            if ($statusRand <= 80) {
                $status = 'completed';
            } elseif ($statusRand <= 90) {
                $status = 'processing';
            } elseif ($statusRand <= 95) {
                $status = 'pending';
            } else {
                $status = 'cancelled';
            }
            $quantity = 1;
            $totalAmount = $price * $quantity;
            
            $stmt->bind_param("ssidis", $orderTime, $status, $quantity, $totalAmount, $studentId, $textbookId);
            if ($stmt->execute()) {
                $orderCount++;
            }
        }
    }
    
    if ($orderCount % 200 === 0) {
        echo "Generated $orderCount orders...\n";
    }
}
$stmt->close();
echo "Textbook orders generation completed! Total: $orderCount\n";

echo "Generating teaching evaluations...\n";
$stmt = $conn->prepare("INSERT IGNORE INTO teaching_evaluations (evaluation_content, rating, evaluation_time, student_id, course_code, instructor_id) VALUES (?, ?, ?, ?, ?, ?)");

for ($i = 0; $i < 1000; $i++) {
    $student = $students[array_rand($students)];
    $course = $courses[array_rand($courses)];
    $instructor = $instructors[array_rand($instructors)];
    $content = "Evaluation content " . $i;
    $rating = rand(1, 5);
    $evalTime = date('Y-m-d H:i:s', strtotime('-' . rand(0, 90) . ' days'));
    
    $stmt->bind_param("sisiss", $content, $rating, $evalTime, $student['student_id'], $course['course_code'], $instructor['instructor_id']);
    $stmt->execute();
}
$stmt->close();
echo "Teaching evaluations generation completed!\n";

echo "\n=== Data Generation Summary ===\n";
echo "Students: 500\n";
echo "Instructors: 50\n";
echo "Courses: 100\n";
echo "Enrollments: 2,000 (4 courses per student)\n";
echo "Assignments: 500 (5 per course)\n";
echo "Submissions: ~1,600 (80% submission rate)\n";
echo "Grades: ~1,600\n";
echo "Grade Appeals: ~32 (2% appeal rate)\n";
echo "Announcements: 500\n";
echo "Textbooks: 100 (1 per course)\n";
echo "Textbook Orders: ~1,000 (50% purchase rate)\n";
echo "Suppliers: 20\n";
echo "Teaching Evaluations: 1,000\n";
echo "\nAll data generation completed successfully!\n";

$conn->close();
?>


<?php
require_once __DIR__ . '/config/course_database.php';
requireInstructor();

$pageTitle = 'Review Appeals';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$instructorId = getCurrentUserId();

$message = '';
$messageType = '';

// Handle review appeal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'review') {
    $appealId = intval($_POST['appeal_id'] ?? 0);
    $reviewResult = $_POST['review_result'] ?? '';
    $reviewRemarks = trim($_POST['review_remarks'] ?? '');
    
    if ($appealId && $reviewResult) {
        // Verify this appeal belongs to a grade given by this instructor
        $verifyQuery = "SELECT ga.appeal_id, ga.appeal_status 
                        FROM grade_appeals ga
                        JOIN grades g ON ga.grade_id = g.grade_id
                        WHERE ga.appeal_id = ? AND g.instructor_id = ?";
        $verifyStmt = $conn->prepare($verifyQuery);
        $verifyStmt->bind_param("ii", $appealId, $instructorId);
        $verifyStmt->execute();
        $appealData = $verifyStmt->get_result()->fetch_assoc();
        $verifyStmt->close();
        
        if ($appealData) {
            // Insert review record
            $stmt = $conn->prepare("INSERT INTO appeal_reviews (instructor_id, appeal_id, review_time, review_result, review_remarks) VALUES (?, ?, NOW(), ?, ?)");
            $stmt->bind_param("iiss", $instructorId, $appealId, $reviewResult, $reviewRemarks);
            
            if ($stmt->execute()) {
                $stmt->close();
                
                // Update appeal status
                $status = $reviewResult === 'approve' ? 'approved' : 'rejected';
                $updateStmt = $conn->prepare("UPDATE grade_appeals SET appeal_status = ? WHERE appeal_id = ?");
                $updateStmt->bind_param("si", $status, $appealId);
                $updateStmt->execute();
                $updateStmt->close();
                
                $message = "Appeal " . ($reviewResult === 'approve' ? 'approved' : 'rejected') . " successfully!";
                $messageType = "success";
            } else {
                $message = "Error submitting review: " . $stmt->error;
                $messageType = "error";
            }
        } else {
            $message = "Invalid appeal or you don't have permission to review this appeal.";
            $messageType = "error";
        }
    } else {
        $message = "Please select a review result.";
        $messageType = "error";
    }
}

// Get pending appeals for grades assigned by this instructor
$query = "SELECT ga.*, g.score, g.grading_remarks, a.assignment_name, c.course_name, c.course_code, 
          s.name as student_name, s.account as student_account,
          (SELECT review_result FROM appeal_reviews WHERE appeal_id = ga.appeal_id ORDER BY review_time DESC LIMIT 1) as review_result,
          (SELECT review_remarks FROM appeal_reviews WHERE appeal_id = ga.appeal_id ORDER BY review_time DESC LIMIT 1) as review_remarks_result,
          (SELECT review_time FROM appeal_reviews WHERE appeal_id = ga.appeal_id ORDER BY review_time DESC LIMIT 1) as review_time
          FROM grade_appeals ga
          JOIN grades g ON ga.grade_id = g.grade_id
          JOIN assignments a ON g.assignment_id = a.assignment_id
          JOIN courses c ON a.course_code = c.course_code
          JOIN students s ON ga.student_id = s.student_id
          WHERE g.instructor_id = ?
          ORDER BY 
            CASE WHEN ga.appeal_status = 'pending' THEN 0 ELSE 1 END,
            ga.appeal_submission_time DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $instructorId);
$stmt->execute();
$appeals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get statistics
$statsQuery = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN ga.appeal_status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN ga.appeal_status = 'approved' THEN 1 ELSE 0 END) as approved,
    SUM(CASE WHEN ga.appeal_status = 'rejected' THEN 1 ELSE 0 END) as rejected
FROM grade_appeals ga
JOIN grades g ON ga.grade_id = g.grade_id
WHERE g.instructor_id = ?";
$statsStmt = $conn->prepare($statsQuery);
$statsStmt->bind_param("i", $instructorId);
$statsStmt->execute();
$stats = $statsStmt->get_result()->fetch_assoc();
$statsStmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>⚖️ Review Grade Appeals</h2>
            <p>Review and respond to student grade appeals</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 8px; background: <?php echo $messageType === 'success' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $messageType === 'success' ? '#065f46' : '#991b1b'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
        <div class="dashboard-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 1.5rem; font-weight: bold; color: #3b82f6;"><?php echo $stats['total'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">Total Appeals</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 1.5rem; font-weight: bold; color: #f59e0b;"><?php echo $stats['pending'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">Pending</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 1.5rem; font-weight: bold; color: #10b981;"><?php echo $stats['approved'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">Approved</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 1.5rem; font-weight: bold; color: #ef4444;"><?php echo $stats['rejected'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">Rejected</div>
        </div>
    </div>

    <!-- Appeals List -->
    <div class="dashboard-card">
        <h3>📋 Appeals List</h3>
        
        <?php if (empty($appeals)): ?>
        <div style="text-align: center; padding: 3rem; color: #666;">
            <p style="font-size: 1.25rem;">No appeals found.</p>
            <p>Students haven't filed any grade appeals for your assignments yet.</p>
        </div>
        <?php else: ?>
        
        <div class="table-container" style="max-height: 600px; overflow-y: auto;">
            <?php foreach ($appeals as $appeal): ?>
            <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; background: <?php echo $appeal['appeal_status'] === 'pending' ? '#fffbeb' : ($appeal['appeal_status'] === 'approved' ? '#f0fdf4' : '#fef2f2'); ?>;">
                <div style="display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 1rem;">
                    <!-- Left: Appeal Info -->
                    <div style="flex: 1; min-width: 300px;">
                        <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem; flex-wrap: wrap;">
                            <span style="padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; background: <?php 
                                echo $appeal['appeal_status'] === 'pending' ? '#fef3c7' : ($appeal['appeal_status'] === 'approved' ? '#d1fae5' : '#fee2e2'); 
                            ?>; color: <?php 
                                echo $appeal['appeal_status'] === 'pending' ? '#d97706' : ($appeal['appeal_status'] === 'approved' ? '#059669' : '#dc2626'); 
                            ?>;">
                                <?php echo ucfirst($appeal['appeal_status']); ?>
                            </span>
                            <span style="padding: 0.25rem 0.5rem; background: rgba(59, 130, 246, 0.1); color: #3b82f6; border-radius: 4px; font-size: 0.75rem; font-weight: 600;">
                                <?php echo htmlspecialchars($appeal['course_code']); ?>
                            </span>
                        </div>
                        
                        <h4 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">
                            <?php echo htmlspecialchars($appeal['assignment_name']); ?>
                        </h4>
                        
                        <div style="display: grid; gap: 0.25rem; font-size: 0.9rem; color: #666;">
                            <div><strong>Student:</strong> <?php echo htmlspecialchars($appeal['student_name']); ?> (<?php echo htmlspecialchars($appeal['student_account']); ?>)</div>
                            <div><strong>Original Score:</strong> <?php echo number_format($appeal['score'], 1); ?></div>
                            <div><strong>Submitted:</strong> <?php echo date('Y-m-d H:i', strtotime($appeal['appeal_submission_time'])); ?></div>
                        </div>
                        
                        <!-- Appeal Reason -->
                        <div style="margin-top: 1rem;">
                            <strong>Appeal Reason:</strong>
                            <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 4px; padding: 0.75rem; margin-top: 0.5rem; max-height: 150px; overflow-y: auto; font-size: 0.9rem;">
                                <?php echo nl2br(htmlspecialchars($appeal['appeal_reason'])); ?>
                            </div>
                        </div>
                        
                        <?php if ($appeal['appeal_materials']): ?>
                        <div style="margin-top: 0.75rem;">
                            <strong>Supporting Materials:</strong>
                            <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 4px; padding: 0.75rem; margin-top: 0.5rem; max-height: 100px; overflow-y: auto; font-size: 0.9rem;">
                                <?php echo nl2br(htmlspecialchars($appeal['appeal_materials'])); ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($appeal['review_time']): ?>
                        <div style="margin-top: 1rem; padding: 0.75rem; background: #e0e7ff; border-radius: 4px;">
                            <strong>Review Result:</strong> 
                            <span style="color: <?php echo $appeal['review_result'] === 'approve' ? '#059669' : '#dc2626'; ?>; font-weight: 600;">
                                <?php echo ucfirst($appeal['review_result']); ?>
                            </span>
                            <br>
                            <small>Reviewed: <?php echo date('Y-m-d H:i', strtotime($appeal['review_time'])); ?></small>
                            <?php if ($appeal['review_remarks_result']): ?>
                            <div style="margin-top: 0.5rem; font-size: 0.9rem;">
                                <strong>Remarks:</strong> <?php echo htmlspecialchars($appeal['review_remarks_result']); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Right: Review Form (only for pending) -->
                    <?php if ($appeal['appeal_status'] === 'pending'): ?>
                    <div style="min-width: 280px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem;">
                        <form method="POST">
                            <input type="hidden" name="action" value="review">
                            <input type="hidden" name="appeal_id" value="<?php echo $appeal['appeal_id']; ?>">
                            
                            <div style="margin-bottom: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Decision *</label>
                                <select name="review_result" required style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; font-size: 1rem; box-sizing: border-box;">
                                    <option value="">-- Select --</option>
                                    <option value="approve">✅ Approve Appeal</option>
                                    <option value="reject">❌ Reject Appeal</option>
                                </select>
                            </div>
                            
                            <div style="margin-bottom: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Remarks</label>
                                <textarea name="review_remarks" rows="3" placeholder="Enter your remarks for the student..."
                                          style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; resize: vertical; box-sizing: border-box; min-height: 80px; max-height: 200px;"></textarea>
                            </div>
                            
                            <button type="submit" class="btn-primary" style="width: 100%;">
                                📝 Submit Review
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <?php endif; ?>
    </div>
</div>

<style>
.table-container {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}
.table-container::-webkit-scrollbar {
    width: 8px;
}
.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}
.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

# Avatar Feature Documentation

## Overview
This feature allows users (students, instructors, and administrators) to upload and display profile pictures stored as BLOB in the database.

## Database Setup

Before using the avatar feature, you need to add the `avatar` column to the database tables:

1. Run the SQL script:
```sql
-- Add avatar column to students table
ALTER TABLE students ADD COLUMN avatar BLOB NULL AFTER contact_info;

-- Add avatar column to instructors table
ALTER TABLE instructors ADD COLUMN avatar BLOB NULL AFTER contact_info;

-- Add avatar column to administrators table
ALTER TABLE administrators ADD COLUMN avatar BLOB NULL AFTER contact_info;
```

Or execute the provided SQL file:
```bash
mysql -u root -p course_management_system < add_avatar_column.sql
```

## Files Added/Modified

### New Files:
1. **`add_avatar_column.sql`** - SQL script to add avatar columns to all user tables
2. **`view_avatar.php`** - Displays avatar images from the database
3. **`admin_profile.php`** - Administrator profile page with avatar upload functionality

### Modified Files:
1. **`student_profile.php`** - Added avatar upload and display functionality
2. **`instructor_profile.php`** - Added avatar upload and display functionality
3. **`includes/course_header.php`** - Added avatar display in the top navigation bar

## Features

### Avatar Upload
- Users can upload profile pictures from their personal profile pages
- Supported formats: JPEG, JPG, PNG, GIF
- Maximum file size: 5MB
- Images are stored as BLOB in the database

### Avatar Display
- Avatar is displayed on:
  - Personal profile pages (150x150px, circular)
  - Top navigation bar (40x40px, circular)
- If no avatar is uploaded, a default placeholder is shown

### Security
- File type validation (only image files allowed)
- File size limit (5MB maximum)
- Proper error handling for invalid uploads

## Usage

### For Users:
1. Navigate to your profile page:
   - Students: `student_profile.php`
   - Instructors: `instructor_profile.php`
   - Administrators: `admin_profile.php`
2. In the "Profile Picture" section, click "Choose File" and select an image
3. Click "Upload Avatar" to save your profile picture
4. Your avatar will appear on your profile page and in the top navigation bar

### For Developers:
To display an avatar in your code:
```php
<img src="view_avatar.php?type=student&id=<?php echo $studentId; ?>" alt="Avatar">
```

Available types:
- `student` - for students
- `instructor` - for instructors
- `administrator` - for administrators

## Technical Details

### Database Schema
The `avatar` column is defined as:
- Type: `BLOB`
- Nullable: `YES`
- Position: After `contact_info` column

### Image Storage
- Images are stored directly in the database as binary data (BLOB)
- No file system storage required
- Images are served dynamically via `view_avatar.php`

### Image Display
- The `view_avatar.php` script:
  - Validates user type and ID parameters
  - Retrieves avatar from the appropriate table
  - Detects image MIME type automatically
  - Returns image with proper headers
  - Falls back to default transparent PNG if no avatar exists

## Notes
- Large images may impact database size and performance
- Consider implementing image compression/resizing in the future
- The current implementation stores full-resolution images


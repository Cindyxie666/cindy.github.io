<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Course Evaluations';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

$message = '';
$messageType = '';

// Handle evaluation submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_evaluation') {
    $courseCode = $_POST['course_code'] ?? '';
    $instructorId = intval($_POST['instructor_id'] ?? 0);
    $rating = intval($_POST['rating'] ?? 0);
    $evaluationContent = trim($_POST['evaluation_content'] ?? '');
    
    if (empty($courseCode) || !$instructorId || $rating < 1 || $rating > 5) {
        $message = "Please fill in all required fields and select a valid rating (1-5).";
        $messageType = "error";
    } elseif (empty($evaluationContent)) {
        $message = "Please provide your evaluation comments.";
        $messageType = "error";
    } else {
        // Check if already evaluated
        $checkStmt = $conn->prepare("SELECT evaluation_id FROM teaching_evaluations WHERE student_id = ? AND course_code = ? AND instructor_id = ?");
        $checkStmt->bind_param("isi", $studentId, $courseCode, $instructorId);
        $checkStmt->execute();
        $existing = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
        
        if ($existing) {
            // Update existing evaluation
            $stmt = $conn->prepare("UPDATE teaching_evaluations SET evaluation_content = ?, rating = ?, evaluation_time = NOW() WHERE evaluation_id = ?");
            $stmt->bind_param("sii", $evaluationContent, $rating, $existing['evaluation_id']);
            if ($stmt->execute()) {
                $message = "Evaluation updated successfully!";
                $messageType = "success";
            } else {
                $message = "Error updating evaluation: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        } else {
            // Insert new evaluation
            $stmt = $conn->prepare("INSERT INTO teaching_evaluations (evaluation_content, rating, evaluation_time, student_id, course_code, instructor_id) VALUES (?, ?, NOW(), ?, ?, ?)");
            $stmt->bind_param("siisi", $evaluationContent, $rating, $studentId, $courseCode, $instructorId);
            if ($stmt->execute()) {
                $message = "Evaluation submitted successfully! Thank you for your feedback.";
                $messageType = "success";
            } else {
                $message = "Error submitting evaluation: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    }
}

// Get enrolled courses with instructors
$query = "SELECT DISTINCT c.course_code, c.course_name, c.course_category, 
                 i.instructor_id, i.name as instructor_name, i.department,
                 e.enrollment_time,
                 (SELECT te.evaluation_id FROM teaching_evaluations te 
                  WHERE te.student_id = ? AND te.course_code = c.course_code AND te.instructor_id = i.instructor_id) as existing_evaluation_id,
                 (SELECT te.rating FROM teaching_evaluations te 
                  WHERE te.student_id = ? AND te.course_code = c.course_code AND te.instructor_id = i.instructor_id) as existing_rating,
                 (SELECT te.evaluation_content FROM teaching_evaluations te 
                  WHERE te.student_id = ? AND te.course_code = c.course_code AND te.instructor_id = i.instructor_id) as existing_content
          FROM courses c
          JOIN enrollments e ON c.course_code = e.course_code
          JOIN teaching t ON c.course_code = t.course_code
          JOIN instructors i ON t.instructor_id = i.instructor_id
          WHERE e.student_id = ? AND e.enrollment_status = 'enrolled' AND c.course_status = 'active'
          ORDER BY c.course_code, i.name";

$stmt = $conn->prepare($query);
$stmt->bind_param("iiii", $studentId, $studentId, $studentId, $studentId);
$stmt->execute();
$courses = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get statistics
$statsQuery = "SELECT 
    COUNT(DISTINCT CONCAT(e.course_code, '-', t.instructor_id)) as total_to_evaluate,
    COUNT(DISTINCT te.evaluation_id) as evaluated
FROM enrollments e
JOIN courses c ON e.course_code = c.course_code
JOIN teaching t ON c.course_code = t.course_code
LEFT JOIN teaching_evaluations te ON te.student_id = e.student_id AND te.course_code = e.course_code AND te.instructor_id = t.instructor_id
WHERE e.student_id = ? AND e.enrollment_status = 'enrolled' AND c.course_status = 'active'";

$statsStmt = $conn->prepare($statsQuery);
$statsStmt->bind_param("i", $studentId);
$statsStmt->execute();
$stats = $statsStmt->get_result()->fetch_assoc();
$statsStmt->close();

$conn->close();

$totalToEvaluate = intval($stats['total_to_evaluate'] ?? 0);
$evaluated = intval($stats['evaluated'] ?? 0);
$pending = $totalToEvaluate - $evaluated;
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>⭐ Course Evaluations</h2>
            <p>Rate and review your courses and instructors</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 8px; background: <?php echo $messageType === 'success' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $messageType === 'success' ? '#065f46' : '#991b1b'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
        <div class="dashboard-card" style="text-align: center; padding: 1.5rem;">
            <div style="font-size: 2rem; font-weight: bold; color: #3b82f6;"><?php echo $totalToEvaluate; ?></div>
            <div style="color: #666;">Total Courses</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1.5rem;">
            <div style="font-size: 2rem; font-weight: bold; color: #10b981;"><?php echo $evaluated; ?></div>
            <div style="color: #666;">Evaluated</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1.5rem;">
            <div style="font-size: 2rem; font-weight: bold; color: #f59e0b;"><?php echo $pending; ?></div>
            <div style="color: #666;">Pending</div>
        </div>
    </div>

    <!-- Courses to Evaluate -->
    <div class="dashboard-card">
        <h3>📋 My Courses</h3>
        
        <?php if (empty($courses)): ?>
        <div style="text-align: center; padding: 3rem; color: #666;">
            <p style="font-size: 3rem; margin-bottom: 1rem;">📚</p>
            <p style="font-size: 1.25rem;">No courses to evaluate.</p>
            <p>You need to be enrolled in active courses to submit evaluations.</p>
        </div>
        <?php else: ?>
        
        <div class="table-container" style="max-height: 700px; overflow-y: auto;">
            <?php foreach ($courses as $course): ?>
            <div class="evaluation-card" style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; background: <?php echo $course['existing_evaluation_id'] ? '#f0fdf4' : '#fffbeb'; ?>; border-left: 4px solid <?php echo $course['existing_evaluation_id'] ? '#10b981' : '#f59e0b'; ?>;">
                <div style="display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 1.5rem;">
                    <!-- Left: Course Info -->
                    <div style="flex: 1; min-width: 280px;">
                        <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem; flex-wrap: wrap;">
                            <span style="padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; background: <?php echo $course['existing_evaluation_id'] ? '#d1fae5' : '#fef3c7'; ?>; color: <?php echo $course['existing_evaluation_id'] ? '#059669' : '#d97706'; ?>;">
                                <?php echo $course['existing_evaluation_id'] ? '✅ Evaluated' : '⏳ Pending'; ?>
                            </span>
                            <span style="padding: 0.25rem 0.5rem; background: rgba(59, 130, 246, 0.1); color: #3b82f6; border-radius: 4px; font-size: 0.75rem; font-weight: 600;">
                                <?php echo htmlspecialchars($course['course_code']); ?>
                            </span>
                            <?php if ($course['course_category']): ?>
                            <span style="padding: 0.25rem 0.5rem; background: rgba(139, 92, 246, 0.1); color: #8b5cf6; border-radius: 4px; font-size: 0.75rem; font-weight: 600;">
                                <?php echo htmlspecialchars($course['course_category']); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <h4 style="margin: 0 0 0.75rem 0; font-size: 1.1rem; color: #1f2937;">
                            📚 <?php echo htmlspecialchars($course['course_name']); ?>
                        </h4>
                        
                        <div style="display: grid; gap: 0.5rem; font-size: 0.9rem; color: #4b5563;">
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <span>👨‍🏫</span>
                                <strong>Instructor:</strong> 
                                <?php echo htmlspecialchars($course['instructor_name']); ?>
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <span>🏢</span>
                                <strong>Department:</strong> 
                                <?php echo htmlspecialchars($course['department'] ?? 'N/A'); ?>
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <span>📅</span>
                                <strong>Enrolled:</strong> 
                                <?php echo date('Y-m-d', strtotime($course['enrollment_time'])); ?>
                            </div>
                        </div>
                        
                        <?php if ($course['existing_evaluation_id'] && $course['existing_rating']): ?>
                        <div style="margin-top: 1rem; padding: 0.75rem; background: #e0f2fe; border-radius: 6px;">
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <strong>Your Rating:</strong>
                                <span style="color: #f59e0b; font-size: 1.1rem;">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php echo $i <= $course['existing_rating'] ? '★' : '☆'; ?>
                                    <?php endfor; ?>
                                </span>
                                <span style="color: #666;">(<?php echo $course['existing_rating']; ?>/5)</span>
                            </div>
                            <?php if ($course['existing_content']): ?>
                            <div style="font-size: 0.9rem; color: #4b5563;">
                                <strong>Your Comments:</strong>
                                <div style="margin-top: 0.25rem; max-height: 80px; overflow-y: auto;">
                                    <?php echo nl2br(htmlspecialchars($course['existing_content'])); ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Right: Evaluation Form -->
                    <div style="min-width: 320px; max-width: 400px; background: white; border: 2px solid #e5e7eb; border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
                        <h4 style="margin: 0 0 1rem 0; padding-bottom: 0.75rem; border-bottom: 2px solid #e5e7eb; color: #1f2937;">
                            <?php echo $course['existing_evaluation_id'] ? '✏️ Update Evaluation' : '⭐ Submit Evaluation'; ?>
                        </h4>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="submit_evaluation">
                            <input type="hidden" name="course_code" value="<?php echo htmlspecialchars($course['course_code']); ?>">
                            <input type="hidden" name="instructor_id" value="<?php echo $course['instructor_id']; ?>">
                            
                            <!-- Rating -->
                            <div style="margin-bottom: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #374151;">
                                    Rating <span style="color: #ef4444;">*</span>
                                </label>
                                <div class="star-rating" style="display: flex; gap: 0.25rem; font-size: 1.75rem;">
                                    <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" name="rating" value="<?php echo $i; ?>" id="star<?php echo $course['course_code'] . $course['instructor_id'] . $i; ?>" 
                                           <?php echo ($course['existing_rating'] == $i) ? 'checked' : ''; ?> required
                                           style="display: none;">
                                    <label for="star<?php echo $course['course_code'] . $course['instructor_id'] . $i; ?>" 
                                           style="cursor: pointer; color: #d1d5db; transition: color 0.2s;"
                                           onmouseover="highlightStars(this, <?php echo $i; ?>)" 
                                           onmouseout="resetStars(this)"
                                           onclick="selectStar(this, <?php echo $i; ?>)">★</label>
                                    <?php endfor; ?>
                                </div>
                                <small style="color: #9ca3af;">Click to rate (1-5 stars)</small>
                            </div>
                            
                            <!-- Comments -->
                            <div style="margin-bottom: 1.5rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #374151;">
                                    Your Comments <span style="color: #ef4444;">*</span>
                                </label>
                                <textarea name="evaluation_content" rows="4" required
                                          placeholder="Share your experience with this course and instructor..."
                                          style="width: 100%; padding: 0.75rem; border: 2px solid #e5e7eb; border-radius: 8px; resize: vertical; box-sizing: border-box; min-height: 100px; max-height: 200px; font-size: 0.9rem;"><?php echo htmlspecialchars($course['existing_content'] ?? ''); ?></textarea>
                            </div>
                            
                            <!-- Submit Button -->
                            <button type="submit" class="btn-primary" style="width: 100%; padding: 0.875rem; font-size: 1rem; font-weight: 600; border-radius: 8px;">
                                <?php echo $course['existing_evaluation_id'] ? '📝 Update Evaluation' : '📤 Submit Evaluation'; ?>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <?php endif; ?>
    </div>
</div>

<style>
.table-container {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}

.table-container::-webkit-scrollbar {
    width: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}

.evaluation-card {
    transition: transform 0.2s, box-shadow 0.2s;
}

.evaluation-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.star-rating {
    flex-direction: row-reverse;
    justify-content: flex-end;
}

.star-rating label:hover,
.star-rating label:hover ~ label,
.star-rating input:checked ~ label {
    color: #f59e0b !important;
}

textarea:focus, input:focus {
    outline: none;
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}

@media (max-width: 768px) {
    .evaluation-card > div {
        flex-direction: column;
    }
    
    .evaluation-card > div > div:last-child {
        max-width: 100%;
        min-width: 100%;
    }
}
</style>

<script>
function highlightStars(label, rating) {
    const container = label.parentElement;
    const labels = container.querySelectorAll('label');
    labels.forEach((l, index) => {
        const starValue = 5 - index;
        l.style.color = starValue <= rating ? '#f59e0b' : '#d1d5db';
    });
}

function resetStars(label) {
    const container = label.parentElement;
    const checkedInput = container.querySelector('input:checked');
    const labels = container.querySelectorAll('label');
    
    if (checkedInput) {
        const checkedValue = parseInt(checkedInput.value);
        labels.forEach((l, index) => {
            const starValue = 5 - index;
            l.style.color = starValue <= checkedValue ? '#f59e0b' : '#d1d5db';
        });
    } else {
        labels.forEach(l => l.style.color = '#d1d5db');
    }
}

function selectStar(label, rating) {
    const container = label.parentElement;
    const labels = container.querySelectorAll('label');
    labels.forEach((l, index) => {
        const starValue = 5 - index;
        l.style.color = starValue <= rating ? '#f59e0b' : '#d1d5db';
    });
}

// Initialize star colors on page load
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.star-rating').forEach(container => {
        const checkedInput = container.querySelector('input:checked');
        if (checkedInput) {
            const labels = container.querySelectorAll('label');
            const checkedValue = parseInt(checkedInput.value);
            labels.forEach((l, index) => {
                const starValue = 5 - index;
                l.style.color = starValue <= checkedValue ? '#f59e0b' : '#d1d5db';
            });
        }
    });
});
</script>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

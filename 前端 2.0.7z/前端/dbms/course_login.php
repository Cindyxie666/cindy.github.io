<?php
require_once __DIR__ . '/config/course_database.php';

$error = '';
$pageTitle = 'Course Management System - Login';

// Redirect if already logged in
if (isCourseLoggedIn()) {
    header('Location: course_index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $account = $_POST['account'] ?? '';
    $password = $_POST['password'] ?? '';
    $user_type = $_POST['user_type'] ?? '';
    
    if ($account && $password && $user_type) {
        $conn = getCourseDBConnection();
        
        // Determine table and ID field based on user type
        $table = '';
        $id_field = '';
        
        switch ($user_type) {
            case 'student':
                $table = 'students';
                $id_field = 'student_id';
                break;
            case 'instructor':
                $table = 'instructors';
                $id_field = 'instructor_id';
                break;
            case 'administrator':
                $table = 'administrators';
                $id_field = 'admin_id';
                break;
        }
        
        if ($table) {
            $stmt = $conn->prepare("SELECT $id_field, name, account, password FROM $table WHERE account = ?");
            $stmt->bind_param("s", $account);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                // 改为明文密码比较
                if ($password === $user['password']) {
                    $_SESSION['user_id'] = $user[$id_field];
                    $_SESSION['username'] = $user['name'];
                    $_SESSION['user_type'] = $user_type;
                    $_SESSION['account'] = $user['account'];
                    header('Location: course_index.php');
                    exit();
                } else {
                    $error = 'Invalid account or password';
                }
            } else {
                $error = 'Invalid account or password';
            }
            
            $stmt->close();
        }
        
        $conn->close();
    } else {
        $error = 'Please fill in all fields';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/components.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-icon">📚</div>
                <h1>Course Management System</h1>
                <p>Welcome Back</p>
            </div>
            <form method="POST" class="login-form">
                <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <div class="form-group">
                    <label>User Type</label>
                    <select name="user_type" required>
                        <option value="">Select User Type</option>
                        <option value="student">Student</option>
                        <option value="instructor">Instructor</option>
                        <option value="administrator">Administrator</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Account</label>
                    <input type="text" name="account" placeholder="Enter account" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter password" required>
                    <small style="display: block; margin-top: 0.5rem; color: #666; font-size: 0.875rem;">Default password: <strong>password</strong></small>
                </div>
                <button type="submit" class="login-button">Login</button>
                <div class="login-footer">
                    <p>Don't have an account? <a href="course_register.php">Register here</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

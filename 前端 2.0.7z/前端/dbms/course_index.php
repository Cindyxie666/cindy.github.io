<?php
require_once __DIR__ . '/config/course_database.php';
requireCourseLogin();

$pageTitle = 'Dashboard';
$userType = getUserType();
$conn = getCourseDBConnection();

$message = '';
$messageType = '';

// Handle clear all data action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'clear_all_data') {
    requireAdministrator();
    
    $password = $_POST['password'] ?? '';
    $adminId = getCurrentUserId();
    
    if (empty($password)) {
        $message = "Password is required!";
        $messageType = "error";
    } else {
        // Verify password (明文比较)
        $stmt = $conn->prepare("SELECT password FROM administrators WHERE admin_id = ?");
        $stmt->bind_param("i", $adminId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result && $password === $result['password']) {
            // Password verified, proceed with clearing data
            try {
                $conn->begin_transaction();
                
                // Disable foreign key checks temporarily
                $conn->query("SET FOREIGN_KEY_CHECKS = 0");
                
                // Clear all tables except the three sample accounts
                $conn->query("DELETE FROM enrollments");
                $conn->query("DELETE FROM teaching");
                $conn->query("DELETE FROM course_management");
                $conn->query("DELETE FROM appeal_reviews");
                $conn->query("DELETE FROM supplier_approvals");
                $conn->query("DELETE FROM evaluation_releases");
                $conn->query("DELETE FROM grade_appeals");
                $conn->query("DELETE FROM grades");
                $conn->query("DELETE FROM assignment_submissions");
                $conn->query("DELETE FROM assignments");
                $conn->query("DELETE FROM courses");
                $conn->query("DELETE FROM announcements");
                $conn->query("DELETE FROM textbook_orders");
                $conn->query("DELETE FROM textbooks");
                $conn->query("DELETE FROM suppliers");
                $conn->query("DELETE FROM teaching_evaluations");
                $conn->query("DELETE FROM course_schedules");
                $conn->query("DELETE FROM students WHERE account != 'student1'");
                $conn->query("DELETE FROM instructors WHERE account != 'instructor1'");
                $conn->query("DELETE FROM administrators WHERE account != 'admin'");
                $conn->query("DELETE FROM system_settings WHERE setting_key != 'enrollment_enabled'");
                $conn->query("INSERT INTO system_settings (setting_key, setting_value, description) VALUES ('enrollment_enabled', '1', 'Course enrollment channel status (1=enabled/open, 0=disabled/closed)') ON DUPLICATE KEY UPDATE setting_value = '1'");
                
                // Re-enable foreign key checks
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");
                
                $conn->commit();
                $message = "All data cleared successfully! Only the three sample accounts (admin, instructor1, student1) remain.";
                $messageType = "success";
            } catch (Exception $e) {
                $conn->rollback();
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");
                $message = "Error clearing data: " . $e->getMessage();
                $messageType = "error";
            }
        } else {
            $message = "Invalid password!";
            $messageType = "error";
        }
    }
}

// Get user-specific data
$stats = [];
$studentInfo = null;

if ($userType === 'student') {
    $studentId = getCurrentUserId();
    
    // Get student info (name, major, grade_level)
    $stmt = $conn->prepare("SELECT name, major, grade_level FROM students WHERE student_id = ?");
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $studentInfo = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    // Get enrolled courses count
    $result = $conn->query("SELECT COUNT(*) as count FROM enrollments WHERE student_id = $studentId AND enrollment_status = 'enrolled'");
    $stats['courses'] = $result->fetch_assoc()['count'];
    
    // Get pending assignments
    $result = $conn->query("SELECT COUNT(*) as count FROM assignments a 
                           JOIN enrollments e ON a.course_code = e.course_code 
                           WHERE e.student_id = $studentId AND e.enrollment_status = 'enrolled' 
                           AND a.deadline > NOW()");
    $stats['assignments'] = $result->fetch_assoc()['count'];
    
    // Get unread announcements
    $result = $conn->query("SELECT COUNT(*) as count FROM announcements 
                           WHERE course_code IN (SELECT course_code FROM enrollments WHERE student_id = $studentId) 
                           OR announcement_type = 'system_notification'");
    $stats['announcements'] = $result->fetch_assoc()['count'];
    
} elseif ($userType === 'instructor') {
    $instructorId = getCurrentUserId();
    // Get teaching courses count
    $result = $conn->query("SELECT COUNT(DISTINCT course_code) as count FROM teaching WHERE instructor_id = $instructorId");
    $stats['courses'] = $result->fetch_assoc()['count'];
    
    // Get assignments to grade
    $result = $conn->query("SELECT COUNT(*) as count FROM assignment_submissions s
                           JOIN assignments a ON s.assignment_id = a.assignment_id
                           WHERE a.instructor_id = $instructorId AND s.submission_status = 'submitted'");
    $stats['submissions'] = $result->fetch_assoc()['count'];
    
    // Get pending appeals
    $result = $conn->query("SELECT COUNT(*) as count FROM grade_appeals ga
                           JOIN grades g ON ga.grade_id = g.grade_id
                           WHERE g.instructor_id = $instructorId AND ga.appeal_status = 'pending'");
    $stats['appeals'] = $result->fetch_assoc()['count'];
    
} elseif ($userType === 'administrator') {
    // Get total courses
    $result = $conn->query("SELECT COUNT(*) as count FROM courses");
    $stats['courses'] = $result->fetch_assoc()['count'];
    
    // Get total students
    $result = $conn->query("SELECT COUNT(*) as count FROM students");
    $stats['students'] = $result->fetch_assoc()['count'];
    
    // Get total instructors
    $result = $conn->query("SELECT COUNT(*) as count FROM instructors");
    $stats['instructors'] = $result->fetch_assoc()['count'];
    
    // Get pending supplier approvals
    $result = $conn->query("SELECT COUNT(*) as count FROM suppliers WHERE cooperation_status = 'pending'");
    $stats['suppliers'] = $result->fetch_assoc()['count'];
}

$conn->close();
include __DIR__ . '/includes/course_header.php';
?>

<div class="dashboard">
    <div class="page-header">
        <div>
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
            <?php if ($userType === 'student' && $studentInfo): ?>
            <p>
                <strong>Major:</strong> <?php echo htmlspecialchars($studentInfo['major']); ?> | 
                <strong>Grade:</strong> <?php echo htmlspecialchars($studentInfo['grade_level']); ?>
            </p>
            <?php else: ?>
            <p>Course Management System Dashboard</p>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin: 1rem 0; padding: 1rem; border-radius: 4px; background: <?php echo $messageType === 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $messageType === 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <?php if ($userType === 'student' && $studentInfo): ?>
    <!-- Student Info Card -->
    <div class="info-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; border-radius: 12px; margin-bottom: 1.5rem; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);">
        <div style="display: flex; align-items: center; gap: 1rem;">
            <div style="width: 60px; height: 60px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">
                🎓
            </div>
            <div>
                <h3 style="margin: 0; font-size: 1.25rem;"><?php echo htmlspecialchars($studentInfo['name']); ?></h3>
                <p style="margin: 0.25rem 0 0 0; opacity: 0.9;">
                    <?php echo htmlspecialchars($studentInfo['major']); ?> - <?php echo htmlspecialchars($studentInfo['grade_level']); ?>
                </p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="stats-grid">
        <?php if ($userType === 'student'): ?>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: #3b82f6;">📚</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['courses']; ?></div>
                <div class="stat-label">Enrolled Courses</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: #f59e0b;">📝</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['assignments']; ?></div>
                <div class="stat-label">Pending Assignments</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">📢</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['announcements']; ?></div>
                <div class="stat-label">Announcements</div>
            </div>
        </div>
        <?php elseif ($userType === 'instructor'): ?>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: #3b82f6;">📚</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['courses']; ?></div>
                <div class="stat-label">Teaching Courses</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: #f59e0b;">📝</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['submissions']; ?></div>
                <div class="stat-label">Submissions to Grade</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(239, 68, 68, 0.1); color: #ef4444;">⚖️</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['appeals']; ?></div>
                <div class="stat-label">Pending Appeals</div>
            </div>
        </div>
        <?php elseif ($userType === 'administrator'): ?>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: #3b82f6;">📚</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['courses']; ?></div>
                <div class="stat-label">Total Courses</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">👥</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['students']; ?></div>
                <div class="stat-label">Total Students</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(139, 92, 246, 0.1); color: #8b5cf6;">👨‍🏫</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['instructors']; ?></div>
                <div class="stat-label">Total Instructors</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: #f59e0b;">🏪</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $stats['suppliers']; ?></div>
                <div class="stat-label">Pending Suppliers</div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="dashboard-grid">
        <div class="dashboard-card">
            <h3>Quick Actions</h3>
            <div class="quick-actions">
                <?php if ($userType === 'student'): ?>
                <a href="student_courses.php" class="action-link">📚 View My Courses</a>
                <a href="student_assignments.php" class="action-link">📝 View Assignments</a>
                <a href="student_grades.php" class="action-link">📊 View Grades</a>
                <a href="student_appeals.php" class="action-link">⚖️ Grade Appeals</a>
                <a href="student_textbooks.php" class="action-link">📖 Order Textbooks</a>
                <?php elseif ($userType === 'instructor'): ?>
                <a href="instructor_courses.php" class="action-link">📚 Manage Courses</a>
                <a href="instructor_assignments.php" class="action-link">📝 Manage Assignments</a>
                <a href="instructor_grading.php" class="action-link">✓ Grade Submissions</a>
                <a href="instructor_appeals.php" class="action-link">⚖️ Review Appeals</a>
                <a href="instructor_announcements.php" class="action-link">📢 Post Announcements</a>
                <?php elseif ($userType === 'administrator'): ?>
                <a href="admin_accounts.php" class="action-link">👥 Manage Accounts</a>
                <a href="admin_courses.php" class="action-link">📚 Manage Courses</a>
                <a href="admin_evaluations.php" class="action-link">📊 Teaching Evaluations</a>
                <a href="admin_bookstore.php" class="action-link">🏪 Bookstore Management</a>
                <a href="#" onclick="showClearDataModal(); return false;" class="action-link" style="color: #ef4444;">🗑️ Clear All Data</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if ($userType === 'administrator'): ?>
<!-- Clear Data Modal -->
<div id="clearDataModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 1000; align-items: center; justify-content: center; flex-direction: column;">
    <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 500px; width: 90%; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <h3 style="margin-top: 0; color: #ef4444;">⚠️ Clear All Data</h3>
        <p style="color: #666; margin-bottom: 1.5rem;">
            This action will <strong>permanently delete</strong> all data from the database, including:
        </p>
        <ul style="color: #666; margin-bottom: 1.5rem; padding-left: 1.5rem;">
            <li>All courses, assignments, and submissions</li>
            <li>All grades and appeals</li>
            <li>All enrollments and teaching records</li>
            <li>All announcements and evaluations</li>
            <li>All textbook orders and suppliers</li>
            <li>All user accounts <strong>except</strong> the three sample accounts (admin, instructor1, student1)</li>
        </ul>
        <p style="color: #ef4444; font-weight: bold; margin-bottom: 1.5rem;">
            ⚠️ This action cannot be undone!
        </p>
        <form method="POST" onsubmit="return confirm('Are you absolutely sure you want to clear all data? This action cannot be undone!');">
            <input type="hidden" name="action" value="clear_all_data">
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Enter your password to confirm:</label>
                <input type="password" name="password" required style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; font-size: 1rem;">
            </div>
            <div style="display: flex; gap: 0.75rem; justify-content: flex-end;">
                <button type="button" onclick="closeClearDataModal()" style="padding: 0.75rem 1.5rem; background: #6b7280; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 1rem;">Cancel</button>
                <button type="submit" style="padding: 0.75rem 1.5rem; background: #ef4444; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 1rem; font-weight: bold;">Clear All Data</button>
            </div>
        </form>
    </div>
</div>

<script>
function showClearDataModal() {
    document.getElementById('clearDataModal').style.display = 'flex';
}

function closeClearDataModal() {
    document.getElementById('clearDataModal').style.display = 'none';
}

document.getElementById('clearDataModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeClearDataModal();
    }
});
</script>
<?php endif; ?>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

<?php
require_once __DIR__ . '/config/course_database.php';

// Check if user is logged in
if (!isCourseLoggedIn()) {
    header('Location: course_login.php');
    exit();
}

$userType = getUserType();
$pageTitle = 'Course Schedule';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$userId = getCurrentUserId();

// Generate time slots: 8:00-8:50, 9:00-9:50, ..., 17:00-17:50
$timeSlots = [];
for ($hour = 8; $hour <= 17; $hour++) {
    $startTime = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00:00';
    $endTime = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':50:00';
    $timeSlots[] = [
        'start' => $startTime,
        'end' => $endTime,
        'display' => str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00-' . str_pad($hour, 2, '0', STR_PAD_LEFT) . ':50'
    ];
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$dayAbbr = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

// Initialize schedule grid
$scheduleGrid = [];
foreach ($days as $day) {
    foreach ($timeSlots as $slot) {
        $scheduleGrid[$day][$slot['start']] = [];
    }
}

if ($userType === 'student') {
    // Get enrolled courses with schedules
    $query = "SELECT c.course_code, c.course_name, c.course_category, cs.day_of_week, cs.start_time, cs.end_time
              FROM courses c
              JOIN enrollments e ON c.course_code = e.course_code
              LEFT JOIN course_schedules cs ON c.course_code = cs.course_code
              WHERE e.student_id = ? AND e.enrollment_status = 'enrolled' AND c.course_status = 'active'
              ORDER BY cs.day_of_week, cs.start_time";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // Populate schedule grid
    foreach ($results as $row) {
        if ($row['day_of_week'] && $row['start_time']) {
            $day = $row['day_of_week'];
            $startTime = $row['start_time'];
            $scheduleGrid[$day][$startTime][] = [
                'code' => $row['course_code'],
                'name' => $row['course_name'],
                'category' => $row['course_category']
            ];
        }
    }
    
} elseif ($userType === 'instructor') {
    // Get courses taught by instructor with schedules
    $query = "SELECT c.course_code, c.course_name, c.course_category, cs.day_of_week, cs.start_time, cs.end_time
              FROM courses c
              JOIN teaching t ON c.course_code = t.course_code
              LEFT JOIN course_schedules cs ON c.course_code = cs.course_code
              WHERE t.instructor_id = ? AND c.course_status IN ('active', 'draft')
              ORDER BY cs.day_of_week, cs.start_time";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // Populate schedule grid
    foreach ($results as $row) {
        if ($row['day_of_week'] && $row['start_time']) {
            $day = $row['day_of_week'];
            $startTime = $row['start_time'];
            $scheduleGrid[$day][$startTime][] = [
                'code' => $row['course_code'],
                'name' => $row['course_name'],
                'category' => $row['course_category']
            ];
        }
    }
}

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📅 Course Schedule</h2>
            <p>View your weekly course schedule</p>
        </div>
    </div>

    <div class="dashboard-card">
        <div style="overflow-x: auto;">
            <table id="scheduleTable" style="width: 100%; border-collapse: collapse; font-size: 0.875rem; min-width: 800px;">
                <thead>
                    <tr>
                        <th style="padding: 0.75rem; text-align: left; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold; min-width: 100px;">Time</th>
                        <?php foreach ($dayAbbr as $abbr): ?>
                        <th style="padding: 0.75rem; text-align: center; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold; min-width: 150px;"><?php echo $abbr; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($timeSlots as $slot): ?>
                    <tr>
                        <td style="padding: 0.75rem; border: 1px solid #ddd; font-weight: bold; background: #f9fafb; text-align: center;"><?php echo $slot['display']; ?></td>
                        <?php foreach ($days as $day): ?>
                        <td style="padding: 0.5rem; border: 1px solid #ddd; vertical-align: top; min-height: 60px;">
                            <?php 
                            $courses = $scheduleGrid[$day][$slot['start']] ?? [];
                            if (!empty($courses)): 
                                foreach ($courses as $course):
                                    $categoryColor = $course['category'] === 'MR' ? '#3b82f6' : 
                                                    ($course['category'] === 'ME' ? '#10b981' : 
                                                    ($course['category'] === 'GE' ? '#f59e0b' : '#ef4444'));
                            ?>
                            <div style="background: <?php echo $categoryColor; ?>; color: white; padding: 0.5rem; margin-bottom: 0.25rem; border-radius: 4px; font-size: 0.8rem;">
                                <div style="font-weight: bold; margin-bottom: 0.25rem;"><?php echo htmlspecialchars($course['code']); ?></div>
                                <div style="font-size: 0.75rem; opacity: 0.9;"><?php echo htmlspecialchars($course['name']); ?></div>
                            </div>
                            <?php 
                                endforeach;
                            endif; 
                            ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Legend -->
    <div class="dashboard-card" style="margin-top: 1.5rem;">
        <h3 style="margin-top: 0;">Category Legend</h3>
        <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <div style="width: 20px; height: 20px; background: #3b82f6; border-radius: 4px;"></div>
                <span>MR (Major Required)</span>
            </div>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <div style="width: 20px; height: 20px; background: #10b981; border-radius: 4px;"></div>
                <span>ME (Major Elective)</span>
            </div>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <div style="width: 20px; height: 20px; background: #f59e0b; border-radius: 4px;"></div>
                <span>GE (General Education)</span>
            </div>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <div style="width: 20px; height: 20px; background: #ef4444; border-radius: 4px;"></div>
                <span>FE (Free Elective)</span>
            </div>
        </div>
    </div>
</div>

<style>
#scheduleTable tbody td {
    transition: background-color 0.2s;
}

#scheduleTable tbody td:hover {
    background-color: #f0f9ff !important;
}

@media print {
    #scheduleTable {
        font-size: 0.75rem;
    }
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


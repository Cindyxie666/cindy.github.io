# Course and Assignment Management System

A complete web-based course management system built with PHP, HTML, CSS, and JavaScript, designed to run on Apache/XAMPP server.

## System Overview

This system manages courses, assignments, submissions, grading, appeals, announcements, and textbook orders for students, instructors, and administrators.

## Requirements Met

### Front End Requirements ✅

- ✅ **20+ Pages**: Multiple pages for each user type (exceeds requirement)
- ✅ **HTML + CSS + PHP + JavaScript**: All pages use standard web technologies
- ✅ **Navigation bars, header, footer**: Implemented in course_header.php and course_footer.php
- ✅ **Data validation**: Client-side and server-side validation
- ✅ **Apache/XAMPP deployment**: Ready for XAMPP
- ✅ **User registration and login**: Three user types (student, instructor, administrator)
- ✅ **4+ Features**: Course management, assignment submission, grading, appeals, bookstore

### Back End Requirements ✅

- ✅ **13 Entity Sets**: Students, Instructors, Administrators, Courses, Assignments, Submissions, Grades, Appeals, Announcements, Textbooks, Orders, Suppliers, Evaluations
- ✅ **14+ Relationship Sets**: Enroll, Teach, Manage, Create, Submit, Grade, File_Appeal, Review_Appeal, Announcement, Order, Include_Textbook, Approves, Releases, Completes
- ✅ **Large datasets**: 
  - Enrollments: 50,000+ records
  - Submissions: 50,000+ records
  - Students: 10,000+ records
  - Assignments: 10,000+ records
  - Grades: 30,000+ records
- ✅ **Performance**: Query execution time can be measured using `microtime()`
- ✅ **Normalization**: Database follows BCNF/3NF
- ✅ **Foreign Keys**: All relationships use foreign keys with CASCADE delete

## User Types

### Student Functions
1. ✅ Register and login
2. ✅ View enrolled courses and deadlines
3. ✅ Submit assignments online
4. ✅ View grades and feedback
5. ✅ File grade appeals
6. ✅ Receive announcements
7. ✅ Order textbooks online

### Instructor Functions
1. ✅ Login and authentication
2. ✅ Create and manage course information
3. ✅ Publish and update assignments
4. ✅ Grade submissions
5. ✅ Review grade appeals
6. ✅ Post announcements

### Administrator Functions
1. ✅ Manage student and instructor accounts
2. ✅ Publish and archive courses
3. ✅ Oversee course and assignment records
4. ✅ Release teaching evaluation surveys
5. ✅ Monitor grade appeal activities
6. ✅ Manage bookstore module

## Installation

1. **Import Database Schema**
   ```bash
   mysql -u root -p < course_management_schema.sql
   ```

2. **Generate Sample Data** (Optional)
   ```bash
   php generate_course_data.php
   ```

3. **Access Application**
   - URL: http://localhost/dbms/course_login.php
   - Default accounts:
     - Student: student1 / password
     - Instructor: instructor1 / password
     - Admin: admin / password

## Database Schema

### Entity Sets (13 total)
1. **students** - Student accounts
2. **instructors** - Instructor accounts
3. **administrators** - Administrator accounts
4. **courses** - Course information
5. **assignments** - Assignment details
6. **assignment_submissions** - Student submissions
7. **grades** - Grade records
8. **grade_appeals** - Grade appeal requests
9. **announcements** - System announcements
10. **textbooks** - Textbook catalog
11. **textbook_orders** - Textbook orders
12. **suppliers** - Textbook suppliers
13. **teaching_evaluations** - Teaching evaluations

### Relationship Sets (14+ total)
1. **enrollments** - Student-Course enrollment
2. **teaching** - Instructor-Course teaching
3. **course_management** - Administrator-Course management
4. **appeal_reviews** - Instructor-Grade Appeal review
5. **supplier_approvals** - Administrator-Supplier approval
6. **evaluation_releases** - Administrator-Evaluation release
7. Plus relationships via foreign keys in main tables

## Pages Structure

### Student Pages (10 files)
- `course_login.php` - Login page
- `course_register.php` - Registration page
- `course_index.php` - Student dashboard
- `student_courses.php` - View enrolled courses and deadlines
- `student_assignments.php` - View assignments
- `student_submit_assignment.php` - Submit assignments online
- `student_grades.php` - View grades and feedback
- `student_appeal.php` - File grade appeal
- `student_appeals.php` - View appeals list
- `student_announcements.php` - Receive announcements and notifications
- `student_textbooks.php` - Order required textbooks online

### Instructor Pages (6 files)
- `course_login.php` - Login and authentication
- `course_index.php` - Instructor dashboard
- `instructor_courses.php` - Create and manage course information
- `instructor_assignments.php` - Publish and update assignments
- `instructor_grading.php` - Grade submissions and give grades
- `instructor_appeals.php` - Review and respond to grade appeals
- `instructor_announcements.php` - Post announcements to students

### Administrator Pages (4 files)
- `course_login.php` - Administrator authentication
- `course_index.php` - Administrator dashboard
- `admin_accounts.php` - Manage student and instructor accounts
- `admin_courses.php` - Publish and archive courses, oversee records
- `admin_evaluations.php` - Release teaching evaluation surveys and collect responses
- `admin_bookstore.php` - Manage bookstore module (approve suppliers, manage textbooks, track orders)

## Features

### Feature 1: Course Management
- Students enroll in courses
- Instructors create and manage courses
- Administrators publish and archive courses

### Feature 2: Assignment Submission
- Students view assignments with deadlines
- Students submit assignments online
- Late submissions are marked automatically

### Feature 3: Grading System
- Instructors grade submissions
- Students view grades and feedback
- Students can file appeals for grade review

### Feature 4: Announcement System
- Instructors post course announcements
- Administrators post system announcements
- Students receive relevant announcements

### Feature 5: Bookstore Module
- Students order required textbooks
- Administrators manage suppliers
- Track orders and inventory

## Data Generation

The `generate_course_data.php` script generates:
- 10,000 students
- 500 instructors
- 1,000 courses
- 50,000 enrollments
- 10,000 assignments
- 50,000 submissions
- 30,000 grades
- 5,000 announcements
- 2,000 textbooks
- 10,000 textbook orders
- 10,000 teaching evaluations

## Security

- Password hashing with `password_hash()`
- Prepared statements (SQL injection prevention)
- Session-based authentication
- Role-based access control
- Input validation and sanitization

## Notes

- All text and interface elements are in English
- No Chinese characters in code or interface
- Follows ER diagram structure
- Meets all specified requirements
- Ready for XAMPP deployment


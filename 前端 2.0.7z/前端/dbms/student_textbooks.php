<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Textbooks';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

$message = '';
$messageType = '';

// Handle order submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'order') {
    $textbookId = $_POST['textbook_id'] ?? 0;
    $quantity = intval($_POST['quantity'] ?? 1);
    
    if ($textbookId && $quantity > 0) {
        // Get textbook price and stock
        $stmt = $conn->prepare("SELECT price, stock_quantity, title FROM textbooks WHERE textbook_id = ?");
        $stmt->bind_param("i", $textbookId);
        $stmt->execute();
        $textbook = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($textbook) {
            if ($quantity > $textbook['stock_quantity']) {
                $message = "Sorry, only {$textbook['stock_quantity']} copies available in stock.";
                $messageType = "error";
            } else {
                $totalAmount = $textbook['price'] * $quantity;
                $orderStmt = $conn->prepare("INSERT INTO textbook_orders (order_time, order_status, quantity_purchased, total_amount, student_id, textbook_id) VALUES (NOW(), 'pending', ?, ?, ?, ?)");
                $orderStmt->bind_param("idii", $quantity, $totalAmount, $studentId, $textbookId);
                if ($orderStmt->execute()) {
                    $message = "Order placed successfully for '{$textbook['title']}' x {$quantity}!";
                    $messageType = "success";
                } else {
                    $message = "Failed to place order. Please try again.";
                    $messageType = "error";
                }
                $orderStmt->close();
            }
        }
    }
}

// Get textbooks for enrolled courses
$query = "SELECT t.*, c.course_name, c.course_code, s.supplier_name
          FROM textbooks t
          LEFT JOIN courses c ON t.course_code = c.course_code
          LEFT JOIN suppliers s ON t.supplier_id = s.supplier_id
          WHERE t.course_code IN (SELECT course_code FROM enrollments WHERE student_id = ? AND enrollment_status = 'enrolled')
          OR t.course_code IS NULL
          ORDER BY c.course_code, t.title";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$textbooks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get student orders
$ordersQuery = "SELECT o.*, t.title, t.isbn, t.author FROM textbook_orders o
                JOIN textbooks t ON o.textbook_id = t.textbook_id
                WHERE o.student_id = ?
                ORDER BY o.order_time DESC";
$ordersStmt = $conn->prepare($ordersQuery);
$ordersStmt->bind_param("i", $studentId);
$ordersStmt->execute();
$orders = $ordersStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$ordersStmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📖 Textbooks</h2>
            <p>Order required textbooks for your courses</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 8px; background: <?php echo $messageType === 'success' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $messageType === 'success' ? '#065f46' : '#991b1b'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <div class="dashboard-grid">
        <!-- Available Textbooks -->
        <div class="dashboard-card">
            <h3>📚 Available Textbooks (<?php echo count($textbooks); ?>)</h3>
            <div class="table-container" style="max-height: 500px; overflow-y: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Author</th>
                            <th>ISBN</th>
                            <th>Course</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($textbooks)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 2rem; color: #666;">
                                No textbooks available. Enroll in courses to see related textbooks.
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($textbooks as $textbook): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($textbook['title']); ?></strong></td>
                            <td><?php echo htmlspecialchars($textbook['author'] ?? 'N/A'); ?></td>
                            <td style="font-family: monospace; font-size: 0.85rem;"><?php echo htmlspecialchars($textbook['isbn'] ?? 'N/A'); ?></td>
                            <td>
                                <?php if ($textbook['course_name']): ?>
                                <span class="course-badge"><?php echo htmlspecialchars($textbook['course_code']); ?></span>
                                <?php else: ?>
                                <span style="color: #666;">General</span>
                                <?php endif; ?>
                            </td>
                            <td style="color: #059669; font-weight: 600;">$<?php echo number_format($textbook['price'], 2); ?></td>
                            <td>
                                <span style="<?php echo $textbook['stock_quantity'] < 5 ? 'color: #dc2626;' : 'color: #059669;'; ?>">
                                    <?php echo $textbook['stock_quantity']; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($textbook['stock_quantity'] > 0): ?>
                                <form method="POST" style="display: flex; gap: 0.5rem; align-items: center;">
                                    <input type="hidden" name="action" value="order">
                                    <input type="hidden" name="textbook_id" value="<?php echo $textbook['textbook_id']; ?>">
                                    <input type="number" name="quantity" value="1" min="1" max="<?php echo $textbook['stock_quantity']; ?>" style="width: 60px; padding: 0.25rem; border: 1px solid #ddd; border-radius: 4px;">
                                    <button type="submit" class="btn-primary" style="padding: 0.25rem 0.75rem; font-size: 0.875rem;">Order</button>
                                </form>
                                <?php else: ?>
                                <span class="status-badge" style="background: #fee2e2; color: #dc2626;">Out of Stock</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- My Orders -->
        <div class="dashboard-card">
            <h3>🛒 My Orders (<?php echo count($orders); ?>)</h3>
            <div class="table-container" style="max-height: 500px; overflow-y: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Textbook</th>
                            <th>Author</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Order Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 2rem; color: #666;">
                                You haven't placed any orders yet.
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                            <td><?php echo htmlspecialchars($order['title']); ?></td>
                            <td><?php echo htmlspecialchars($order['author'] ?? 'N/A'); ?></td>
                            <td><?php echo $order['quantity_purchased']; ?></td>
                            <td style="color: #059669; font-weight: 600;">$<?php echo number_format($order['total_amount'], 2); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($order['order_time'])); ?></td>
                            <td>
                                <span class="status-badge <?php echo $order['order_status']; ?>">
                                    <?php echo ucfirst($order['order_status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* 表格容器滚动条 */
.table-container {
    overflow-x: auto;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}

.table-container::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}

/* 课程徽章 */
.course-badge {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
}

/* 状态徽章 */
.status-badge {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-badge.pending {
    background: #fef3c7;
    color: #d97706;
}

.status-badge.confirmed {
    background: #dbeafe;
    color: #2563eb;
}

.status-badge.shipped {
    background: #e0e7ff;
    color: #4f46e5;
}

.status-badge.delivered {
    background: #d1fae5;
    color: #059669;
}

.status-badge.cancelled {
    background: #fee2e2;
    color: #dc2626;
}

/* 响应式调整 */
@media (max-width: 768px) {
    .dashboard-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

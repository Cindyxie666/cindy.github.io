# Database Triggers Documentation

## Overview
This document describes all database triggers implemented in the Course Management System. These triggers enforce business rule constraints beyond standard SQL constraints (NOT NULL, PRIMARY KEY, UNIQUE, FOREIGN KEY).

## Trigger List

### 1. Assignment Deadline Constraint
**Triggers:** `check_assignment_deadline_before_insert`, `check_assignment_deadline_before_update`  
**Table:** `assignments`  
**Constraint:** Assignment deadline must be after release time  
**Error Message:** "Assignment deadline must be after release time"

**Purpose:** Ensures that assignments cannot have a deadline that is before or equal to the release time.

---

### 2. Grade Score Range Constraint
**Triggers:** `check_grade_score_before_insert`, `check_grade_score_before_update`  
**Table:** `grades`  
**Constraint:** Grade score must be between 0 and 100  
**Error Message:** "Grade score must be between 0 and 100"

**Purpose:** Validates that all grades fall within the valid range of 0-100.

---

### 3. Submission Time Constraint
**Triggers:** `check_submission_time_before_insert`, `check_submission_time_before_update`  
**Table:** `assignment_submissions`  
**Constraint:** Submission time cannot be earlier than assignment release time  
**Error Message:** "Submission time cannot be earlier than assignment release time"

**Purpose:** Prevents students from submitting assignments before they are released.

---

### 4. Course Schedule Time Constraint
**Triggers:** `check_schedule_time_before_insert`, `check_schedule_time_before_update`  
**Table:** `course_schedules`  
**Constraint:** End time must be after start time  
**Error Message:** "Course schedule end time must be after start time"

**Purpose:** Ensures course schedules have valid time ranges.

---

### 5. Textbook Order Quantity Constraint
**Triggers:** `check_textbook_order_quantity_before_insert`, `check_textbook_order_quantity_before_update`  
**Table:** `textbook_orders`  
**Constraints:** 
- Order quantity cannot exceed available stock
- Order quantity must be greater than 0  
**Error Messages:** 
- "Order quantity cannot exceed available stock"
- "Order quantity must be greater than 0"

**Purpose:** Prevents ordering more textbooks than available and ensures positive order quantities.

---

### 6. Evaluation Release Deadline Constraint
**Triggers:** `check_evaluation_deadline_before_insert`, `check_evaluation_deadline_before_update`  
**Table:** `evaluation_releases`  
**Constraint:** Collection deadline must be after release time  
**Error Message:** "Evaluation collection deadline must be after release time"

**Purpose:** Ensures evaluation collection deadlines are set after the release time.

---

### 7. Grading Time Constraint
**Triggers:** `check_grading_time_before_insert`, `check_grading_time_before_update`  
**Table:** `grades`  
**Constraint:** Grading time cannot be earlier than submission time  
**Error Message:** "Grading time cannot be earlier than submission time"

**Purpose:** Ensures grades are assigned after submissions are made.

---

### 8. Credit Hours Constraint
**Triggers:** `check_credit_hours_before_insert`, `check_credit_hours_before_update`  
**Table:** `courses`  
**Constraint:** Credit hours must be greater than 0  
**Error Message:** "Credit hours must be greater than 0"

**Purpose:** Ensures all courses have positive credit hours.

---

### 9. Textbook Price Constraint
**Triggers:** `check_textbook_price_before_insert`, `check_textbook_price_before_update`  
**Table:** `textbooks`  
**Constraint:** Textbook price cannot be negative  
**Error Message:** "Textbook price cannot be negative"

**Purpose:** Prevents negative prices for textbooks.

---

### 10. Order Total Amount Constraint
**Triggers:** `check_order_amount_before_insert`, `check_order_amount_before_update`  
**Table:** `textbook_orders`  
**Constraint:** Order total amount cannot be negative  
**Error Message:** "Order total amount cannot be negative"

**Purpose:** Ensures order amounts are non-negative.

---

## Implementation Details

### Trigger Execution
- All triggers execute **BEFORE** INSERT or UPDATE operations
- Triggers use MySQL `SIGNAL` statement to raise errors
- Error state `45000` is used for user-defined errors
- Each constraint has separate triggers for INSERT and UPDATE operations

### Error Handling
When a trigger constraint is violated:
1. The operation (INSERT/UPDATE) is aborted
2. An error is raised with SQLSTATE '45000'
3. A descriptive error message is returned to the application
4. No data changes are committed

### Testing Triggers
To test if triggers are working:

```sql
-- Test assignment deadline constraint
INSERT INTO assignments (assignment_name, release_time, deadline, course_code, instructor_id)
VALUES ('Test', '2024-01-01 10:00:00', '2024-01-01 09:00:00', 'CS101', 1);
-- Should fail with error message

-- Test grade score constraint
INSERT INTO grades (score, grading_time, submission_id, assignment_id, student_id, instructor_id)
VALUES (150, NOW(), 1, 1, 1, 1);
-- Should fail with error message
```

## Notes
- Triggers are automatically created when running `course_management_schema.sql`
- To add triggers to an existing database, run `database_triggers.sql`
- All triggers are included in the main schema file for new installations


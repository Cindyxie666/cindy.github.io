<?php
require_once __DIR__ . '/config/course_database.php';
courseLogout();
?>


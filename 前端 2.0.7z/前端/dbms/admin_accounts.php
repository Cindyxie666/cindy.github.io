<?php
require_once __DIR__ . '/config/course_database.php';
requireAdministrator();

$pageTitle = 'Account Management';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();

$message = '';
$messageType = '';

// Handle redirect messages
if (isset($_GET['message'])) {
    if ($_GET['message'] === 'updated') {
        $message = "Account updated successfully!";
        $messageType = "success";
    } elseif ($_GET['message'] === 'deleted') {
        $message = "Account deleted successfully!";
        $messageType = "success";
    }
}

// Handle edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $userType = $_POST['user_type'] ?? '';
    $userId = $_POST['user_id'] ?? 0;
    $name = $_POST['name'] ?? '';
    $account = $_POST['account'] ?? '';
    
    if ($userType && $userId && $name && $account) {
        $table = '';
        $idField = '';
        $updateFields = '';
        $params = [];
        $types = '';
        
        switch ($userType) {
            case 'student':
                $table = 'students';
                $idField = 'student_id';
                $gradeLevel = $_POST['grade_level'] ?? '';
                $major = $_POST['major'] ?? '';
                $contactInfo = $_POST['contact_info'] ?? '';
                
                $updateFields = "name = ?, account = ?, grade_level = ?, major = ?, contact_info = ?";
                $params = [$name, $account, $gradeLevel, $major, $contactInfo, $userId];
                $types = "sssssi";
                break;
            case 'instructor':
                $table = 'instructors';
                $idField = 'instructor_id';
                $department = $_POST['department'] ?? '';
                $subjectsTaught = $_POST['subjects_taught'] ?? '';
                $contactInfo = $_POST['contact_info'] ?? '';
                
                $updateFields = "name = ?, account = ?, department = ?, subjects_taught = ?, contact_info = ?";
                $params = [$name, $account, $department, $subjectsTaught, $contactInfo, $userId];
                $types = "sssssi";
                break;
            case 'administrator':
                $table = 'administrators';
                $idField = 'admin_id';
                $permissionLevel = $_POST['permission_level'] ?? 'normal';
                $contactInfo = $_POST['contact_info'] ?? '';
                
                $updateFields = "name = ?, account = ?, permission_level = ?, contact_info = ?";
                $params = [$name, $account, $permissionLevel, $contactInfo, $userId];
                $types = "ssssi";
                break;
        }
        
        if ($table && $updateFields) {
            // Check if account already exists for another user
            $checkStmt = $conn->prepare("SELECT $idField FROM $table WHERE account = ? AND $idField != ?");
            $checkStmt->bind_param("si", $account, $userId);
            $checkStmt->execute();
            $existing = $checkStmt->get_result()->fetch_assoc();
            $checkStmt->close();
            
            if (!$existing) {
                $stmt = $conn->prepare("UPDATE $table SET $updateFields WHERE $idField = ?");
                $stmt->bind_param($types, ...$params);
                if ($stmt->execute()) {
                    $stmt->close();
                    // Redirect to preserve filters (check both POST and GET)
                    $redirectParams = [];
                    if (!empty($_POST['search']) || !empty($_GET['search'])) $redirectParams['search'] = $_POST['search'] ?? $_GET['search'];
                    if (!empty($_POST['filter_type']) || !empty($_GET['filter_type'])) $redirectParams['filter_type'] = $_POST['filter_type'] ?? $_GET['filter_type'];
                    if (!empty($_POST['filter_grade']) || !empty($_GET['filter_grade'])) $redirectParams['filter_grade'] = $_POST['filter_grade'] ?? $_GET['filter_grade'];
                    if (!empty($_POST['filter_major']) || !empty($_GET['filter_major'])) $redirectParams['filter_major'] = $_POST['filter_major'] ?? $_GET['filter_major'];
                    if (!empty($_POST['filter_department']) || !empty($_GET['filter_department'])) $redirectParams['filter_department'] = $_POST['filter_department'] ?? $_GET['filter_department'];
                    if (!empty($_POST['page']) || !empty($_GET['page'])) $redirectParams['page'] = $_POST['page'] ?? $_GET['page'];
                    $redirectParams['message'] = 'updated';
                    header('Location: admin_accounts.php?' . http_build_query($redirectParams));
                    exit();
                } else {
                    $message = "Error updating account: " . $stmt->error;
                    $messageType = "error";
                }
                $stmt->close();
            } else {
                $message = "Account name already exists!";
                $messageType = "error";
            }
        }
    }
}

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $userType = $_POST['user_type'] ?? '';
    $userId = $_POST['user_id'] ?? 0;
    
    if ($userType && $userId) {
        $table = '';
        $idField = '';
        
        switch ($userType) {
            case 'student':
                $table = 'students';
                $idField = 'student_id';
                break;
            case 'instructor':
                $table = 'instructors';
                $idField = 'instructor_id';
                break;
            case 'administrator':
                $table = 'administrators';
                $idField = 'admin_id';
                break;
        }
        
        if ($table) {
            $stmt = $conn->prepare("DELETE FROM $table WHERE $idField = ?");
            $stmt->bind_param("i", $userId);
            if ($stmt->execute()) {
                $stmt->close();
                // Redirect to preserve filters (check both POST and GET)
                $redirectParams = [];
                if (!empty($_POST['search']) || !empty($_GET['search'])) $redirectParams['search'] = $_POST['search'] ?? $_GET['search'];
                    if (!empty($_POST['filter_type']) || !empty($_GET['filter_type'])) $redirectParams['filter_type'] = $_POST['filter_type'] ?? $_GET['filter_type'];
                    if (!empty($_POST['filter_grade']) || !empty($_GET['filter_grade'])) $redirectParams['filter_grade'] = $_POST['filter_grade'] ?? $_GET['filter_grade'];
                    if (!empty($_POST['filter_major']) || !empty($_GET['filter_major'])) $redirectParams['filter_major'] = $_POST['filter_major'] ?? $_GET['filter_major'];
                    if (!empty($_POST['filter_department']) || !empty($_GET['filter_department'])) $redirectParams['filter_department'] = $_POST['filter_department'] ?? $_GET['filter_department'];
                    if (!empty($_POST['page']) || !empty($_GET['page'])) $redirectParams['page'] = $_POST['page'] ?? $_GET['page'];
                    $redirectParams['message'] = 'deleted';
                header('Location: admin_accounts.php?' . http_build_query($redirectParams));
                exit();
            } else {
                $message = "Error deleting account: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    }
}

// Get filter and search parameters
$search = $_GET['search'] ?? '';
$filterType = $_GET['filter_type'] ?? '';
$filterGrade = $_GET['filter_grade'] ?? '';
$filterMajor = $_GET['filter_major'] ?? '';
$filterDepartment = $_GET['filter_department'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build WHERE conditions for students
$studentWhere = [];
$studentParams = [];
$studentTypes = '';

if ($filterType === '' || $filterType === 'student') {
    if ($search) {
        $studentWhere[] = "(name LIKE ? OR account LIKE ?)";
        $studentParams[] = "%$search%";
        $studentParams[] = "%$search%";
        $studentTypes .= "ss";
    }
    if ($filterGrade) {
        $studentWhere[] = "grade_level = ?";
        $studentParams[] = $filterGrade;
        $studentTypes .= "s";
    }
    if ($filterMajor) {
        $studentWhere[] = "major = ?";
        $studentParams[] = $filterMajor;
        $studentTypes .= "s";
    }
}

// Build WHERE conditions for instructors
$instructorWhere = [];
$instructorParams = [];
$instructorTypes = '';

if ($filterType === '' || $filterType === 'instructor') {
    if ($search) {
        $instructorWhere[] = "(name LIKE ? OR account LIKE ?)";
        $instructorParams[] = "%$search%";
        $instructorParams[] = "%$search%";
        $instructorTypes .= "ss";
    }
    if ($filterDepartment) {
        $instructorWhere[] = "department = ?";
        $instructorParams[] = $filterDepartment;
        $instructorTypes .= "s";
    }
}

// Build WHERE conditions for administrators
$adminWhere = [];
$adminParams = [];
$adminTypes = '';

if ($filterType === '' || $filterType === 'administrator') {
    if ($search) {
        $adminWhere[] = "(name LIKE ? OR account LIKE ?)";
        $adminParams[] = "%$search%";
        $adminParams[] = "%$search%";
        $adminTypes .= "ss";
    }
}

// Build queries
$studentWhereClause = !empty($studentWhere) ? "WHERE " . implode(" AND ", $studentWhere) : "";
$instructorWhereClause = !empty($instructorWhere) ? "WHERE " . implode(" AND ", $instructorWhere) : "";
$adminWhereClause = !empty($adminWhere) ? "WHERE " . implode(" AND ", $adminWhere) : "";

// Get total counts for pagination
$studentCountQuery = "SELECT COUNT(*) as total FROM students $studentWhereClause";
$instructorCountQuery = "SELECT COUNT(*) as total FROM instructors $instructorWhereClause";
$adminCountQuery = "SELECT COUNT(*) as total FROM administrators $adminWhereClause";

$totalCount = 0;

if ($filterType === '' || $filterType === 'student') {
    if (!empty($studentParams)) {
        $stmt = $conn->prepare($studentCountQuery);
        $stmt->bind_param($studentTypes, ...$studentParams);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $totalCount += $result['total'];
        $stmt->close();
    } else {
        $result = $conn->query($studentCountQuery)->fetch_assoc();
        $totalCount += $result['total'];
    }
}

if ($filterType === '' || $filterType === 'instructor') {
    if (!empty($instructorParams)) {
        $stmt = $conn->prepare($instructorCountQuery);
        $stmt->bind_param($instructorTypes, ...$instructorParams);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $totalCount += $result['total'];
        $stmt->close();
    } else {
        $result = $conn->query($instructorCountQuery)->fetch_assoc();
        $totalCount += $result['total'];
    }
}

if ($filterType === '' || $filterType === 'administrator') {
    if (!empty($adminParams)) {
        $stmt = $conn->prepare($adminCountQuery);
        $stmt->bind_param($adminTypes, ...$adminParams);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $totalCount += $result['total'];
        $stmt->close();
    } else {
        $result = $conn->query($adminCountQuery)->fetch_assoc();
        $totalCount += $result['total'];
    }
}

$totalPages = ceil($totalCount / $perPage);

// Get users with pagination (using UNION to combine and sort)
$allUsers = [];

// Get students
if ($filterType === '' || $filterType === 'student') {
    $studentQuery = "SELECT student_id as id, name, account, grade_level, major, contact_info, NULL as department, 'student' as type FROM students $studentWhereClause ORDER BY name LIMIT ? OFFSET ?";
    
    if (!empty($studentParams)) {
        // For students with filters, we need to get all matching records first, then paginate
        $tempQuery = "SELECT student_id as id, name, account, grade_level, major, contact_info, NULL as department, 'student' as type FROM students $studentWhereClause ORDER BY name";
        $stmt = $conn->prepare($tempQuery);
        if (!empty($studentTypes)) {
            $stmt->bind_param($studentTypes, ...$studentParams);
        }
        $stmt->execute();
        $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        $students = $conn->query("SELECT student_id as id, name, account, grade_level, major, contact_info, NULL as department, 'student' as type FROM students ORDER BY name")->fetch_all(MYSQLI_ASSOC);
    }
    $allUsers = array_merge($allUsers, $students);
}

// Get instructors
if ($filterType === '' || $filterType === 'instructor') {
    if (!empty($instructorParams)) {
        $tempQuery = "SELECT instructor_id as id, name, account, NULL as grade_level, NULL as major, contact_info, department, 'instructor' as type FROM instructors $instructorWhereClause ORDER BY name";
        $stmt = $conn->prepare($tempQuery);
        if (!empty($instructorTypes)) {
            $stmt->bind_param($instructorTypes, ...$instructorParams);
        }
        $stmt->execute();
        $instructors = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        $instructors = $conn->query("SELECT instructor_id as id, name, account, NULL as grade_level, NULL as major, contact_info, department, 'instructor' as type FROM instructors ORDER BY name")->fetch_all(MYSQLI_ASSOC);
    }
    $allUsers = array_merge($allUsers, $instructors);
}

// Get administrators
if ($filterType === '' || $filterType === 'administrator') {
    if (!empty($adminParams)) {
        $tempQuery = "SELECT admin_id as id, name, account, NULL as grade_level, permission_level as major, contact_info, NULL as department, 'administrator' as type FROM administrators $adminWhereClause ORDER BY name";
        $stmt = $conn->prepare($tempQuery);
        if (!empty($adminTypes)) {
            $stmt->bind_param($adminTypes, ...$adminParams);
        }
        $stmt->execute();
        $admins = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        $admins = $conn->query("SELECT admin_id as id, name, account, NULL as grade_level, permission_level as major, contact_info, NULL as department, 'administrator' as type FROM administrators ORDER BY name")->fetch_all(MYSQLI_ASSOC);
    }
    $allUsers = array_merge($allUsers, $admins);
}

// Sort all users by name
usort($allUsers, function($a, $b) {
    return strcmp($a['name'], $b['name']);
});

// Apply pagination
$allUsers = array_slice($allUsers, $offset, $perPage);

// Get unique values for filter dropdowns
$gradeLevels = $conn->query("SELECT DISTINCT grade_level FROM students WHERE grade_level IS NOT NULL ORDER BY grade_level")->fetch_all(MYSQLI_ASSOC);
$majors = $conn->query("SELECT DISTINCT major FROM students WHERE major IS NOT NULL ORDER BY major")->fetch_all(MYSQLI_ASSOC);
$departments = $conn->query("SELECT DISTINCT department FROM instructors WHERE department IS NOT NULL ORDER BY department")->fetch_all(MYSQLI_ASSOC);

// Get user details for editing (if edit_id is set)
$editUser = null;
if (isset($_GET['edit_id']) && isset($_GET['type'])) {
    $editId = $_GET['edit_id'];
    $editType = $_GET['type'];
    
    switch ($editType) {
        case 'student':
            $stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
            $stmt->bind_param("i", $editId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            if ($result) {
                $editUser = array_merge($result, ['type' => 'student']);
            }
            $stmt->close();
            break;
        case 'instructor':
            $stmt = $conn->prepare("SELECT * FROM instructors WHERE instructor_id = ?");
            $stmt->bind_param("i", $editId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            if ($result) {
                $editUser = array_merge($result, ['type' => 'instructor']);
            }
            $stmt->close();
            break;
        case 'administrator':
            $stmt = $conn->prepare("SELECT * FROM administrators WHERE admin_id = ?");
            $stmt->bind_param("i", $editId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            if ($result) {
                $editUser = array_merge($result, ['type' => 'administrator']);
            }
            $stmt->close();
            break;
    }
}

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>👥 Account Management</h2>
            <p>Manage student, instructor, and administrator accounts</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 4px; background: <?php echo $messageType === 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $messageType === 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Search and Filter Form -->
    <div style="background: white; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <form method="GET" action="admin_accounts.php" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; align-items: end;">
            <!-- Search -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Search (Name/Account)</label>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Enter name or account..." style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <!-- Filter Type -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Type</label>
                <select name="filter_type" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <option value="student" <?php echo $filterType === 'student' ? 'selected' : ''; ?>>Student</option>
                    <option value="instructor" <?php echo $filterType === 'instructor' ? 'selected' : ''; ?>>Instructor</option>
                    <option value="administrator" <?php echo $filterType === 'administrator' ? 'selected' : ''; ?>>Administrator</option>
                </select>
            </div>
            
            <!-- Filter Grade Level -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Grade Level</label>
                <select name="filter_grade" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <?php foreach ($gradeLevels as $grade): ?>
                        <option value="<?php echo htmlspecialchars($grade['grade_level']); ?>" <?php echo $filterGrade === $grade['grade_level'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($grade['grade_level']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Filter Major -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Major</label>
                <select name="filter_major" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <?php foreach ($majors as $major): ?>
                        <option value="<?php echo htmlspecialchars($major['major']); ?>" <?php echo $filterMajor === $major['major'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($major['major']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Filter Department -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Department</label>
                <select name="filter_department" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['department']); ?>" <?php echo $filterDepartment === $dept['department'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['department']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Buttons -->
            <div style="display: flex; gap: 0.5rem;">
                <button type="submit" style="padding: 0.5rem 1.5rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">Search</button>
                <a href="admin_accounts.php" style="padding: 0.5rem 1.5rem; background: #6b7280; color: white; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; text-align: center; font-weight: bold;">Reset</a>
            </div>
        </form>
    </div>

    <!-- Results Info -->
    <div style="margin-bottom: 1rem; color: #666; font-size: 0.9rem;">
        Found <strong><?php echo $totalCount; ?></strong> account(s), showing <strong><?php echo min($offset + 1, $totalCount); ?></strong> - <strong><?php echo min($offset + count($allUsers), $totalCount); ?></strong>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Account</th>
                    <th>Type</th>
                    <th>Details</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($allUsers as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['name']); ?></td>
                    <td><?php echo htmlspecialchars($user['account']); ?></td>
                    <td>
                        <span class="role-badge">
                            <?php echo ucfirst($user['type']); ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($user['type'] === 'student'): ?>
                            <?php echo htmlspecialchars($user['grade_level']); ?> - <?php echo htmlspecialchars($user['major']); ?>
                        <?php elseif ($user['type'] === 'instructor'): ?>
                            <?php echo htmlspecialchars($user['department'] ?? 'N/A'); ?>
                        <?php else: ?>
                            <?php echo htmlspecialchars($user['major'] ?? 'N/A'); ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button onclick="showEditModal(<?php echo $user['id']; ?>, '<?php echo $user['type']; ?>')" class="action-btn" style="margin-right: 0.5rem;">Edit</button>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this account?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="user_type" value="<?php echo $user['type']; ?>">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <?php
                            // Preserve filter parameters
                            if ($search) echo '<input type="hidden" name="search" value="' . htmlspecialchars($search) . '">';
                            if ($filterType) echo '<input type="hidden" name="filter_type" value="' . htmlspecialchars($filterType) . '">';
                            if ($filterGrade) echo '<input type="hidden" name="filter_grade" value="' . htmlspecialchars($filterGrade) . '">';
                            if ($filterMajor) echo '<input type="hidden" name="filter_major" value="' . htmlspecialchars($filterMajor) . '">';
                            if ($filterDepartment) echo '<input type="hidden" name="filter_department" value="' . htmlspecialchars($filterDepartment) . '">';
                            if ($page > 1) echo '<input type="hidden" name="page" value="' . $page . '">';
                            ?>
                            <button type="submit" class="action-btn danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($allUsers)): ?>
                <tr>
                    <td colspan="5" style="text-align: center; padding: 2rem; color: #999;">
                        No matching accounts found
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div style="margin-top: 2rem; display: flex; justify-content: center; align-items: center; gap: 0.5rem;">
        <?php
        // Build query string for pagination links
        $queryParams = [];
        if ($search) $queryParams['search'] = $search;
        if ($filterType) $queryParams['filter_type'] = $filterType;
        if ($filterGrade) $queryParams['filter_grade'] = $filterGrade;
        if ($filterMajor) $queryParams['filter_major'] = $filterMajor;
        if ($filterDepartment) $queryParams['filter_department'] = $filterDepartment;
        $queryString = !empty($queryParams) ? '&' . http_build_query($queryParams) : '';
        ?>
        
        <!-- First Page -->
        <?php if ($page > 1): ?>
            <a href="admin_accounts.php?page=1<?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">First</a>
        <?php endif; ?>
        
        <!-- Previous Page -->
        <?php if ($page > 1): ?>
            <a href="admin_accounts.php?page=<?php echo $page - 1; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Previous</a>
        <?php endif; ?>
        
        <!-- Page Numbers -->
        <?php
        $startPage = max(1, $page - 2);
        $endPage = min($totalPages, $page + 2);
        
        for ($i = $startPage; $i <= $endPage; $i++):
        ?>
            <a href="admin_accounts.php?page=<?php echo $i; ?><?php echo $queryString; ?>" 
               style="padding: 0.5rem 1rem; background: <?php echo $i === $page ? '#3b82f6' : 'white'; ?>; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: <?php echo $i === $page ? 'white' : '#333'; ?>; font-weight: <?php echo $i === $page ? 'bold' : 'normal'; ?>;">
                <?php echo $i; ?>
            </a>
        <?php endfor; ?>
        
        <!-- Next Page -->
        <?php if ($page < $totalPages): ?>
            <a href="admin_accounts.php?page=<?php echo $page + 1; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Next</a>
        <?php endif; ?>
        
        <!-- Last Page -->
        <?php if ($page < $totalPages): ?>
            <a href="admin_accounts.php?page=<?php echo $totalPages; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Last</a>
        <?php endif; ?>
        
        <span style="margin-left: 1rem; color: #666;">
            Page <?php echo $page; ?> / <?php echo $totalPages; ?>
        </span>
        
        <!-- Jump to Page -->
        <div style="margin-left: 1rem; display: flex; align-items: center; gap: 0.5rem;">
            <span style="color: #666; font-size: 0.875rem;">Go to:</span>
            <input type="number" id="jumpPage" min="1" max="<?php echo $totalPages; ?>" value="<?php echo $page; ?>" style="width: 60px; padding: 0.25rem 0.5rem; border: 1px solid #ddd; border-radius: 4px; font-size: 0.875rem;">
            <button onclick="jumpToPage('admin_accounts.php', <?php echo $totalPages; ?>, '<?php echo htmlspecialchars($queryString, ENT_QUOTES); ?>')" style="padding: 0.25rem 0.75rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 0.875rem;">Go</button>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
    <div class="modal-content" style="background-color: #fefefe; margin: 5% auto; padding: 2rem; border: 1px solid #888; width: 80%; max-width: 600px; border-radius: 8px;">
        <span class="close" onclick="closeEditModal()" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h2>Edit Account</h2>
        <form method="POST" id="editForm" action="admin_accounts.php">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="user_type" id="edit_user_type">
            <input type="hidden" name="user_id" id="edit_user_id">
            <?php
            // Preserve filter parameters in form
            if ($search) echo '<input type="hidden" name="search" value="' . htmlspecialchars($search) . '">';
            if ($filterType) echo '<input type="hidden" name="filter_type" value="' . htmlspecialchars($filterType) . '">';
            if ($filterGrade) echo '<input type="hidden" name="filter_grade" value="' . htmlspecialchars($filterGrade) . '">';
            if ($filterMajor) echo '<input type="hidden" name="filter_major" value="' . htmlspecialchars($filterMajor) . '">';
            if ($filterDepartment) echo '<input type="hidden" name="filter_department" value="' . htmlspecialchars($filterDepartment) . '">';
            if ($page > 1) echo '<input type="hidden" name="page" value="' . $page . '">';
            ?>
            
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Name *</label>
                <input type="text" name="name" id="edit_name" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Account *</label>
                <input type="text" name="account" id="edit_account" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <!-- Student specific fields -->
            <div id="student_fields" style="display: none;">
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Grade Level *</label>
                    <input type="text" name="grade_level" id="edit_grade_level" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Major *</label>
                    <input type="text" name="major" id="edit_major" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Contact Info</label>
                    <input type="text" name="contact_info" id="edit_contact_info" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
            </div>
            
            <!-- Instructor specific fields -->
            <div id="instructor_fields" style="display: none;">
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Department *</label>
                    <input type="text" name="department" id="edit_department" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Subjects Taught</label>
                    <textarea name="subjects_taught" id="edit_subjects_taught" rows="3" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;"></textarea>
                </div>
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Contact Info</label>
                    <input type="text" name="contact_info" id="edit_contact_info_instructor" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
            </div>
            
            <!-- Administrator specific fields -->
            <div id="admin_fields" style="display: none;">
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Permission Level *</label>
                    <select name="permission_level" id="edit_permission_level" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="normal">Normal</option>
                        <option value="super">Super</option>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Contact Info</label>
                    <input type="text" name="contact_info" id="edit_contact_info_admin" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
            </div>
            
            <div class="form-actions" style="margin-top: 1.5rem; display: flex; gap: 0.5rem;">
                <button type="submit" class="btn-primary" style="padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">Save Changes</button>
                <button type="button" class="btn-secondary" onclick="closeEditModal()" style="padding: 0.5rem 1rem; background: #6b7280; color: white; border: none; border-radius: 4px; cursor: pointer;">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showEditModal(userId, userType) {
    // Build query string with current filters
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('edit_id', userId);
    urlParams.set('type', userType);
    window.location.href = 'admin_accounts.php?' + urlParams.toString();
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
    // Remove edit parameters but keep filters
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.delete('edit_id');
    urlParams.delete('type');
    const queryString = urlParams.toString();
    window.location.href = 'admin_accounts.php' + (queryString ? '?' + queryString : '');
}

function jumpToPage(baseUrl, maxPages, queryString) {
    const pageInput = document.getElementById('jumpPage');
    const page = parseInt(pageInput.value);
    if (page >= 1 && page <= maxPages) {
        window.location.href = baseUrl + '?page=' + page + queryString;
    } else {
        alert('Please enter a valid page number between 1 and ' + maxPages);
        pageInput.focus();
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target == modal) {
        closeEditModal();
    }
}

// Populate edit modal if editUser is set
<?php if ($editUser): ?>
document.addEventListener('DOMContentLoaded', function() {
    const user = <?php echo json_encode($editUser); ?>;
    const userIdField = user.type === 'student' ? 'student_id' : (user.type === 'instructor' ? 'instructor_id' : 'admin_id');
    
    document.getElementById('edit_user_id').value = user[userIdField];
    document.getElementById('edit_user_type').value = user.type;
    document.getElementById('edit_name').value = user.name || '';
    document.getElementById('edit_account').value = user.account || '';
    
    // Hide all field groups first
    document.getElementById('student_fields').style.display = 'none';
    document.getElementById('instructor_fields').style.display = 'none';
    document.getElementById('admin_fields').style.display = 'none';
    
    // Show appropriate fields based on user type
    if (user.type === 'student') {
        document.getElementById('student_fields').style.display = 'block';
        document.getElementById('edit_grade_level').value = user.grade_level || '';
        document.getElementById('edit_major').value = user.major || '';
        document.getElementById('edit_contact_info').value = user.contact_info || '';
    } else if (user.type === 'instructor') {
        document.getElementById('instructor_fields').style.display = 'block';
        document.getElementById('edit_department').value = user.department || '';
        document.getElementById('edit_subjects_taught').value = user.subjects_taught || '';
        document.getElementById('edit_contact_info_instructor').value = user.contact_info || '';
    } else if (user.type === 'administrator') {
        document.getElementById('admin_fields').style.display = 'block';
        document.getElementById('edit_permission_level').value = user.permission_level || 'normal';
        document.getElementById('edit_contact_info_admin').value = user.contact_info || '';
    }
    
    // Show modal
    document.getElementById('editModal').style.display = 'flex';
});
<?php endif; ?>
</script>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


# Quick Start Guide - Course Management System

## Prerequisites
- XAMPP installed and running
- Apache and MySQL services started

## Quick Setup (5 minutes)

1. **Copy files to XAMPP**
   ```bash
   # Copy php folder to htdocs
   cp -r php /Applications/XAMPP/htdocs/dbms
   ```

2. **Create database**
   - Open http://localhost/phpmyadmin
   - Click "Import" tab
   - Select `course_management_schema.sql`
   - Click "Go"
   - Database `course_management_system` will be created automatically

3. **Access application**
   - Open http://localhost/dbms/course_login.php
   - Login as:
     - Student: `student1` / `password`
     - Instructor: `instructor1` / `password`
     - Admin: `admin` / `password`

4. **Generate sample data** (optional, takes ~5-10 minutes)
   ```bash
   cd /Applications/XAMPP/htdocs/dbms
   php generate_course_data.php
   ```

## Default Logins

- **Student**: student1 / password
- **Instructor**: instructor1 / password
- **Administrator**: admin / password

## Pages Overview

### Student Pages (10)
1. **Login** - User authentication
2. **Register** - New user registration
3. **Dashboard** - System overview
4. **My Courses** - View enrolled courses and deadlines
5. **Assignments** - View assignments
6. **Submit Assignment** - Submit assignments online
7. **Grades** - View grades and feedback
8. **Appeals** - File and view grade appeals
9. **Announcements** - View announcements
10. **Textbooks** - Order textbooks online

### Instructor Pages (6)
1. **Login** - Instructor authentication
2. **Dashboard** - Instructor overview
3. **Courses** - Create and manage courses
4. **Assignments** - Publish and update assignments
5. **Grading** - Grade submissions
6. **Appeals** - Review grade appeals
7. **Announcements** - Post announcements

### Administrator Pages (4)
1. **Login** - Administrator authentication
2. **Dashboard** - Administrator overview
3. **Accounts** - Manage student and instructor accounts
4. **Courses** - Publish and archive courses
5. **Evaluations** - Manage teaching evaluations
6. **Bookstore** - Manage bookstore module

## Features Demonstrated

1. **Course Management** - Students enroll, instructors teach, admins manage
2. **Assignment Submission** - Students submit assignments with deadline tracking
3. **Grading System** - Instructors grade submissions, students view feedback
4. **Grade Appeals** - Students file appeals, instructors review
5. **Announcements** - Course and system announcements
6. **Bookstore** - Textbook ordering and management

## Testing Performance

1. Go to any page with database queries
2. Check query execution time (can be displayed using microtime())
3. All operations are logged in the database
4. Large datasets (50K+ records) are handled efficiently

## Requirements Met

✅ 20+ pages (more than required 10)
✅ HTML + CSS + PHP + JavaScript
✅ Navigation, header, footer
✅ User registration/login with 3 roles (student, instructor, administrator)
✅ 4+ complete features
✅ Large datasets (50K+ records in enrollments/submissions)
✅ Query execution time can be displayed
✅ Foreign keys with CASCADE
✅ BCNF/3NF normalization
✅ 13 entity sets, 14+ relationship sets

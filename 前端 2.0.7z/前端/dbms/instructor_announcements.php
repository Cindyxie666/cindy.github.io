<?php
require_once __DIR__ . '/config/course_database.php';
requireInstructor();

$pageTitle = 'Post Announcements';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$instructorId = getCurrentUserId();

// Handle create announcement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $courseCode = $_POST['course_code'] ?? '';
    $announcementType = $_POST['announcement_type'] ?? 'course_notification';
    
    if ($title && $content) {
        $stmt = $conn->prepare("INSERT INTO announcements (title, content, release_time, publisher_type, publisher_id, course_code, announcement_type) VALUES (?, ?, NOW(), 'instructor', ?, ?, ?)");
        $stmt->bind_param("ssiss", $title, $content, $instructorId, $courseCode, $announcementType);
        $stmt->execute();
        $stmt->close();
    }
}

// Get courses taught by instructor
$coursesStmt = $conn->prepare("SELECT DISTINCT c.course_code, c.course_name FROM courses c JOIN teaching t ON c.course_code = t.course_code WHERE t.instructor_id = ?");
$coursesStmt->bind_param("i", $instructorId);
$coursesStmt->execute();
$courses = $coursesStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$coursesStmt->close();

// Get announcements posted by this instructor
$announcementsStmt = $conn->prepare("SELECT a.*, c.course_name FROM announcements a LEFT JOIN courses c ON a.course_code = c.course_code WHERE a.publisher_type = 'instructor' AND a.publisher_id = ? ORDER BY a.release_time DESC");
$announcementsStmt->bind_param("i", $instructorId);
$announcementsStmt->execute();
$announcements = $announcementsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$announcementsStmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📢 Post Announcements</h2>
            <p>Post announcements and reminders to students</p>
        </div>
        <button onclick="showCreateModal()" class="btn-primary">+ Post Announcement</button>
    </div>

    <div class="dashboard-grid">
        <div class="dashboard-card">
            <h3>Create New Announcement</h3>
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <div class="form-group">
                    <label>Title *</label>
                    <input type="text" name="title" required>
                </div>
                <div class="form-group">
                    <label>Content *</label>
                    <textarea name="content" rows="5" required></textarea>
                </div>
                <div class="form-group">
                    <label>Course</label>
                    <select name="course_code">
                        <option value="">All Courses (System Notification)</option>
                        <?php foreach ($courses as $course): ?>
                        <option value="<?php echo htmlspecialchars($course['course_code']); ?>"><?php echo htmlspecialchars($course['course_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Type</label>
                    <select name="announcement_type">
                        <option value="course_notification">Course Notification</option>
                        <option value="system_notification">System Notification</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary">Post Announcement</button>
            </form>
        </div>

        <div class="dashboard-card">
            <h3>My Announcements</h3>
            <div class="announcements-list">
                <?php foreach ($announcements as $announcement): ?>
                <div class="announcement-item">
                    <h4><?php echo htmlspecialchars($announcement['title']); ?></h4>
                    <p class="announcement-meta">
                        <span>📚 <?php echo htmlspecialchars($announcement['course_name'] ?? 'System'); ?></span>
                        <span>🕒 <?php echo date('Y-m-d H:i', strtotime($announcement['release_time'])); ?></span>
                    </p>
                    <p><?php echo htmlspecialchars(substr($announcement['content'], 0, 100)); ?>...</p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<style>
.announcements-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}
.announcement-item {
    padding: 1rem;
    background: var(--bg);
    border-radius: 0.5rem;
    border-left: 3px solid var(--primary);
}
.announcement-item h4 {
    margin: 0 0 0.5rem 0;
    font-size: 1rem;
    font-weight: 600;
}
.announcement-meta {
    display: flex;
    gap: 1rem;
    font-size: 0.875rem;
    color: var(--text-light);
    margin-bottom: 0.5rem;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


<?php
require_once __DIR__ . '/config/course_database.php';
requireInstructor();

$pageTitle = 'Review Appeals';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$instructorId = getCurrentUserId();

$message = '';
$messageType = '';

// Handle review appeal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'review') {
    $appealId = intval($_POST['appeal_id'] ?? 0);
    $reviewResult = $_POST['review_result'] ?? '';
    $reviewRemarks = trim($_POST['review_remarks'] ?? '');
    $newScore = isset($_POST['new_score']) ? floatval($_POST['new_score']) : null;
    
    if ($appealId && in_array($reviewResult, ['approve', 'reject'])) {
        // Verify this appeal belongs to a grade given by this instructor
        $verifyQuery = "SELECT ga.appeal_id, ga.appeal_status, ga.grade_id, ga.student_id,
                               g.score as original_score, g.assignment_id,
                               a.assignment_name
                        FROM grade_appeals ga
                        JOIN grades g ON ga.grade_id = g.grade_id
                        JOIN assignments a ON g.assignment_id = a.assignment_id
                        WHERE ga.appeal_id = ? AND g.instructor_id = ? AND ga.appeal_status = 'pending'";
        $verifyStmt = $conn->prepare($verifyQuery);
        $verifyStmt->bind_param("ii", $appealId, $instructorId);
        $verifyStmt->execute();
        $appealData = $verifyStmt->get_result()->fetch_assoc();
        $verifyStmt->close();
        
        if ($appealData) {
            $conn->begin_transaction();
            
            try {
                // Insert review record
                $stmt = $conn->prepare("INSERT INTO appeal_reviews (instructor_id, appeal_id, review_time, review_result, review_remarks) VALUES (?, ?, NOW(), ?, ?)");
                $stmt->bind_param("iiss", $instructorId, $appealId, $reviewResult, $reviewRemarks);
                $stmt->execute();
                $stmt->close();
                
                // Update appeal status
                $status = $reviewResult === 'approve' ? 'approved' : 'rejected';
                $updateStmt = $conn->prepare("UPDATE grade_appeals SET appeal_status = ? WHERE appeal_id = ?");
                $updateStmt->bind_param("si", $status, $appealId);
                $updateStmt->execute();
                $updateStmt->close();
                
                // If approved and new score provided, update the grade
                if ($reviewResult === 'approve' && $newScore !== null && $newScore >= 0 && $newScore <= 100) {
                    $gradeStmt = $conn->prepare("UPDATE grades SET score = ?, grading_remarks = CONCAT(IFNULL(grading_remarks, ''), '\n[Appeal Approved] Score updated from ', score, ' to ', ?) WHERE grade_id = ?");
                    $gradeStmt->bind_param("ddi", $newScore, $newScore, $appealData['grade_id']);
                    $gradeStmt->execute();
                    $gradeStmt->close();
                }
                
                // Send notification to student
                $notifContent = $reviewResult === 'approve' 
                    ? "Your grade appeal for '{$appealData['assignment_name']}' has been APPROVED." . ($newScore !== null ? " New score: $newScore" : "") . ($reviewRemarks ? " Remarks: $reviewRemarks" : "")
                    : "Your grade appeal for '{$appealData['assignment_name']}' has been REJECTED." . ($reviewRemarks ? " Remarks: $reviewRemarks" : "");
                
                $notifStmt = $conn->prepare("INSERT INTO notifications (notification_content, notification_time, is_read, student_id, instructor_id) VALUES (?, NOW(), 0, ?, ?)");
                $notifStmt->bind_param("sii", $notifContent, $appealData['student_id'], $instructorId);
                $notifStmt->execute();
                $notifStmt->close();
                
                $conn->commit();
                
                $message = "Appeal " . ($reviewResult === 'approve' ? 'approved' : 'rejected') . " successfully!";
                $messageType = "success";
                
            } catch (Exception $e) {
                $conn->rollback();
                $message = "Error processing review: " . $e->getMessage();
                $messageType = "error";
            }
        } else {
            $message = "Invalid appeal, already reviewed, or you don't have permission.";
            $messageType = "error";
        }
    } else {
        $message = "Please select a valid review result.";
        $messageType = "error";
    }
}

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$filterStatus = $_GET['status'] ?? '';

// Build filter
$filterWhere = "";
$filterParams = [$instructorId];
$filterTypes = "i";

if ($filterStatus && in_array($filterStatus, ['pending', 'approved', 'rejected'])) {
    $filterWhere = " AND ga.appeal_status = ?";
    $filterParams[] = $filterStatus;
    $filterTypes .= "s";
}

// Get total count
$countQuery = "SELECT COUNT(*) as total 
               FROM grade_appeals ga
               JOIN grades g ON ga.grade_id = g.grade_id
               WHERE g.instructor_id = ? $filterWhere";
$countStmt = $conn->prepare($countQuery);
$countStmt->bind_param($filterTypes, ...$filterParams);
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['total'];
$countStmt->close();

$totalPages = max(1, ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

// Get appeals
$listParams = $filterParams;
$listTypes = $filterTypes;
$listParams[] = $perPage;
$listParams[] = $offset;
$listTypes .= "ii";

$query = "SELECT ga.*, 
                 g.score as original_score, g.grading_remarks as original_remarks, g.grading_time,
                 a.assignment_name, a.assignment_id,
                 c.course_name, c.course_code,
                 s.name as student_name, s.account as student_account,
                 ar.review_result, ar.review_remarks as review_remarks_result, ar.review_time
          FROM grade_appeals ga
          JOIN grades g ON ga.grade_id = g.grade_id
          JOIN assignments a ON g.assignment_id = a.assignment_id
          JOIN courses c ON a.course_code = c.course_code
          JOIN students s ON ga.student_id = s.student_id
          LEFT JOIN appeal_reviews ar ON ga.appeal_id = ar.appeal_id
          WHERE g.instructor_id = ? $filterWhere
          ORDER BY 
            CASE WHEN ga.appeal_status = 'pending' THEN 0 ELSE 1 END,
            ga.appeal_submission_time DESC
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($query);
$stmt->bind_param($listTypes, ...$listParams);
$stmt->execute();
$appeals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get statistics
$statsQuery = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN ga.appeal_status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN ga.appeal_status = 'approved' THEN 1 ELSE 0 END) as approved,
    SUM(CASE WHEN ga.appeal_status = 'rejected' THEN 1 ELSE 0 END) as rejected
FROM grade_appeals ga
JOIN grades g ON ga.grade_id = g.grade_id
WHERE g.instructor_id = ?";
$statsStmt = $conn->prepare($statsQuery);
$statsStmt->bind_param("i", $instructorId);
$statsStmt->execute();
$stats = $statsStmt->get_result()->fetch_assoc();
$statsStmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>⚖️ Review Grade Appeals</h2>
            <p>Review and respond to student grade appeals</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 8px; background: <?php echo $messageType === 'success' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $messageType === 'success' ? '#065f46' : '#991b1b'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
        <div class="dashboard-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 1.5rem; font-weight: bold; color: #3b82f6;"><?php echo $stats['total'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">Total Appeals</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1rem; cursor: pointer;" onclick="window.location='?status=pending'">
            <div style="font-size: 1.5rem; font-weight: bold; color: #f59e0b;"><?php echo $stats['pending'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">⏳ Pending</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1rem; cursor: pointer;" onclick="window.location='?status=approved'">
            <div style="font-size: 1.5rem; font-weight: bold; color: #10b981;"><?php echo $stats['approved'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">✅ Approved</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1rem; cursor: pointer;" onclick="window.location='?status=rejected'">
            <div style="font-size: 1.5rem; font-weight: bold; color: #ef4444;"><?php echo $stats['rejected'] ?? 0; ?></div>
            <div style="color: #666; font-size: 0.875rem;">❌ Rejected</div>
        </div>
    </div>

    <!-- Filter -->
    <div class="dashboard-card" style="margin-bottom: 1.5rem;">
        <form method="GET" style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
            <div>
                <label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; color: #666;">Filter by Status</label>
                <select name="status" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; min-width: 150px;">
                    <option value="">All Status</option>
                    <option value="pending" <?php echo $filterStatus === 'pending' ? 'selected' : ''; ?>>⏳ Pending</option>
                    <option value="approved" <?php echo $filterStatus === 'approved' ? 'selected' : ''; ?>>✅ Approved</option>
                    <option value="rejected" <?php echo $filterStatus === 'rejected' ? 'selected' : ''; ?>>❌ Rejected</option>
                </select>
            </div>
            <div style="align-self: flex-end;">
                <button type="submit" class="btn-primary">Filter</button>
                <?php if ($filterStatus): ?>
                <a href="instructor_appeals.php" class="btn-secondary" style="margin-left: 0.5rem;">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Appeals List -->
    <div class="dashboard-card">
        <h3>📋 Appeals (<?php echo $total; ?>)</h3>
        
        <?php if (empty($appeals)): ?>
        <div style="text-align: center; padding: 3rem; color: #666;">
            <p style="font-size: 3rem; margin-bottom: 1rem;">📭</p>
            <p style="font-size: 1.25rem;">No appeals found.</p>
            <p>Students haven't filed any grade appeals for your assignments yet.</p>
        </div>
        <?php else: ?>
        
        <div class="table-container" style="max-height: 700px; overflow-y: auto;">
            <?php foreach ($appeals as $appeal): ?>
            <div class="appeal-card" style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; background: <?php 
                echo $appeal['appeal_status'] === 'pending' ? '#fffbeb' : ($appeal['appeal_status'] === 'approved' ? '#f0fdf4' : '#fef2f2'); 
            ?>; border-left: 4px solid <?php 
                echo $appeal['appeal_status'] === 'pending' ? '#f59e0b' : ($appeal['appeal_status'] === 'approved' ? '#10b981' : '#ef4444'); 
            ?>;">
                <div style="display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 1.5rem;">
                    <!-- Left: Appeal Info -->
                    <div style="flex: 1; min-width: 320px;">
                        <!-- Status & Course Badge -->
                        <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem; flex-wrap: wrap;">
                            <span class="status-badge" style="padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; background: <?php 
                                echo $appeal['appeal_status'] === 'pending' ? '#fef3c7' : ($appeal['appeal_status'] === 'approved' ? '#d1fae5' : '#fee2e2'); 
                            ?>; color: <?php 
                                echo $appeal['appeal_status'] === 'pending' ? '#d97706' : ($appeal['appeal_status'] === 'approved' ? '#059669' : '#dc2626'); 
                            ?>;">
                                <?php 
                                    $statusIcon = $appeal['appeal_status'] === 'pending' ? '⏳' : ($appeal['appeal_status'] === 'approved' ? '✅' : '❌');
                                    echo $statusIcon . ' ' . ucfirst($appeal['appeal_status']); 
                                ?>
                            </span>
                            <span style="padding: 0.25rem 0.5rem; background: rgba(59, 130, 246, 0.1); color: #3b82f6; border-radius: 4px; font-size: 0.75rem; font-weight: 600;">
                                <?php echo htmlspecialchars($appeal['course_code']); ?>
                            </span>
                            <span style="font-size: 0.75rem; color: #666;">
                                Appeal #<?php echo $appeal['appeal_id']; ?>
                            </span>
                        </div>
                        
                        <!-- Assignment Name -->
                        <h4 style="margin: 0 0 0.75rem 0; font-size: 1.1rem; color: #1f2937;">
                            📝 <?php echo htmlspecialchars($appeal['assignment_name']); ?>
                        </h4>
                        
                        <!-- Student & Grade Info -->
                        <div style="display: grid; gap: 0.5rem; font-size: 0.9rem; color: #4b5563; margin-bottom: 1rem;">
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <span><span>👤</span>
                                <strong>Student:</strong> 
                                <?php echo htmlspecialchars($appeal['student_name']); ?> 
                                <span style="color: #9ca3af;">(<?php echo htmlspecialchars($appeal['student_account']); ?>)</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <span>📊</span>
                                <strong>Original Score:</strong> 
                                <span style="font-size: 1.1rem; font-weight: bold; color: #3b82f6;"><?php echo number_format($appeal['original_score'], 1); ?></span>
                                <span style="color: #9ca3af;">/ 100</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <span>📅</span>
                                <strong>Submitted:</strong> 
                                <?php echo date('Y-m-d H:i', strtotime($appeal['appeal_submission_time'])); ?>
                            </div>
                        </div>
                        
                        <!-- Appeal Reason -->
                        <div style="margin-bottom: 1rem;">
                            <div style="font-weight: 600; margin-bottom: 0.5rem; color: #374151;">📄 Appeal Reason:</div>
                            <div style="background: white; border: 1px solid #e5e7eb; border-radius: 6px; padding: 1rem; max-height: 150px; overflow-y: auto; font-size: 0.9rem; line-height: 1.6; color: #4b5563;">
                                <?php echo nl2br(htmlspecialchars($appeal['appeal_reason'])); ?>
                            </div>
                        </div>
                        
                        <!-- Supporting Materials -->
                        <?php if (!empty($appeal['appeal_materials'])): ?>
                        <div style="margin-bottom: 1rem;">
                            <div style="font-weight: 600; margin-bottom: 0.5rem; color: #374151;">📎 Supporting Materials:</div>
                            <div style="background: white; border: 1px solid #e5e7eb; border-radius: 6px; padding: 1rem; max-height: 100px; overflow-y: auto; font-size: 0.9rem; line-height: 1.6; color: #4b5563;">
                                <?php echo nl2br(htmlspecialchars($appeal['appeal_materials'])); ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Review Result (if already reviewed) -->
                        <?php if ($appeal['review_time']): ?>
                        <div style="background: linear-gradient(135deg, #e0e7ff 0%, #c7d2fe 100%); border-radius: 8px; padding: 1rem; margin-top: 1rem;">
                            <div style="font-weight: 600; margin-bottom: 0.5rem; color: #4338ca;">
                                📋 Review Decision
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <strong>Result:</strong>
                                <span style="padding: 0.25rem 0.5rem; border-radius: 4px; font-weight: 600; background: <?php echo $appeal['review_result'] === 'approve' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $appeal['review_result'] === 'approve' ? '#059669' : '#dc2626'; ?>;">
                                    <?php echo $appeal['review_result'] === 'approve' ? '✅ Approved' : '❌ Rejected'; ?>
                                </span>
                            </div>
                            <div style="font-size: 0.85rem; color: #6366f1;">
                                Reviewed on: <?php echo date('Y-m-d H:i', strtotime($appeal['review_time'])); ?>
                            </div>
                            <?php if (!empty($appeal['review_remarks_result'])): ?>
                            <div style="margin-top: 0.75rem; padding-top: 0.75rem; border-top: 1px solid rgba(99, 102, 241, 0.2);">
                                <strong>Remarks:</strong>
                                <div style="margin-top: 0.25rem; color: #4b5563;">
                                    <?php echo nl2br(htmlspecialchars($appeal['review_remarks_result'])); ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Right: Review Form (only for pending appeals) -->
                    <?php if ($appeal['appeal_status'] === 'pending'): ?>
                    <div style="min-width: 300px; max-width: 350px; background: white; border: 2px solid #e5e7eb; border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
                        <h4 style="margin: 0 0 1rem 0; padding-bottom: 0.75rem; border-bottom: 2px solid #e5e7eb; color: #1f2937;">
                            ✏️ Submit Review
                        </h4>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="review">
                            <input type="hidden" name="appeal_id" value="<?php echo $appeal['appeal_id']; ?>">
                            
                            <!-- Decision -->
                            <div style="margin-bottom: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #374151;">
                                    Decision <span style="color: #ef4444;">*</span>
                                </label>
                                <select name="review_result" required style="width: 100%; padding: 0.75rem; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 1rem; box-sizing: border-box; background: white; cursor: pointer;">
                                    <option value="">-- Select Decision --</option>
                                    <option value="approve">✅ Approve Appeal</option>
                                    <option value="reject">❌ Reject Appeal</option>
                                </select>
                            </div>
                            
                            <!-- New Score (optional, for approve) -->
                            <div style="margin-bottom: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #374151;">
                                    New Score <span style="color: #9ca3af; font-weight: normal;">(if approving)</span>
                                </label>
                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="number" name="new_score" min="0" max="100" step="0.1"
                                           placeholder="<?php echo $appeal['original_score']; ?>"
                                           style="flex: 1; padding: 0.75rem; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 1rem; box-sizing: border-box;">
                                    <span style="color: #666;">/ 100</span>
                                </div>
                                <small style="color: #9ca3af;">Leave blank to keep original score</small>
                            </div>
                            
                            <!-- Remarks -->
                            <div style="margin-bottom: 1.5rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #374151;">
                                    Remarks for Student
                                </label>
                                <textarea name="review_remarks" rows="4" 
                                          placeholder="Enter feedback or explanation for your decision..."
                                          style="width: 100%; padding: 0.75rem; border: 2px solid #e5e7eb; border-radius: 8px; resize: vertical; box-sizing: border-box; min-height: 100px; max-height: 200px; font-size: 0.9rem;"></textarea>
                            </div>
                            
                            <!-- Submit Button -->
                            <button type="submit" class="btn-primary" style="width: 100%; padding: 0.875rem; font-size: 1rem; font-weight: 600; border-radius: 8px;">
                                📤 Submit Review
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
            <?php if ($page > 1): ?>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn-secondary" style="padding: 0.5rem 1rem;">← Previous</a>
            <?php endif; ?>
            
            <span style="padding: 0.5rem 1rem; color: #666;">
                Page <?php echo $page; ?> of <?php echo $totalPages; ?>
            </span>
            
            <?php if ($page < $totalPages): ?>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn-secondary" style="padding: 0.5rem 1rem;">Next →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php endif; ?>
    </div>
</div>

<style>
.table-container {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}

.table-container::-webkit-scrollbar {
    width: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}

.appeal-card {
    transition: transform 0.2s, box-shadow 0.2s;
}

.appeal-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

textarea {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}

textarea::-webkit-scrollbar {
    width: 6px;
}

textarea::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
}

textarea::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 3px;
}

select:focus, input:focus, textarea:focus {
    outline: none;
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}

@media (max-width: 768px) {
    .appeal-card > div {
        flex-direction: column;
    }
    
    .appeal-card > div > div:last-child {
        max-width: 100%;
        min-width: 100%;
    }
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

<?php
require_once __DIR__ . '/config/course_database.php';

$error = '';
$success = '';
$pageTitle = 'Course Management System - Register';

// Redirect if already logged in
if (isCourseLoggedIn()) {
    header('Location: course_index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $account = $_POST['account'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $user_type = $_POST['user_type'] ?? '';
    
    // Additional fields based on user type
    $grade_level = $_POST['grade_level'] ?? '';
    $major = $_POST['major'] ?? '';
    $department = $_POST['department'] ?? '';
    $contact_info = $_POST['contact_info'] ?? '';
    
    // Validation
    if (empty($name) || empty($account) || empty($password) || empty($user_type)) {
        $error = 'All required fields must be filled';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } else {
        $conn = getCourseDBConnection();
        
        // Determine table and fields based on user type
        $table = '';
        $id_field = '';
        $fields = [];
        $values = [];
        $types = '';
        
        switch ($user_type) {
            case 'student':
                if (empty($grade_level) || empty($major)) {
                    $error = 'Grade level and major are required for students';
                    break;
                }
                $table = 'students';
                $id_field = 'student_id';
                $fields = ['name', 'account', 'password', 'grade_level', 'major', 'contact_info'];
                // 直接存储明文密码
                $values = [$name, $account, $password, $grade_level, $major, $contact_info];
                $types = 'ssssss';
                break;
            case 'instructor':
                if (empty($department)) {
                    $error = 'Department is required for instructors';
                    break;
                }
                $table = 'instructors';
                $id_field = 'instructor_id';
                $fields = ['name', 'account', 'password', 'department', 'subjects_taught', 'contact_info'];
                // 直接存储明文密码
                $values = [$name, $account, $password, $department, '', $contact_info];
                $types = 'ssssss';
                break;
            case 'administrator':
                $table = 'administrators';
                $id_field = 'admin_id';
                $fields = ['name', 'account', 'password', 'permission_level', 'contact_info'];
                // 直接存储明文密码
                $values = [$name, $account, $password, 'normal', $contact_info];
                $types = 'sssss';
                break;
            default:
                $error = 'Invalid user type selected';
                break;
        }
        
        // Check if we have a valid table set
        if (empty($table) && empty($error)) {
            $error = 'Please select a valid user type';
        }
        
        if ($table && empty($error)) {
            // Check if account exists
            $checkStmt = $conn->prepare("SELECT $id_field FROM $table WHERE account = ?");
            $checkStmt->bind_param("s", $account);
            $checkStmt->execute();
            if ($checkStmt->get_result()->num_rows > 0) {
                $error = 'Account already exists. Please choose a different account name.';
            } else {
                // Insert new user
                $fieldList = implode(', ', $fields);
                $placeholders = implode(', ', array_fill(0, count($fields), '?'));
                $insertStmt = $conn->prepare("INSERT INTO $table ($fieldList) VALUES ($placeholders)");
                $insertStmt->bind_param($types, ...$values);
                
                if ($insertStmt->execute()) {
                    $success = 'Registration successful! You can now login.';
                } else {
                    // Show detailed error for debugging
                    $dbError = $insertStmt->error;
                    $error = 'Registration failed. Error: ' . htmlspecialchars($dbError) . '. Please check your information and try again.';
                    // Log the error for debugging (in production, log to file instead)
                    error_log("Registration error for user type $user_type: $dbError");
                }
                $insertStmt->close();
            }
            $checkStmt->close();
        }
        
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/components.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-icon">📚</div>
                <h1>Create Account</h1>
                <p>Register for Course Management System</p>
            </div>
            <form method="POST" class="login-form" id="registerForm">
                <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                <div class="form-group">
                    <label>User Type</label>
                    <select name="user_type" id="user_type" required onchange="updateFormFields()">
                        <option value="">Select User Type</option>
                        <option value="student">Student</option>
                        <option value="instructor">Instructor</option>
                        <!-- <option value="administrator">Administrator</option> -->
                    </select>
                </div>
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" placeholder="Enter full name" required>
                </div>
                <div class="form-group">
                    <label>Account</label>
                    <input type="text" name="account" placeholder="Enter account username" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter password" required>
                </div>
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="confirm_password" placeholder="Confirm password" required>
                </div>
                <div class="form-group" id="student_fields" style="display: none;">
                    <label>Grade Level</label>
                    <select name="grade_level">
                        <option value="">Select Grade Level</option>
                        <option value="Freshman">Freshman</option>
                        <option value="Sophomore">Sophomore</option>
                        <option value="Junior">Junior</option>
                        <option value="Senior">Senior</option>
                        <option value="Graduate">Graduate</option>
                    </select>
                </div>
                <div class="form-group" id="student_fields2" style="display: none;">
                    <label>Major</label>
                    <input type="text" name="major" placeholder="Enter major">
                </div>
                <div class="form-group" id="instructor_fields" style="display: none;">
                    <label>Department</label>
                    <input type="text" name="department" placeholder="Enter department">
                </div>
                <div class="form-group">
                    <label>Contact Information</label>
                    <input type="text" name="contact_info" placeholder="Email or phone">
                </div>
                <button type="submit" class="login-button">Register</button>
                <div class="login-footer">
                    <p>Already have an account? <a href="course_login.php">Login here</a></p>
                </div>
            </form>
        </div>
    </div>
    <script>
    function updateFormFields() {
        const userType = document.getElementById('user_type').value;
        const studentFields = document.querySelectorAll('#student_fields, #student_fields2');
        const instructorFields = document.getElementById('instructor_fields');
        
        // Hide all
        studentFields.forEach(f => f.style.display = 'none');
        if (instructorFields) instructorFields.style.display = 'none';
        
        // Show relevant fields
        if (userType === 'student') {
            studentFields.forEach(f => {
                f.style.display = 'block';
                const input = f.querySelector('select, input');
                if (input) input.required = true;
            });
        } else if (userType === 'instructor') {
            if (instructorFields) {
                instructorFields.style.display = 'block';
                const input = instructorFields.querySelector('input');
                if (input) input.required = true;
            }
        }
    }
    </script>
</body>
</html>

-- ============================================
-- Course and Assignment Management System
-- Complete Database Schema (All-in-One)
-- ============================================
-- This file includes:
-- 1. Database creation
-- 2. All entity tables (13 total)
-- 3. All relationship tables
-- 4. All triggers
-- 5. Initial sample data
-- ============================================

CREATE DATABASE IF NOT EXISTS course_management_system;
USE course_management_system;

-- ============================================
-- ENTITY SETS (13 total)
-- ============================================

-- 1. Students table
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    account VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    grade_level VARCHAR(20) NOT NULL,
    major VARCHAR(100) NOT NULL,
    contact_info VARCHAR(255),
    avatar LONGBLOB NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_account (account),
    INDEX idx_grade_level (grade_level),
    INDEX idx_major (major)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Instructors table
CREATE TABLE instructors (
    instructor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    account VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    department VARCHAR(100) NOT NULL,
    subjects_taught TEXT,
    contact_info VARCHAR(255),
    avatar LONGBLOB NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_account (account),
    INDEX idx_department (department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Administrators table
CREATE TABLE administrators (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    account VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    permission_level ENUM('super', 'normal') DEFAULT 'normal',
    contact_info VARCHAR(255),
    avatar LONGBLOB NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_account (account),
    INDEX idx_permission_level (permission_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Courses table
CREATE TABLE courses (
    course_code VARCHAR(20) PRIMARY KEY,
    course_category ENUM('MR', 'ME', 'GE', 'FE') NOT NULL DEFAULT 'MR',
    course_name VARCHAR(200) NOT NULL,
    credit_hours INT NOT NULL,
    course_description TEXT,
    semester_offered VARCHAR(50),
    course_status ENUM('active', 'archived', 'draft') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course_name (course_name),
    INDEX idx_course_category (course_category),
    INDEX idx_semester (semester_offered),
    INDEX idx_status (course_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Assignments table
CREATE TABLE assignments (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    assignment_name VARCHAR(200) NOT NULL,
    assignment_description TEXT,
    release_time DATETIME NOT NULL,
    deadline DATETIME NOT NULL,
    requirements TEXT,
    course_code VARCHAR(20) NOT NULL,
    instructor_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE,
    INDEX idx_course_code (course_code),
    INDEX idx_instructor_id (instructor_id),
    INDEX idx_deadline (deadline)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Assignment Submissions table
CREATE TABLE assignment_submissions (
    submission_id INT AUTO_INCREMENT PRIMARY KEY,
    submission_time DATETIME NOT NULL,
    submission_content TEXT NOT NULL,
    submission_status ENUM('submitted', 'late', 'graded') DEFAULT 'submitted',
    student_id INT NOT NULL,
    assignment_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (assignment_id) REFERENCES assignments(assignment_id) ON DELETE CASCADE,
    INDEX idx_student_id (student_id),
    INDEX idx_assignment_id (assignment_id),
    INDEX idx_status (submission_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Grades table
CREATE TABLE grades (
    grade_id INT AUTO_INCREMENT PRIMARY KEY,
    score DECIMAL(5,2) NOT NULL,
    grading_time DATETIME NOT NULL,
    grading_remarks TEXT,
    submission_id INT NOT NULL,
    assignment_id INT NOT NULL,
    student_id INT NOT NULL,
    instructor_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (submission_id) REFERENCES assignment_submissions(submission_id) ON DELETE CASCADE,
    FOREIGN KEY (assignment_id) REFERENCES assignments(assignment_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE,
    INDEX idx_submission_id (submission_id),
    INDEX idx_assignment_id (assignment_id),
    INDEX idx_student_id (student_id),
    INDEX idx_instructor_id (instructor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Grade Appeals table
CREATE TABLE grade_appeals (
    appeal_id INT AUTO_INCREMENT PRIMARY KEY,
    appeal_reason TEXT NOT NULL,
    appeal_submission_time DATETIME NOT NULL,
    appeal_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    appeal_materials TEXT,
    student_id INT NOT NULL,
    grade_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (grade_id) REFERENCES grades(grade_id) ON DELETE CASCADE,
    INDEX idx_student_id (student_id),
    INDEX idx_grade_id (grade_id),
    INDEX idx_status (appeal_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. Announcements table
CREATE TABLE announcements (
    announcement_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    release_time DATETIME NOT NULL,
    publisher_type ENUM('instructor', 'administrator') NOT NULL,
    publisher_id INT NOT NULL,
    course_code VARCHAR(20),
    announcement_type ENUM('course_notification', 'system_notification') DEFAULT 'course_notification',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    INDEX idx_course_code (course_code),
    INDEX idx_release_time (release_time),
    INDEX idx_type (announcement_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. Suppliers table (must be created before textbooks)
CREATE TABLE suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    contact_info VARCHAR(255),
    textbook_types_supplied TEXT,
    cooperation_status ENUM('active', 'suspended', 'pending') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (cooperation_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. Textbooks table
CREATE TABLE textbooks (
    textbook_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(100),
    isbn VARCHAR(20),
    publisher VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    course_code VARCHAR(20),
    supplier_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE SET NULL,
    INDEX idx_course_code (course_code),
    INDEX idx_isbn (isbn),
    INDEX idx_supplier_id (supplier_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. Textbook Orders table
CREATE TABLE textbook_orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    order_time DATETIME NOT NULL,
    order_status ENUM('pending', 'confirmed', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    quantity_purchased INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    student_id INT NOT NULL,
    textbook_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (textbook_id) REFERENCES textbooks(textbook_id) ON DELETE CASCADE,
    INDEX idx_student_id (student_id),
    INDEX idx_textbook_id (textbook_id),
    INDEX idx_status (order_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. Teaching Evaluations table
CREATE TABLE teaching_evaluations (
    evaluation_id INT AUTO_INCREMENT PRIMARY KEY,
    evaluation_content TEXT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    evaluation_time DATETIME NOT NULL,
    student_id INT NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    instructor_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE,
    INDEX idx_student_id (student_id),
    INDEX idx_course_code (course_code),
    INDEX idx_instructor_id (instructor_id),
    INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- RELATIONSHIP SETS
-- ============================================

-- 1. Enrollments (Student-Course relationship)
CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    enrollment_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    enrollment_status ENUM('enrolled', 'dropped') DEFAULT 'enrolled',
    time_conflict BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, course_code),
    INDEX idx_student_id (student_id),
    INDEX idx_course_code (course_code),
    INDEX idx_status (enrollment_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Teaching (Instructor-Course relationship)
CREATE TABLE teaching (
    teaching_id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_id INT NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    teaching_semester VARCHAR(50),
    teaching_class VARCHAR(50),
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    UNIQUE KEY unique_teaching (instructor_id, course_code),
    INDEX idx_instructor_id (instructor_id),
    INDEX idx_course_code (course_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Course Management (Admin-Course relationship)
CREATE TABLE course_management (
    management_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    operation_time DATETIME NOT NULL,
    operation_type ENUM('publish', 'archive') NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES administrators(admin_id) ON DELETE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    INDEX idx_admin_id (admin_id),
    INDEX idx_course_code (course_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Appeal Reviews (Instructor reviews appeals)
CREATE TABLE appeal_reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    instructor_id INT NOT NULL,
    appeal_id INT NOT NULL,
    review_time DATETIME NOT NULL,
    review_result ENUM('approve', 'reject') NOT NULL,
    review_remarks TEXT,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE CASCADE,
    FOREIGN KEY (appeal_id) REFERENCES grade_appeals(appeal_id) ON DELETE CASCADE,
    INDEX idx_instructor_id (instructor_id),
    INDEX idx_appeal_id (appeal_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Supplier Approvals (Admin approves suppliers)
CREATE TABLE supplier_approvals (
    approval_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    supplier_id INT NOT NULL,
    approval_time DATETIME NOT NULL,
    approval_result ENUM('approve', 'reject') NOT NULL,
    approval_remarks TEXT,
    FOREIGN KEY (admin_id) REFERENCES administrators(admin_id) ON DELETE CASCADE,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE CASCADE,
    INDEX idx_admin_id (admin_id),
    INDEX idx_supplier_id (supplier_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Evaluation Releases (Admin releases evaluations)
CREATE TABLE evaluation_releases (
    release_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    evaluation_id INT NOT NULL,
    release_time DATETIME NOT NULL,
    collection_deadline DATETIME NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES administrators(admin_id) ON DELETE CASCADE,
    FOREIGN KEY (evaluation_id) REFERENCES teaching_evaluations(evaluation_id) ON DELETE CASCADE,
    INDEX idx_admin_id (admin_id),
    INDEX idx_evaluation_id (evaluation_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Course Schedules table
CREATE TABLE course_schedules (
    schedule_id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL,
    day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    INDEX idx_course_code (course_code),
    INDEX idx_day_time (day_of_week, start_time),
    UNIQUE KEY unique_course_time (course_code, day_of_week, start_time, end_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. System Settings table
CREATE TABLE system_settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value VARCHAR(255) NOT NULL,
    description TEXT,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES administrators(admin_id) ON DELETE SET NULL,
    INDEX idx_setting_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- DATABASE TRIGGERS
-- ============================================

DELIMITER $$

-- 1. Assignment deadline must be after release time
CREATE TRIGGER check_assignment_deadline_before_insert
BEFORE INSERT ON assignments
FOR EACH ROW
BEGIN
    IF NEW.deadline <= NEW.release_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Assignment deadline must be after release time';
    END IF;
END$$

CREATE TRIGGER check_assignment_deadline_before_update
BEFORE UPDATE ON assignments
FOR EACH ROW
BEGIN
    IF NEW.deadline <= NEW.release_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Assignment deadline must be after release time';
    END IF;
END$$

-- 2. Grade score must be between 0 and 100
CREATE TRIGGER check_grade_score_before_insert
BEFORE INSERT ON grades
FOR EACH ROW
BEGIN
    IF NEW.score < 0 OR NEW.score > 100 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Grade score must be between 0 and 100';
    END IF;
END$$

CREATE TRIGGER check_grade_score_before_update
BEFORE UPDATE ON grades
FOR EACH ROW
BEGIN
    IF NEW.score < 0 OR NEW.score > 100 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Grade score must be between 0 and 100';
    END IF;
END$$

-- 3. Submission time cannot be earlier than assignment release time
CREATE TRIGGER check_submission_time_before_insert
BEFORE INSERT ON assignment_submissions
FOR EACH ROW
BEGIN
    DECLARE assignment_release_time DATETIME;
    
    SELECT release_time INTO assignment_release_time
    FROM assignments
    WHERE assignment_id = NEW.assignment_id;
    
    IF NEW.submission_time < assignment_release_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Submission time cannot be earlier than assignment release time';
    END IF;
END$$

CREATE TRIGGER check_submission_time_before_update
BEFORE UPDATE ON assignment_submissions
FOR EACH ROW
BEGIN
    DECLARE assignment_release_time DATETIME;
    
    SELECT release_time INTO assignment_release_time
    FROM assignments
    WHERE assignment_id = NEW.assignment_id;
    
    IF NEW.submission_time < assignment_release_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Submission time cannot be earlier than assignment release time';
    END IF;
END$$

-- 4. Course schedule end time must be after start time
CREATE TRIGGER check_schedule_time_before_insert
BEFORE INSERT ON course_schedules
FOR EACH ROW
BEGIN
    IF NEW.end_time <= NEW.start_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Course schedule end time must be after start time';
    END IF;
END$$

CREATE TRIGGER check_schedule_time_before_update
BEFORE UPDATE ON course_schedules
FOR EACH ROW
BEGIN
    IF NEW.end_time <= NEW.start_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Course schedule end time must be after start time';
    END IF;
END$$

-- 5. Textbook order quantity validation
CREATE TRIGGER check_textbook_order_quantity_before_insert
BEFORE INSERT ON textbook_orders
FOR EACH ROW
BEGIN
    DECLARE available_stock INT;
    
    SELECT stock_quantity INTO available_stock
    FROM textbooks
    WHERE textbook_id = NEW.textbook_id;
    
    IF NEW.quantity_purchased > available_stock THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Order quantity cannot exceed available stock';
    END IF;
    
    IF NEW.quantity_purchased <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Order quantity must be greater than 0';
    END IF;
END$$

CREATE TRIGGER check_textbook_order_quantity_before_update
BEFORE UPDATE ON textbook_orders
FOR EACH ROW
BEGIN
    DECLARE available_stock INT;
    
    SELECT stock_quantity INTO available_stock
    FROM textbooks
    WHERE textbook_id = NEW.textbook_id;
    
    IF NEW.quantity_purchased > available_stock THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Order quantity cannot exceed available stock';
    END IF;
    
    IF NEW.quantity_purchased <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Order quantity must be greater than 0';
    END IF;
END$$

-- 6. Evaluation collection deadline must be after release time
CREATE TRIGGER check_evaluation_deadline_before_insert
BEFORE INSERT ON evaluation_releases
FOR EACH ROW
BEGIN
    IF NEW.collection_deadline <= NEW.release_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Evaluation collection deadline must be after release time';
    END IF;
END$$

CREATE TRIGGER check_evaluation_deadline_before_update
BEFORE UPDATE ON evaluation_releases
FOR EACH ROW
BEGIN
    IF NEW.collection_deadline <= NEW.release_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Evaluation collection deadline must be after release time';
    END IF;
END$$

-- 7. Credit hours must be greater than 0
CREATE TRIGGER check_credit_hours_before_insert
BEFORE INSERT ON courses
FOR EACH ROW
BEGIN
    IF NEW.credit_hours <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Credit hours must be greater than 0';
    END IF;
END$$

CREATE TRIGGER check_credit_hours_before_update
BEFORE UPDATE ON courses
FOR EACH ROW
BEGIN
    IF NEW.credit_hours <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Credit hours must be greater than 0';
    END IF;
END$$

-- 8. Textbook price cannot be negative
CREATE TRIGGER check_textbook_price_before_insert
BEFORE INSERT ON textbooks
FOR EACH ROW
BEGIN
    IF NEW.price < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Textbook price cannot be negative';
    END IF;
END$$

CREATE TRIGGER check_textbook_price_before_update
BEFORE UPDATE ON textbooks
FOR EACH ROW
BEGIN
    IF NEW.price < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Textbook price cannot be negative';
    END IF;
END$$

-- 9. Textbook stock cannot be negative
CREATE TRIGGER check_textbook_stock_before_insert
BEFORE INSERT ON textbooks
FOR EACH ROW
BEGIN
    IF NEW.stock_quantity < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Textbook stock quantity cannot be negative';
    END IF;
END$$

CREATE TRIGGER check_textbook_stock_before_update
BEFORE UPDATE ON textbooks
FOR EACH ROW
BEGIN
    IF NEW.stock_quantity < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Textbook stock quantity cannot be negative';
    END IF;
END$$

-- 10. Grading time cannot be earlier than submission time
CREATE TRIGGER check_grading_time_before_insert
BEFORE INSERT ON grades
FOR EACH ROW
BEGIN
    DECLARE submission_time DATETIME;
    
    SELECT s.submission_time INTO submission_time
    FROM assignment_submissions s
    WHERE s.submission_id = NEW.submission_id;
    
    IF NEW.grading_time < submission_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Grading time cannot be earlier than submission time';
    END IF;
END$$

CREATE TRIGGER check_grading_time_before_update
BEFORE UPDATE ON grades
FOR EACH ROW
BEGIN
    DECLARE submission_time DATETIME;
    
    SELECT s.submission_time INTO submission_time
    FROM assignment_submissions s
    WHERE s.submission_id = NEW.submission_id;
    
    IF NEW.grading_time < submission_time THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Grading time cannot be earlier than submission time';
    END IF;
END$$

DELIMITER ;

-- ============================================
-- INITIAL DATA
-- ============================================

-- Default administrator (password: password)
INSERT INTO administrators (name, account, password, permission_level, contact_info) VALUES
('System Admin', 'admin', 'password', 'super', 'admin@university.edu');

-- Sample instructor (password: password)
INSERT INTO instructors (name, account, password, department, subjects_taught, contact_info) VALUES
('Dr. John Smith', 'instructor1', 'password', 'Computer Science', 'Programming, Database', 'instructor1@university.edu');

-- Sample student (password: password)
INSERT INTO students (name, account, password, grade_level, major, contact_info) VALUES
('Alice Johnson', 'student1', 'password', 'Sophomore', 'Computer Science', 'student1@university.edu');

-- Default system setting (enrollment channel enabled)
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('enrollment_enabled', '1', 'Course enrollment channel status (1=enabled/open, 0=disabled/closed)');

-- ============================================
-- END OF SCHEMA
-- ============================================


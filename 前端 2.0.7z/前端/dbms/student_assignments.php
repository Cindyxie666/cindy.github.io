<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Assignments';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();
$courseCode = $_GET['course'] ?? '';

// Get assignments for enrolled courses
$query = "SELECT a.*, c.course_name, 
          (SELECT COUNT(*) FROM assignment_submissions WHERE assignment_id = a.assignment_id AND student_id = ?) as submitted
          FROM assignments a
          JOIN courses c ON a.course_code = c.course_code
          JOIN enrollments e ON c.course_code = e.course_code
          WHERE e.student_id = ? AND e.enrollment_status = 'enrolled'";
$params = [$studentId, $studentId];
$types = 'ii';

if ($courseCode) {
    $query .= " AND a.course_code = ?";
    $params[] = $courseCode;
    $types .= 's';
}

$query .= " ORDER BY a.deadline ASC";

$stmt = $conn->prepare($query);
if (count($params) > 2) {
    $stmt->bind_param($types, ...$params);
} else {
    $stmt->bind_param($types, $params[0], $params[1]);
}
$stmt->execute();
$assignments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📝 Assignments</h2>
            <p>View and submit assignments</p>
        </div>
    </div>

    <?php if ($courseCode): ?>
    <div class="info-box">
        <p>Showing assignments for: <strong><?php echo htmlspecialchars($courseCode); ?></strong></p>
        <a href="student_assignments.php" class="action-btn">View All Assignments</a>
    </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Assignment Name</th>
                    <th>Course</th>
                    <th>Release Time</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($assignments as $assignment): ?>
                <?php
                $now = new DateTime();
                $deadline = new DateTime($assignment['deadline']);
                $isOverdue = $now > $deadline;
                $status = $assignment['submitted'] > 0 ? 'Submitted' : ($isOverdue ? 'Overdue' : 'Pending');
                ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($assignment['assignment_name']); ?></strong></td>
                    <td><?php echo htmlspecialchars($assignment['course_name']); ?></td>
                    <td><?php echo date('Y-m-d H:i', strtotime($assignment['release_time'])); ?></td>
                    <td class="<?php echo $isOverdue ? 'text-danger' : ''; ?>">
                        <?php echo date('Y-m-d H:i', strtotime($assignment['deadline'])); ?>
                    </td>
                    <td>
                        <span class="status-badge <?php echo strtolower($status); ?>">
                            <?php echo $status; ?>
                        </span>
                    </td>
                    <td>
                        <a href="student_submit_assignment.php?id=<?php echo $assignment['assignment_id']; ?>" class="action-btn">
                            <?php echo $assignment['submitted'] > 0 ? 'View/Update' : 'Submit'; ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


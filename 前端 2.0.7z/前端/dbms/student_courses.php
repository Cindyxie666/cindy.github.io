<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'My Courses';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

// Get enrolled courses
$query = "SELECT c.*, e.enrollment_time, e.enrollment_status, 
          (SELECT COUNT(*) FROM assignments WHERE course_code = c.course_code) as assignment_count
          FROM courses c
          JOIN enrollments e ON c.course_code = e.course_code
          WHERE e.student_id = ? AND e.enrollment_status = 'enrolled'
          ORDER BY c.course_code";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$courses = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📚 My Courses</h2>
            <p>View your enrolled courses and deadlines</p>
        </div>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Credit Hours</th>
                    <th>Semester</th>
                    <th>Assignments</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $course): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($course['course_code']); ?></strong></td>
                    <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                    <td><?php echo $course['credit_hours']; ?></td>
                    <td><?php echo htmlspecialchars($course['semester_offered'] ?? 'N/A'); ?></td>
                    <td><?php echo $course['assignment_count']; ?></td>
                    <td>
                        <span class="status-badge <?php echo $course['course_status']; ?>">
                            <?php echo ucfirst($course['course_status']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="student_assignments.php?course=<?php echo urlencode($course['course_code']); ?>" class="action-btn">
                            View Assignments
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


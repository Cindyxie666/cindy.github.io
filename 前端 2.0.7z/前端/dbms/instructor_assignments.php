<?php
require_once __DIR__ . '/config/course_database.php';
requireInstructor();

$pageTitle = 'Assignments';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$instructorId = getCurrentUserId();
$courseCode = $_GET['course'] ?? '';

// Handle create assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $assignmentName = $_POST['assignment_name'] ?? '';
    $description = $_POST['assignment_description'] ?? '';
    $releaseTime = $_POST['release_time'] ?? '';
    $deadline = $_POST['deadline'] ?? '';
    $requirements = $_POST['requirements'] ?? '';
    $courseCode = $_POST['course_code'] ?? '';
    
    if ($assignmentName && $releaseTime && $deadline && $courseCode) {
        $stmt = $conn->prepare("INSERT INTO assignments (assignment_name, assignment_description, release_time, deadline, requirements, course_code, instructor_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssi", $assignmentName, $description, $releaseTime, $deadline, $requirements, $courseCode, $instructorId);
        $stmt->execute();
        $stmt->close();
    }
}

// Get assignments for courses taught by this instructor
$query = "SELECT a.*, c.course_name,
          (SELECT COUNT(*) FROM assignment_submissions WHERE assignment_id = a.assignment_id) as submission_count
          FROM assignments a
          JOIN courses c ON a.course_code = c.course_code
          WHERE a.instructor_id = ?";
$params = [$instructorId];
$types = 'i';

if ($courseCode) {
    $query .= " AND a.course_code = ?";
    $params[] = $courseCode;
    $types .= 's';
}

$query .= " ORDER BY a.deadline ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$assignments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get courses taught by instructor
$coursesStmt = $conn->prepare("SELECT DISTINCT c.course_code, c.course_name FROM courses c JOIN teaching t ON c.course_code = t.course_code WHERE t.instructor_id = ?");
$coursesStmt->bind_param("i", $instructorId);
$coursesStmt->execute();
$courses = $coursesStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$coursesStmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📝 Assignments</h2>
            <p>Create and manage assignments</p>
        </div>
        <button onclick="showCreateModal()" class="btn-primary">+ Create Assignment</button>
    </div>

    <?php if ($courseCode): ?>
    <div class="info-box">
        <p>Showing assignments for: <strong><?php echo htmlspecialchars($courseCode); ?></strong></p>
        <a href="instructor_assignments.php" class="action-btn">View All Assignments</a>
    </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Assignment Name</th>
                    <th>Course</th>
                    <th>Release Time</th>
                    <th>Deadline</th>
                    <th>Submissions</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($assignments as $assignment): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($assignment['assignment_name']); ?></strong></td>
                    <td><?php echo htmlspecialchars($assignment['course_name']); ?></td>
                    <td><?php echo date('Y-m-d H:i', strtotime($assignment['release_time'])); ?></td>
                    <td><?php echo date('Y-m-d H:i', strtotime($assignment['deadline'])); ?></td>
                    <td><?php echo $assignment['submission_count']; ?></td>
                    <td>
                        <a href="instructor_grading.php?assignment=<?php echo $assignment['assignment_id']; ?>" class="action-btn">Grade</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Create Assignment Modal -->
<div id="createModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close" onclick="closeCreateModal()">&times;</span>
        <h2>Create Assignment</h2>
        <form method="POST">
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label>Course *</label>
                <select name="course_code" required>
                    <option value="">Select Course</option>
                    <?php foreach ($courses as $course): ?>
                    <option value="<?php echo htmlspecialchars($course['course_code']); ?>"><?php echo htmlspecialchars($course['course_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Assignment Name *</label>
                <input type="text" name="assignment_name" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="assignment_description" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Release Time *</label>
                <input type="datetime-local" name="release_time" required>
            </div>
            <div class="form-group">
                <label>Deadline *</label>
                <input type="datetime-local" name="deadline" required>
            </div>
            <div class="form-group">
                <label>Requirements</label>
                <textarea name="requirements" rows="3"></textarea>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-primary">Create Assignment</button>
                <button type="button" class="btn-secondary" onclick="closeCreateModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showCreateModal() {
    document.getElementById('createModal').style.display = 'flex';
}
function closeCreateModal() {
    document.getElementById('createModal').style.display = 'none';
}
</script>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


# Course Category System

## Overview
The course management system now includes automatic course code generation with category classification. Courses are categorized into four types: MR, ME, GE, and FE.

## Course Categories

- **MR** - Major Required (专业必修)
- **ME** - Major Elective (专业选修)
- **GE** - General Education (通识教育)
- **FE** - Free Elective (自由选修)

## Course Code Format

Course codes are automatically generated in the format: `CATEGORY-XXX`

Examples:
- `MR-001` - First Major Required course
- `ME-042` - 42nd Major Elective course
- `GE-001` - First General Education course
- `FE-100` - 100th Free Elective course

## Features

1. **Automatic Code Generation**: Course codes are automatically generated when creating a new course
2. **Sequential Numbering**: Each category maintains its own sequential numbering (001, 002, 003, ...)
3. **No Duplicates**: The system ensures no duplicate course codes within each category
4. **Ordered**: Course codes are ordered and sequential within each category

## Database Migration

To add the course category feature to an existing database, run the migration script:

```bash
mysql -u root -p course_management_system < add_course_category.sql
```

Or import through phpMyAdmin:
1. Open phpMyAdmin
2. Select `course_management_system` database
3. Go to SQL tab
4. Copy and paste the contents of `add_course_category.sql`
5. Click "Go"

## How to Create a Course

1. Log in as an instructor
2. Go to "My Courses" page
3. Click "+ Create Course" button
4. Select a category (MR, ME, GE, or FE) - **Required**
5. Fill in course details:
   - Course Name (required)
   - Credit Hours (1-6, default: 3)
   - Semester (optional)
   - Description (optional)
6. Click "Create Course"
7. The system will automatically generate a unique course code (e.g., MR-001)

## Technical Details

- Course codes are generated within a database transaction to ensure atomicity
- The system queries existing courses in the same category to find the maximum sequence number
- Each category maintains independent numbering
- Course codes are formatted with zero-padding (001, 002, ..., 099, 100, ...)

## Display

In the course list, courses are displayed with:
- Course Code (auto-generated)
- Category badge (color-coded)
- Course Name
- Other course details

Categories are color-coded:
- MR: Blue
- ME: Green
- GE: Orange
- FE: Red


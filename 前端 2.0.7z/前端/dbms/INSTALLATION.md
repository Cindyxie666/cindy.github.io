# Installation Guide - Course Management System

## Step 1: Install XAMPP

1. Download XAMPP from https://www.apachefriends.org/
2. Install XAMPP (default location: C:\xampp on Windows, /Applications/XAMPP on Mac)
3. Start Apache and MySQL services from XAMPP Control Panel

## Step 2: Setup Project

1. Copy the `php` folder to your XAMPP htdocs directory:
   - Windows: `C:\xampp\htdocs\dbms`
   - Mac: `/Applications/XAMPP/htdocs/dbms`
   - Linux: `/opt/lampp/htdocs/dbms`

2. Or create a symbolic link:
   ```bash
   # Mac/Linux
   ln -s /path/to/project/php /Applications/XAMPP/htdocs/dbms
   ```

## Step 3: Create Database

**Note**: You do NOT need to manually create the database. The `course_management_schema.sql` file will automatically create it.

### Option A: Using phpMyAdmin (Recommended)
1. Open http://localhost/phpmyadmin
2. Click "Import" tab (no need to create database first)
3. Click "Choose File" and select `course_management_schema.sql`
4. Click "Go"
5. The database `course_management_system` will be created automatically along with all tables

**Alternative method** (if you prefer to create database first):
1. Open http://localhost/phpmyadmin
2. Click "New" to create a new database named `course_management_system`
3. Select the `course_management_system` database
4. Click "Import" tab
5. Select `course_management_schema.sql` file
6. Click "Go"

### Option B: Using Command Line
```bash
# Windows (in XAMPP shell)
cd C:\xampp\mysql\bin
mysql -u root -p < C:\xampp\htdocs\dbms\course_management_schema.sql

# Mac/Linux
/Applications/XAMPP/xamppfiles/bin/mysql -u root -p < /Applications/XAMPP/htdocs/dbms/course_management_schema.sql
```

The SQL file contains `CREATE DATABASE IF NOT EXISTS course_management_system;` so it will create the database automatically.

## Step 4: Configure Database Connection

Edit `php/config/course_database.php` if your MySQL credentials are different:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // Change if you set a password
define('DB_NAME', 'course_management_system');
```

## Step 5: Generate Sample Data (Optional but Recommended)

This will generate the required large datasets:
```bash
cd /path/to/dbms
php generate_course_data.php
```

**Note**: This may take several minutes to complete as it generates:
- 10,000 students
- 500 instructors
- 1,000 courses
- 50,000 enrollments
- 10,000 assignments
- 50,000 submissions
- 30,000 grades
- 5,000 announcements
- 2,000 textbooks
- 10,000 textbook orders
- 10,000 teaching evaluations

## Step 6: Access the Application

1. Open your web browser
2. Navigate to: http://localhost/dbms/course_login.php
3. Login with default credentials:
   - Student: `student1` / `password`
   - Instructor: `instructor1` / `password`
   - Administrator: `admin` / `password`

## Troubleshooting

### Apache won't start
- Check if port 80 is already in use
- Change Apache port in XAMPP Control Panel → Config → httpd.conf

### MySQL won't start
- Check if port 3306 is already in use
- Check MySQL error logs in XAMPP

### Database connection error
- Verify MySQL is running
- Check database credentials in `config/course_database.php`
- Ensure database `course_management_system` exists

### Permission denied errors
- On Mac/Linux, ensure proper file permissions:
  ```bash
  chmod -R 755 /Applications/XAMPP/htdocs/dbms
  ```

### Page not found (404)
- Ensure files are in correct location: `htdocs/dbms/`
- Check Apache DocumentRoot setting
- Verify `.htaccess` file exists

## File Structure After Installation

```
htdocs/
└── dbms/
    ├── config/
    │   └── course_database.php
    ├── includes/
    │   ├── course_header.php
    │   └── course_footer.php
    ├── css/
    │   ├── style.css
    │   └── components.css
    ├── js/
    │   └── main.js
    ├── course_login.php
    ├── course_register.php
    ├── course_index.php
    ├── student_*.php (10 files)
    ├── instructor_*.php (6 files)
    ├── admin_*.php (4 files)
    ├── course_management_schema.sql
    └── generate_course_data.php
```

## Verification

After installation, verify:
1. ✅ Can access http://localhost/dbms/course_login.php
2. ✅ Can login with student1/password (or instructor1/admin)
3. ✅ Dashboard shows statistics
4. ✅ Students can view courses and assignments
5. ✅ Instructors can create courses and assignments
6. ✅ Administrators can manage accounts and courses
7. ✅ Database has required record counts (if data generated)

## Next Steps

1. Explore all 20+ pages
2. Test student registration
3. Test assignment submission
4. Test grading functionality
5. Test grade appeals
6. Test bookstore module
7. Test announcement system

<?php
require_once __DIR__ . '/config/course_database.php';
requireAdministrator();

$pageTitle = 'My Profile';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$adminId = getCurrentUserId();

$message = '';
$messageType = '';

// Handle avatar upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_avatar') {
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['avatar'];
        
        // Validate file type
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        $fileType = mime_content_type($file['tmp_name']);
        
        if (!in_array($fileType, $allowedTypes)) {
            $message = "Invalid file type. Only JPEG, PNG, and GIF images are allowed.";
            $messageType = "error";
        } elseif ($file['size'] > 5 * 1024 * 1024) { // 5MB limit
            $message = "File size too large. Maximum size is 5MB.";
            $messageType = "error";
        } else {
            // Read file content
            $avatarData = file_get_contents($file['tmp_name']);
            
            // Update avatar in database
            $stmt = $conn->prepare("UPDATE administrators SET avatar = ? WHERE admin_id = ?");
            $stmt->bind_param("si", $avatarData, $adminId);
            
            if ($stmt->execute()) {
                $message = "Avatar uploaded successfully!";
                $messageType = "success";
            } else {
                $message = "Error uploading avatar: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    } else {
        $message = "No file uploaded or upload error occurred.";
        $messageType = "error";
    }
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $name = $_POST['name'] ?? '';
    $account = $_POST['account'] ?? '';
    $permissionLevel = $_POST['permission_level'] ?? 'normal';
    $contactInfo = $_POST['contact_info'] ?? '';
    
    if ($name && $account) {
        // Check if account already exists for another user
        $checkStmt = $conn->prepare("SELECT admin_id FROM administrators WHERE account = ? AND admin_id != ?");
        $checkStmt->bind_param("si", $account, $adminId);
        $checkStmt->execute();
        $existing = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
        
        if (!$existing) {
            $stmt = $conn->prepare("UPDATE administrators SET name = ?, account = ?, permission_level = ?, contact_info = ? WHERE admin_id = ?");
            $stmt->bind_param("ssssi", $name, $account, $permissionLevel, $contactInfo, $adminId);
            if ($stmt->execute()) {
                // Update session username
                $_SESSION['username'] = $name;
                $message = "Profile updated successfully!";
                $messageType = "success";
            } else {
                $message = "Error updating profile: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        } else {
            $message = "Account name already exists!";
            $messageType = "error";
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    if ($currentPassword && $newPassword && $confirmPassword) {
        if ($newPassword !== $confirmPassword) {
            $message = "New passwords do not match!";
            $messageType = "error";
        } elseif (strlen($newPassword) < 6) {
            $message = "Password must be at least 6 characters long!";
            $messageType = "error";
        } else {
            // Verify current password
            $stmt = $conn->prepare("SELECT password FROM administrators WHERE admin_id = ?");
            $stmt->bind_param("i", $adminId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if ($result && password_verify($currentPassword, $result['password'])) {
                // Update password
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $updateStmt = $conn->prepare("UPDATE administrators SET password = ? WHERE admin_id = ?");
                $updateStmt->bind_param("si", $hashedPassword, $adminId);
                if ($updateStmt->execute()) {
                    $message = "Password changed successfully!";
                    $messageType = "success";
                } else {
                    $message = "Error changing password: " . $updateStmt->error;
                    $messageType = "error";
                }
                $updateStmt->close();
            } else {
                $message = "Current password is incorrect!";
                $messageType = "error";
            }
        }
    }
}

// Get current administrator information
$stmt = $conn->prepare("SELECT * FROM administrators WHERE admin_id = ?");
$stmt->bind_param("i", $adminId);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>👤 My Profile</h2>
            <p>Manage your account information and password</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 4px; background: <?php echo $messageType === 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $messageType === 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <div class="dashboard-grid">
        <!-- Avatar Section -->
        <div class="dashboard-card">
            <h3>Profile Picture</h3>
            <div style="text-align: center; margin-bottom: 1rem;">
                <img src="view_avatar.php?type=administrator&id=<?php echo $adminId; ?>" 
                     alt="Avatar" 
                     style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 3px solid #3b82f6; margin-bottom: 1rem;"
                     onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'150\' height=\'150\'%3E%3Crect fill=\'%23ddd\' width=\'150\' height=\'150\'/%3E%3Ctext fill=\'%23999\' font-family=\'sans-serif\' font-size=\'50\' dy=\'10.5\' font-weight=\'bold\' x=\'50%25\' y=\'50%25\' text-anchor=\'middle\'%3E👤%3C/text%3E%3C/svg%3E'">
            </div>
            <form method="POST" enctype="multipart/form-data" style="margin-top: 1rem;">
                <input type="hidden" name="action" value="upload_avatar">
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Upload Avatar</label>
                    <input type="file" name="avatar" accept="image/jpeg,image/jpg,image/png,image/gif" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <small style="color: #666; font-size: 0.875rem;">Max size: 5MB. Supported formats: JPEG, PNG, GIF</small>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary" style="padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">Upload Avatar</button>
                </div>
            </form>
        </div>

        <!-- Profile Information -->
        <div class="dashboard-card">
            <h3>Profile Information</h3>
            <form method="POST" style="margin-top: 1rem;">
                <input type="hidden" name="action" value="update_profile">
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Name *</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($admin['name'] ?? ''); ?>" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Account *</label>
                    <input type="text" name="account" value="<?php echo htmlspecialchars($admin['account'] ?? ''); ?>" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Permission Level *</label>
                    <select name="permission_level" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="normal" <?php echo ($admin['permission_level'] ?? 'normal') === 'normal' ? 'selected' : ''; ?>>Normal</option>
                        <option value="super" <?php echo ($admin['permission_level'] ?? 'normal') === 'super' ? 'selected' : ''; ?>>Super</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Contact Information</label>
                    <input type="text" name="contact_info" value="<?php echo htmlspecialchars($admin['contact_info'] ?? ''); ?>" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div class="form-actions" style="margin-top: 1.5rem;">
                    <button type="submit" class="btn-primary" style="padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">Update Profile</button>
                </div>
            </form>
        </div>

        <!-- Change Password -->
        <div class="dashboard-card">
            <h3>Change Password</h3>
            <form method="POST" style="margin-top: 1rem;">
                <input type="hidden" name="action" value="change_password">
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Current Password *</label>
                    <input type="password" name="current_password" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">New Password *</label>
                    <input type="password" name="new_password" required minlength="6" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <small style="color: #666; font-size: 0.875rem;">Must be at least 6 characters</small>
                </div>
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Confirm New Password *</label>
                    <input type="password" name="confirm_password" required minlength="6" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <div class="form-actions" style="margin-top: 1.5rem;">
                    <button type="submit" class="btn-primary" style="padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


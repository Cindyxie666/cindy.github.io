<?php
require_once __DIR__ . '/config/course_database.php';

echo "<h2>头像诊断测试</h2>";

$conn = getCourseDBConnection();

// 1. 检查字段类型
echo "<h3>1. 数据库字段类型</h3>";
$result = $conn->query("SHOW COLUMNS FROM students WHERE Field = 'avatar'");
$col = $result->fetch_assoc();
echo "<p>students.avatar 类型: <strong>" . $col['Type'] . "</strong></p>";

if (stripos($col['Type'], 'longblob') === false) {
    echo "<p style='color:red;'>⚠️ 需要改成 LONGBLOB！运行：</p>";
    echo "<pre>ALTER TABLE students MODIFY COLUMN avatar LONGBLOB NULL;</pre>";
}

// 2. 检查数据
echo "<h3>2. 学生头像数据</h3>";
$result = $conn->query("SELECT student_id, name, LENGTH(avatar) as size, avatar FROM students LIMIT 5");

echo "<table border='1' cellpadding='8' style='border-collapse:collapse;'>";
echo "<tr><th>ID</th><th>Name</th><th>Size</th><th>Header (hex)</th><th>Type</th><th>Preview</th></tr>";

while ($row = $result->fetch_assoc()) {
    $size = $row['size'] ?? 0;
    $header = $row['avatar'] ? bin2hex(substr($row['avatar'], 0, 8)) : 'N/A';
    
    // 判断类型
    $type = 'Unknown';
    if ($row['avatar']) {
        if (substr($row['avatar'], 0, 2) === "\xff\xd8") $type = 'JPEG';
        elseif (substr($row['avatar'], 0, 8) === "\x89PNG\r\n\x1a\n") $type = 'PNG';
        elseif (substr($row['avatar'], 0, 6) === 'GIF89a' || substr($row['avatar'], 0, 6) === 'GIF87a') $type = 'GIF';
    }
    
    echo "<tr>";
    echo "<td>" . $row['student_id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "<td>" . ($size ? number_format($size) . ' bytes' : 'NULL') . "</td>";
    echo "<td style='font-family:monospace;font-size:11px;'>" . $header . "</td>";
    echo "<td>" . $type . "</td>";
    echo "<td>";
    if ($size > 0) {
        echo "<img src='view_avatar.php?type=student&id=" . $row['student_id'] . "&t=" . time() . "' width='60' height='60' style='object-fit:cover;border-radius:50%;border:1px solid #ccc;'>";
    } else {
        echo "无头像";
    }
    echo "</td>";
    echo "</tr>";
}
echo "</table>";

$conn->close();

echo "<h3>3. 解决方案</h3>";
echo "<ol>";
echo "<li>确保 avatar 字段是 LONGBLOB 类型</li>";
echo "<li>替换 view_avatar.php 文件</li>";
echo "<li>重新上传头像</li>";
echo "<li>Ctrl+F5 强制刷新页面</li>";
echo "</ol>";
?>

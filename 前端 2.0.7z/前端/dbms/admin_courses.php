<?php
require_once __DIR__ . '/config/course_database.php';
requireAdministrator();

$pageTitle = 'Course Management';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();

$message = '';
$messageType = '';

// Handle publish/archive/delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $courseCode = $_POST['course_code'] ?? '';
    $action = $_POST['action'];
    $adminId = getCurrentUserId();
    
    if (empty($courseCode)) {
        $message = "Course code is required!";
        $messageType = "error";
    } elseif ($action === 'publish' || $action === 'archive') {
        $status = $action === 'publish' ? 'active' : 'archived';
        
        // Update course status
        $stmt = $conn->prepare("UPDATE courses SET course_status = ? WHERE course_code = ?");
        $stmt->bind_param("ss", $status, $courseCode);
        if ($stmt->execute()) {
            // Log management operation
            $logStmt = $conn->prepare("INSERT INTO course_management (admin_id, course_code, operation_time, operation_type) VALUES (?, ?, NOW(), ?)");
            $logStmt->bind_param("iss", $adminId, $courseCode, $action);
            $logStmt->execute();
            $logStmt->close();
            
            $stmt->close();
            // Redirect to preserve filters (check both POST and GET)
            $redirectParams = [];
            if (!empty($_POST['search']) || !empty($_GET['search'])) $redirectParams['search'] = $_POST['search'] ?? $_GET['search'];
            if (!empty($_POST['filter_status']) || !empty($_GET['filter_status'])) $redirectParams['filter_status'] = $_POST['filter_status'] ?? $_GET['filter_status'];
            if (!empty($_POST['filter_semester']) || !empty($_GET['filter_semester'])) $redirectParams['filter_semester'] = $_POST['filter_semester'] ?? $_GET['filter_semester'];
            if (!empty($_POST['filter_category']) || !empty($_GET['filter_category'])) $redirectParams['filter_category'] = $_POST['filter_category'] ?? $_GET['filter_category'];
            if (!empty($_POST['page']) || !empty($_GET['page'])) $redirectParams['page'] = $_POST['page'] ?? $_GET['page'];
            $redirectParams['message'] = $action;
            header('Location: admin_courses.php?' . http_build_query($redirectParams));
            exit();
        } else {
            $message = "Error updating course: " . $stmt->error;
            $messageType = "error";
        }
        $stmt->close();
    } elseif ($action === 'delete') {
        // Check if course exists
        $checkStmt = $conn->prepare("SELECT course_code, course_name FROM courses WHERE course_code = ?");
        $checkStmt->bind_param("s", $courseCode);
        $checkStmt->execute();
        $course = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
        
        if (!$course) {
            $message = "Course not found!";
            $messageType = "error";
        } else {
            // Get counts before deletion (for warning/info)
            $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM enrollments WHERE course_code = ?");
            $countStmt->bind_param("s", $courseCode);
            $countStmt->execute();
            $enrollmentCount = $countStmt->get_result()->fetch_assoc()['count'];
            $countStmt->close();
            
            $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM assignments WHERE course_code = ?");
            $countStmt->bind_param("s", $courseCode);
            $countStmt->execute();
            $assignmentCount = $countStmt->get_result()->fetch_assoc()['count'];
            $countStmt->close();
            
            // Delete course (CASCADE will handle related records)
            $stmt = $conn->prepare("DELETE FROM courses WHERE course_code = ?");
            $stmt->bind_param("s", $courseCode);
            
            if ($stmt->execute()) {
                $stmt->close();
                // Redirect to preserve filters (check both POST and GET)
                $redirectParams = [];
                if (!empty($_POST['search']) || !empty($_GET['search'])) $redirectParams['search'] = $_POST['search'] ?? $_GET['search'];
                if (!empty($_POST['filter_status']) || !empty($_GET['filter_status'])) $redirectParams['filter_status'] = $_POST['filter_status'] ?? $_GET['filter_status'];
                if (!empty($_POST['filter_semester']) || !empty($_GET['filter_semester'])) $redirectParams['filter_semester'] = $_POST['filter_semester'] ?? $_GET['filter_semester'];
                if (!empty($_POST['filter_category']) || !empty($_GET['filter_category'])) $redirectParams['filter_category'] = $_POST['filter_category'] ?? $_GET['filter_category'];
                if (!empty($_POST['page']) || !empty($_GET['page'])) $redirectParams['page'] = $_POST['page'] ?? $_GET['page'];
                $redirectParams['message'] = 'deleted';
                header('Location: admin_courses.php?' . http_build_query($redirectParams));
                exit();
            } else {
                $message = "Error deleting course: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    }
}

// Handle enrollment channel toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_enrollment') {
    $adminId = getCurrentUserId();
    $enabled = $_POST['enabled'] ?? '0';
    
    // Check if setting exists, if not create it
    $checkStmt = $conn->prepare("SELECT setting_id FROM system_settings WHERE setting_key = 'enrollment_enabled'");
    $checkStmt->execute();
    $exists = $checkStmt->get_result()->fetch_assoc();
    $checkStmt->close();
    
    if ($exists) {
        // Update existing setting
        $updateStmt = $conn->prepare("UPDATE system_settings SET setting_value = ?, updated_by = ? WHERE setting_key = 'enrollment_enabled'");
        $updateStmt->bind_param("si", $enabled, $adminId);
        if ($updateStmt->execute()) {
            $message = "Enrollment channel " . ($enabled == '1' ? 'opened' : 'closed') . " successfully!";
            $messageType = "success";
        } else {
            $message = "Error updating enrollment channel: " . $updateStmt->error;
            $messageType = "error";
        }
        $updateStmt->close();
    } else {
        // Create new setting
        $insertStmt = $conn->prepare("INSERT INTO system_settings (setting_key, setting_value, description, updated_by) VALUES ('enrollment_enabled', ?, 'Course enrollment channel status', ?)");
        $insertStmt->bind_param("si", $enabled, $adminId);
        if ($insertStmt->execute()) {
            $message = "Enrollment channel " . ($enabled == '1' ? 'opened' : 'closed') . " successfully!";
            $messageType = "success";
        } else {
            $message = "Error creating enrollment channel setting: " . $insertStmt->error;
            $messageType = "error";
        }
        $insertStmt->close();
    }
}

// Handle success message from redirect
if (isset($_GET['success']) && $_GET['success'] == '1') {
    $message = "Operation completed successfully!";
    $messageType = "success";
}

// Handle redirect messages
if (isset($_GET['message'])) {
    if ($_GET['message'] === 'published' || $_GET['message'] === 'archived' || $_GET['message'] === 'deleted') {
        $message = "Operation completed successfully!";
        $messageType = "success";
    }
}

// Get enrollment channel status
$enrollmentEnabled = true; // Default to enabled
$enrollmentStmt = $conn->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'enrollment_enabled'");
$enrollmentStmt->execute();
$enrollmentResult = $enrollmentStmt->get_result()->fetch_assoc();
$enrollmentStmt->close();
if ($enrollmentResult) {
    $enrollmentEnabled = ($enrollmentResult['setting_value'] == '1');
}

// Get filter and search parameters
$search = $_GET['search'] ?? '';
$filterStatus = $_GET['filter_status'] ?? '';
$filterSemester = $_GET['filter_semester'] ?? '';
$filterCategory = $_GET['filter_category'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build WHERE conditions
$where = [];
$params = [];
$types = '';

if ($search) {
    $where[] = "(course_code LIKE ? OR course_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types .= "ss";
}

if ($filterStatus) {
    $where[] = "course_status = ?";
    $params[] = $filterStatus;
    $types .= "s";
}

if ($filterSemester) {
    $where[] = "semester_offered = ?";
    $params[] = $filterSemester;
    $types .= "s";
}

if ($filterCategory) {
    $where[] = "course_category = ?";
    $params[] = $filterCategory;
    $types .= "s";
}

$whereClause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

// Get total count for pagination
$countQuery = "SELECT COUNT(*) as total FROM courses $whereClause";
if (!empty($params)) {
    $countStmt = $conn->prepare($countQuery);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $totalCount = $countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
} else {
    $totalCount = $conn->query($countQuery)->fetch_assoc()['total'];
}

$totalPages = ceil($totalCount / $perPage);

// Get courses with pagination
$coursesQuery = "SELECT c.*, 
                 (SELECT COUNT(*) FROM enrollments WHERE course_code = c.course_code) as enrollment_count,
                 (SELECT COUNT(*) FROM assignments WHERE course_code = c.course_code) as assignment_count
                 FROM courses c
                 $whereClause
                 ORDER BY c.course_code
                 LIMIT ? OFFSET ?";

if (!empty($params)) {
    $coursesStmt = $conn->prepare($coursesQuery);
    $params[] = $perPage;
    $params[] = $offset;
    $types .= "ii";
    $coursesStmt->bind_param($types, ...$params);
    $coursesStmt->execute();
    $courses = $coursesStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $coursesStmt->close();
} else {
    $courses = $conn->query("SELECT c.*, 
                            (SELECT COUNT(*) FROM enrollments WHERE course_code = c.course_code) as enrollment_count,
                            (SELECT COUNT(*) FROM assignments WHERE course_code = c.course_code) as assignment_count
                            FROM courses c
                            $whereClause
                            ORDER BY c.course_code
                            LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);
}

// Get unique values for filter dropdowns
$semesters = $conn->query("SELECT DISTINCT semester_offered FROM courses WHERE semester_offered IS NOT NULL ORDER BY semester_offered")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📚 Course Management</h2>
            <p>Publish, archive, and delete courses</p>
        </div>
    </div>

    <!-- Enrollment Channel Control -->
    <div class="dashboard-card" style="margin-bottom: 1.5rem;">
        <h3>📝 Enrollment Channel Control</h3>
        <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem;">
            <div style="flex: 1;">
                <p style="margin: 0; color: #666;">
                    Current Status: 
                    <strong style="color: <?php echo $enrollmentEnabled ? '#10b981' : '#ef4444'; ?>;">
                        <?php echo $enrollmentEnabled ? '✅ OPEN' : '❌ CLOSED'; ?>
                    </strong>
                </p>
                <small style="color: #999;">
                    When closed, students cannot enroll in or drop courses. They can only view available courses and their enrolled courses.
                </small>
            </div>
            <form method="POST" style="margin: 0;">
                <input type="hidden" name="action" value="toggle_enrollment">
                <input type="hidden" name="enabled" value="<?php echo $enrollmentEnabled ? '0' : '1'; ?>">
                <button type="submit" class="btn-primary" style="padding: 0.5rem 1.5rem; background: <?php echo $enrollmentEnabled ? '#ef4444' : '#10b981'; ?>; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">
                    <?php echo $enrollmentEnabled ? 'Close Enrollment' : 'Open Enrollment'; ?>
                </button>
            </form>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin: 1rem 0; padding: 1rem; border-radius: 4px; background: <?php echo $messageType === 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $messageType === 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Search and Filter Form -->
    <div style="background: white; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <form method="GET" action="admin_courses.php" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; align-items: end;">
            <!-- Search -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Search (Code/Name)</label>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Enter course code or name..." style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <!-- Filter Status -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Status</label>
                <select name="filter_status" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <option value="active" <?php echo $filterStatus === 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="archived" <?php echo $filterStatus === 'archived' ? 'selected' : ''; ?>>Archived</option>
                    <option value="draft" <?php echo $filterStatus === 'draft' ? 'selected' : ''; ?>>Draft</option>
                </select>
            </div>
            
            <!-- Filter Semester -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Semester</label>
                <select name="filter_semester" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <?php foreach ($semesters as $semester): ?>
                        <option value="<?php echo htmlspecialchars($semester['semester_offered']); ?>" <?php echo $filterSemester === $semester['semester_offered'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($semester['semester_offered']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Filter Category -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Category</label>
                <select name="filter_category" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <option value="MR" <?php echo $filterCategory === 'MR' ? 'selected' : ''; ?>>MR</option>
                    <option value="ME" <?php echo $filterCategory === 'ME' ? 'selected' : ''; ?>>ME</option>
                    <option value="GE" <?php echo $filterCategory === 'GE' ? 'selected' : ''; ?>>GE</option>
                    <option value="FE" <?php echo $filterCategory === 'FE' ? 'selected' : ''; ?>>FE</option>
                </select>
            </div>
            
            <!-- Buttons -->
            <div style="display: flex; gap: 0.5rem;">
                <button type="submit" style="padding: 0.5rem 1.5rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">Search</button>
                <a href="admin_courses.php" style="padding: 0.5rem 1.5rem; background: #6b7280; color: white; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; text-align: center; font-weight: bold;">Reset</a>
            </div>
        </form>
    </div>

    <!-- Results Info -->
    <div style="margin-bottom: 1rem; color: #666; font-size: 0.9rem;">
        Found <strong><?php echo $totalCount; ?></strong> course(s), showing <strong><?php echo min($offset + 1, $totalCount); ?></strong> - <strong><?php echo min($offset + count($courses), $totalCount); ?></strong>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Credit Hours</th>
                    <th>Semester</th>
                    <th>Enrollments</th>
                    <th>Assignments</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $course): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($course['course_code']); ?></strong></td>
                    <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                    <td><?php echo $course['credit_hours']; ?></td>
                    <td><?php echo htmlspecialchars($course['semester_offered'] ?? 'N/A'); ?></td>
                    <td><?php echo $course['enrollment_count']; ?></td>
                    <td><?php echo $course['assignment_count']; ?></td>
                    <td>
                        <span class="status-badge <?php echo $course['course_status']; ?>">
                            <?php echo ucfirst($course['course_status']); ?>
                        </span>
                    </td>
                    <td>
                        <div style="display: flex; gap: 0.25rem; flex-wrap: wrap;">
                            <?php if ($course['course_status'] !== 'active'): ?>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to publish this course?');">
                                <input type="hidden" name="action" value="publish">
                                <input type="hidden" name="course_code" value="<?php echo htmlspecialchars($course['course_code']); ?>">
                                <?php
                                // Preserve filter parameters
                                if ($search) echo '<input type="hidden" name="search" value="' . htmlspecialchars($search) . '">';
                                if ($filterStatus) echo '<input type="hidden" name="filter_status" value="' . htmlspecialchars($filterStatus) . '">';
                                if ($filterSemester) echo '<input type="hidden" name="filter_semester" value="' . htmlspecialchars($filterSemester) . '">';
                                if ($filterCategory) echo '<input type="hidden" name="filter_category" value="' . htmlspecialchars($filterCategory) . '">';
                                if ($page > 1) echo '<input type="hidden" name="page" value="' . $page . '">';
                                ?>
                                <button type="submit" class="action-btn" style="font-size: 0.875rem; padding: 0.25rem 0.5rem;">Publish</button>
                            </form>
                            <?php endif; ?>
                            <?php if ($course['course_status'] !== 'archived'): ?>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to archive this course?');">
                                <input type="hidden" name="action" value="archive">
                                <input type="hidden" name="course_code" value="<?php echo htmlspecialchars($course['course_code']); ?>">
                                <?php
                                // Preserve filter parameters
                                if ($search) echo '<input type="hidden" name="search" value="' . htmlspecialchars($search) . '">';
                                if ($filterStatus) echo '<input type="hidden" name="filter_status" value="' . htmlspecialchars($filterStatus) . '">';
                                if ($filterSemester) echo '<input type="hidden" name="filter_semester" value="' . htmlspecialchars($filterSemester) . '">';
                                if ($filterCategory) echo '<input type="hidden" name="filter_category" value="' . htmlspecialchars($filterCategory) . '">';
                                if ($page > 1) echo '<input type="hidden" name="page" value="' . $page . '">';
                                ?>
                                <button type="submit" class="action-btn" style="font-size: 0.875rem; padding: 0.25rem 0.5rem; background: #f59e0b;">Archive</button>
                            </form>
                            <?php endif; ?>
                            <form method="POST" style="display: inline;" onsubmit="return confirmDelete('<?php echo htmlspecialchars($course['course_code']); ?>', '<?php echo htmlspecialchars(addslashes($course['course_name'])); ?>', <?php echo $course['enrollment_count']; ?>, <?php echo $course['assignment_count']; ?>);">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="course_code" value="<?php echo htmlspecialchars($course['course_code']); ?>">
                                <?php
                                // Preserve filter parameters
                                if ($search) echo '<input type="hidden" name="search" value="' . htmlspecialchars($search) . '">';
                                if ($filterStatus) echo '<input type="hidden" name="filter_status" value="' . htmlspecialchars($filterStatus) . '">';
                                if ($filterSemester) echo '<input type="hidden" name="filter_semester" value="' . htmlspecialchars($filterSemester) . '">';
                                if ($filterCategory) echo '<input type="hidden" name="filter_category" value="' . htmlspecialchars($filterCategory) . '">';
                                if ($page > 1) echo '<input type="hidden" name="page" value="' . $page . '">';
                                ?>
                                <button type="submit" class="action-btn danger" style="font-size: 0.875rem; padding: 0.25rem 0.5rem;">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($courses)): ?>
                <tr>
                    <td colspan="8" style="text-align: center; padding: 2rem; color: #999;">
                        No matching courses found
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div style="margin-top: 2rem; display: flex; justify-content: center; align-items: center; gap: 0.5rem;">
        <?php
        // Build query string for pagination links
        $queryParams = [];
        if ($search) $queryParams['search'] = $search;
        if ($filterStatus) $queryParams['filter_status'] = $filterStatus;
        if ($filterSemester) $queryParams['filter_semester'] = $filterSemester;
        if ($filterCategory) $queryParams['filter_category'] = $filterCategory;
        $queryString = !empty($queryParams) ? '&' . http_build_query($queryParams) : '';
        ?>
        
        <!-- First Page -->
        <?php if ($page > 1): ?>
            <a href="admin_courses.php?page=1<?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">First</a>
        <?php endif; ?>
        
        <!-- Previous Page -->
        <?php if ($page > 1): ?>
            <a href="admin_courses.php?page=<?php echo $page - 1; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Previous</a>
        <?php endif; ?>
        
        <!-- Page Numbers -->
        <?php
        $startPage = max(1, $page - 2);
        $endPage = min($totalPages, $page + 2);
        
        for ($i = $startPage; $i <= $endPage; $i++):
        ?>
            <a href="admin_courses.php?page=<?php echo $i; ?><?php echo $queryString; ?>" 
               style="padding: 0.5rem 1rem; background: <?php echo $i === $page ? '#3b82f6' : 'white'; ?>; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: <?php echo $i === $page ? 'white' : '#333'; ?>; font-weight: <?php echo $i === $page ? 'bold' : 'normal'; ?>;">
                <?php echo $i; ?>
            </a>
        <?php endfor; ?>
        
        <!-- Next Page -->
        <?php if ($page < $totalPages): ?>
            <a href="admin_courses.php?page=<?php echo $page + 1; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Next</a>
        <?php endif; ?>
        
        <!-- Last Page -->
        <?php if ($page < $totalPages): ?>
            <a href="admin_courses.php?page=<?php echo $totalPages; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Last</a>
        <?php endif; ?>
        
        <span style="margin-left: 1rem; color: #666;">
            Page <?php echo $page; ?> / <?php echo $totalPages; ?>
        </span>
        
        <!-- Jump to Page -->
        <div style="margin-left: 1rem; display: flex; align-items: center; gap: 0.5rem;">
            <span style="color: #666; font-size: 0.875rem;">Go to:</span>
            <input type="number" id="jumpPage" min="1" max="<?php echo $totalPages; ?>" value="<?php echo $page; ?>" style="width: 60px; padding: 0.25rem 0.5rem; border: 1px solid #ddd; border-radius: 4px; font-size: 0.875rem;">
            <button onclick="jumpToPage('admin_courses.php', <?php echo $totalPages; ?>, '<?php echo htmlspecialchars($queryString, ENT_QUOTES); ?>')" style="padding: 0.25rem 0.75rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 0.875rem;">Go</button>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
function confirmDelete(courseCode, courseName, enrollmentCount, assignmentCount) {
    var message = 'Are you sure you want to DELETE this course?\n\n';
    message += 'Course Code: ' + courseCode + '\n';
    message += 'Course Name: ' + courseName + '\n\n';
    
    if (enrollmentCount > 0 || assignmentCount > 0) {
        message += 'WARNING: This will also delete:\n';
        if (enrollmentCount > 0) {
            message += '- ' + enrollmentCount + ' enrollment(s)\n';
        }
        if (assignmentCount > 0) {
            message += '- ' + assignmentCount + ' assignment(s)\n';
        }
        message += '- All related records (grades, submissions, appeals, etc.)\n\n';
    }
    
    message += 'This action CANNOT be undone!';
    
    return confirm(message);
}

function jumpToPage(baseUrl, maxPages, queryString) {
    const pageInput = document.getElementById('jumpPage');
    const page = parseInt(pageInput.value);
    if (page >= 1 && page <= maxPages) {
        window.location.href = baseUrl + '?page=' + page + queryString;
    } else {
        alert('Please enter a valid page number between 1 and ' + maxPages);
        pageInput.focus();
    }
}
</script>

<?php include __DIR__ . '/includes/course_footer.php'; ?>



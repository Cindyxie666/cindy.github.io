<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Notifications';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$filter = $_GET['filter'] ?? '';

// Build query
$whereConditions = ["student_id = ?"];
$params = [$studentId];
$types = "i";

if ($filter === 'unread') {
    $whereConditions[] = "is_read = 0";
} elseif ($filter === 'read') {
    $whereConditions[] = "is_read = 1";
}

$whereClause = implode(" AND ", $whereConditions);

// Get total count
$countQuery = "SELECT COUNT(*) as total FROM notifications WHERE $whereClause";
$countStmt = $conn->prepare($countQuery);
$countStmt->bind_param($types, ...$params);
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['total'];
$countStmt->close();

$totalPages = max(1, ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

// Get notifications
$query = "SELECT * FROM notifications WHERE $whereClause ORDER BY notification_time DESC LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;
$types .= "ii";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get unread count
$unreadStmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE student_id = ? AND is_read = 0");
$unreadStmt->bind_param("i", $studentId);
$unreadStmt->execute();
$unreadCount = $unreadStmt->get_result()->fetch_assoc()['count'];
$unreadStmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>🔔 Notifications</h2>
            <p>Stay updated with your course activities</p>
        </div>
    </div>

    <!-- Stats -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
        <div class="dashboard-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 1.5rem; font-weight: bold; color: #3b82f6;"><?php echo $total; ?></div>
            <div style="color: #666; font-size: 0.875rem;">Total</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 1.5rem; font-weight: bold; color: #f59e0b;"><?php echo $unreadCount; ?></div>
            <div style="color: #666; font-size: 0.875rem;">Unread</div>
        </div>
    </div>

    <!-- Filter -->
    <div class="dashboard-card" style="margin-bottom: 1.5rem;">
        <form method="GET" style="display: flex; gap: 1rem; align-items: center;">
            <select name="filter" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">All Notifications</option>
                <option value="unread" <?php echo $filter === 'unread' ? 'selected' : ''; ?>>Unread Only</option>
                <option value="read" <?php echo $filter === 'read' ? 'selected' : ''; ?>>Read Only</option>
            </select>
            <button type="submit" class="btn-primary">Filter</button>
            <?php if ($filter): ?>
            <a href="student_notifications.php" class="btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Notifications List -->
    <div class="dashboard-card">
        <h3>📬 Notifications (<?php echo $total; ?>)</h3>
        
        <div class="table-container" style="max-height: 500px; overflow-y: auto;">
            <?php if (empty($notifications)): ?>
            <div style="text-align: center; padding: 3rem; color: #666;">
                <p style="font-size: 1.25rem;">No notifications found.</p>
            </div>
            <?php else: ?>
            
            <?php foreach ($notifications as $notif): ?>
            <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem; margin-bottom: 0.75rem; background: <?php echo $notif['is_read'] ? '#fff' : '#eff6ff'; ?>; border-left: 4px solid <?php echo $notif['is_read'] ? '#e5e7eb' : '#3b82f6'; ?>;">
                <div style="display: flex; justify-content: space-between; align-items: start; gap: 1rem;">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                            <?php if (!$notif['is_read']): ?>
                            <span style="width: 8px; height: 8px; background: #3b82f6; border-radius: 50%;"></span>
                            <?php endif; ?>
                            <span style="font-size: 0.875rem; color: #666;">
                                <?php echo date('Y-m-d H:i', strtotime($notif['notification_time'])); ?>
                            </span>
                        </div>
                        <div style="color: #374151; line-height: 1.5;">
                            <?php echo nl2br(htmlspecialchars($notif['notification_content'])); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
            <?php if ($page > 1): ?>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn-secondary" style="padding: 0.5rem 1rem;">← Previous</a>
            <?php endif; ?>
            
            <span style="padding: 0.5rem 1rem; color: #666;">
                Page <?php echo $page; ?> of <?php echo $totalPages; ?>
            </span>
            
            <?php if ($page < $totalPages): ?>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn-secondary" style="padding: 0.5rem 1rem;">Next →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.table-container {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}
.table-container::-webkit-scrollbar {
    width: 8px;
}
.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}
.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

<?php
require_once __DIR__ . '/config/course_database.php';

$userType = $_GET['type'] ?? '';
$userId = intval($_GET['id'] ?? 0);

// 默认头像
function outputDefaultAvatar() {
    header('Content-Type: image/svg+xml');
    header('Cache-Control: no-cache');
    echo '<svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 150 150">
        <rect fill="#e0e0e0" width="150" height="150"/>
        <circle cx="75" cy="55" r="30" fill="#bdbdbd"/>
        <ellipse cx="75" cy="130" rx="45" ry="35" fill="#bdbdbd"/>
    </svg>';
    exit;
}

if (!$userType || !$userId) {
    outputDefaultAvatar();
}

$table = '';
$idField = '';

switch ($userType) {
    case 'student':
        $table = 'students';
        $idField = 'student_id';
        break;
    case 'instructor':
        $table = 'instructors';
        $idField = 'instructor_id';
        break;
    case 'administrator':
        $table = 'administrators';
        $idField = 'admin_id';
        break;
    default:
        outputDefaultAvatar();
}

try {
    $conn = getCourseDBConnection();
    
    $stmt = $conn->prepare("SELECT avatar FROM $table WHERE $idField = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    if (!$row || !$row['avatar'] || strlen($row['avatar']) < 100) {
        outputDefaultAvatar();
    }
    
    $avatar = $row['avatar'];
    
    // 检测图片类型
    $mimeType = 'image/jpeg';
    if (substr($avatar, 0, 8) === "\x89PNG\r\n\x1a\n") {
        $mimeType = 'image/png';
    } elseif (substr($avatar, 0, 2) === "\xff\xd8") {
        $mimeType = 'image/jpeg';
    } elseif (substr($avatar, 0, 6) === 'GIF87a' || substr($avatar, 0, 6) === 'GIF89a') {
        $mimeType = 'image/gif';
    }
    
    header('Content-Type: ' . $mimeType);
    header('Content-Length: ' . strlen($avatar));
    header('Cache-Control: no-cache, must-revalidate');
    
    echo $avatar;
    exit;
    
} catch (Exception $e) {
    outputDefaultAvatar();
}
?>

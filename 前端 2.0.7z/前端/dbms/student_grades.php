<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'My Grades';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

// Get grades
$query = "SELECT g.*, a.assignment_name, a.course_code, c.course_name
          FROM grades g
          JOIN assignments a ON g.assignment_id = a.assignment_id
          JOIN courses c ON a.course_code = c.course_code
          WHERE g.student_id = ?
          ORDER BY g.grading_time DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$grades = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📊 My Grades</h2>
            <p>View your grades and feedback</p>
        </div>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Assignment</th>
                    <th>Course</th>
                    <th>Score</th>
                    <th>Grading Time</th>
                    <th>Remarks</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($grades as $grade): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($grade['assignment_name']); ?></strong></td>
                    <td><?php echo htmlspecialchars($grade['course_name']); ?></td>
                    <td>
                        <span class="score-badge">
                            <?php echo number_format($grade['score'], 2); ?>
                        </span>
                    </td>
                    <td><?php echo date('Y-m-d H:i', strtotime($grade['grading_time'])); ?></td>
                    <td><?php echo htmlspecialchars($grade['grading_remarks'] ?? 'N/A'); ?></td>
                    <td>
                        <a href="student_appeal.php?grade_id=<?php echo $grade['grade_id']; ?>" class="action-btn">
                            Appeal Grade
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
.score-badge {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
    border-radius: 9999px;
    font-weight: 600;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


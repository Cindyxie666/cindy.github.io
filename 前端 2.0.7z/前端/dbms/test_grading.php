<?php
require_once __DIR__ . '/config/course_database.php';
requireInstructor();

$conn = getCourseDBConnection();
$instructorId = getCurrentUserId();

echo "<h1>评分功能诊断</h1>";
echo "<p>当前教师 ID: <strong>$instructorId</strong></p>";

// 1. 检查教师信息
echo "<h2>1. 教师信息</h2>";
$stmt = $conn->prepare("SELECT * FROM instructors WHERE instructor_id = ?");
$stmt->bind_param("i", $instructorId);
$stmt->execute();
$instructor = $stmt->get_result()->fetch_assoc();
$stmt->close();
echo "<p>姓名: " . htmlspecialchars($instructor['name']) . "</p>";

// 2. 检查教师教授的课程
echo "<h2>2. 教授的课程 (teaching 表)</h2>";
$stmt = $conn->prepare("SELECT t.*, c.course_name FROM teaching t JOIN courses c ON t.course_code = c.course_code WHERE t.instructor_id = ?");
$stmt->bind_param("i", $instructorId);
$stmt->execute();
$teaching = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($teaching)) {
    echo "<p style='color:red;'>❌ 该教师没有关联任何课程！需要在 teaching 表中添加记录。</p>";
} else {
    echo "<table border='1' cellpadding='8'><tr><th>Course Code</th><th>Course Name</th></tr>";
    foreach ($teaching as $t) {
        echo "<tr><td>{$t['course_code']}</td><td>" . htmlspecialchars($t['course_name']) . "</td></tr>";
    }
    echo "</table>";
}

// 3. 检查该教师创建的作业
echo "<h2>3. 该教师创建的作业</h2>";
$stmt = $conn->prepare("SELECT a.*, c.course_name FROM assignments a JOIN courses c ON a.course_code = c.course_code WHERE a.instructor_id = ?");
$stmt->bind_param("i", $instructorId);
$stmt->execute();
$assignments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($assignments)) {
    echo "<p style='color:red;'>❌ 该教师没有创建任何作业！</p>";
} else {
    echo "<table border='1' cellpadding='8'><tr><th>ID</th><th>Assignment</th><th>Course</th><th>Deadline</th></tr>";
    foreach ($assignments as $a) {
        echo "<tr><td>{$a['assignment_id']}</td><td>" . htmlspecialchars($a['assignment_name']) . "</td><td>{$a['course_code']}</td><td>{$a['deadline']}</td></tr>";
    }
    echo "</table>";
}

// 4. 检查作业提交情况
echo "<h2>4. 该教师作业的提交情况</h2>";
$query = "SELECT s.*, a.assignment_name, st.name as student_name, 
          (SELECT score FROM grades WHERE submission_id = s.submission_id) as current_score
          FROM assignment_submissions s
          JOIN assignments a ON s.assignment_id = a.assignment_id
          JOIN students st ON s.student_id = st.student_id
          WHERE a.instructor_id = ?
          ORDER BY s.submission_time DESC
          LIMIT 20";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $instructorId);
$stmt->execute();
$submissions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($submissions)) {
    echo "<p style='color:red;'>❌ 没有学生提交作业！</p>";
} else {
    echo "<p style='color:green;'>✅ 找到 " . count($submissions) . " 个提交</p>";
    echo "<table border='1' cellpadding='8'><tr><th>Submission ID</th><th>Student</th><th>Assignment</th><th>Status</th><th>Score</th></tr>";
    foreach ($submissions as $s) {
        $score = $s['current_score'] !== null ? $s['current_score'] : '<span style="color:orange;">未评分</span>';
        echo "<tr><td>{$s['submission_id']}</td><td>" . htmlspecialchars($s['student_name']) . "</td><td>" . htmlspecialchars($s['assignment_name']) . "</td><td>{$s['submission_status']}</td><td>$score</td></tr>";
    }
    echo "</table>";
}

// 5. 检查所有作业（不限于当前教师）
echo "<h2>5. 所有作业和提交 (调试用)</h2>";
$result = $conn->query("SELECT a.assignment_id, a.assignment_name, a.instructor_id, i.name as instructor_name,
                        (SELECT COUNT(*) FROM assignment_submissions WHERE assignment_id = a.assignment_id) as submission_count
                        FROM assignments a 
                        JOIN instructors i ON a.instructor_id = i.instructor_id
                        LIMIT 20");
$allAssignments = $result->fetch_all(MYSQLI_ASSOC);

echo "<table border='1' cellpadding='8'><tr><th>Assignment ID</th><th>Assignment</th><th>Created By (ID)</th><th>Instructor Name</th><th>Submissions</th></tr>";
foreach ($allAssignments as $a) {
    $highlight = ($a['instructor_id'] == $instructorId) ? "style='background:#d1fae5;'" : "";
    echo "<tr $highlight><td>{$a['assignment_id']}</td><td>" . htmlspecialchars($a['assignment_name']) . "</td><td>{$a['instructor_id']}</td><td>" . htmlspecialchars($a['instructor_name']) . "</td><td>{$a['submission_count']}</td></tr>";
}
echo "</table>";
echo "<p><small>绿色行 = 当前教师创建的作业</small></p>";

$conn->close();

echo "<h2>6. 解决方案</h2>";
echo "<ol>";
echo "<li>如果没有关联课程：运行下面的 SQL</li>";
echo "<li>如果没有作业：去 Assignments 页面创建作业</li>";
echo "<li>如果没有提交：用学生账号提交作业</li>";
echo "</ol>";

echo "<h3>添加教师-课程关联的 SQL：</h3>";
echo "<pre style='background:#333;color:#0f0;padding:15px;'>";
echo "-- 将教师 ID=$instructorId 关联到课程\n";
echo "INSERT INTO teaching (instructor_id, course_code, teaching_semester) VALUES ($instructorId, 'MR-001', 'Fall 2024');\n";
echo "INSERT INTO teaching (instructor_id, course_code, teaching_semester) VALUES ($instructorId, 'ME-001', 'Fall 2024');\n";
echo "</pre>";
?>

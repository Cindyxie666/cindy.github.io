<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Announcements';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

// Get announcements for enrolled courses and system announcements
$query = "SELECT a.*, c.course_name, 
          CASE 
            WHEN a.publisher_type = 'instructor' THEN i.name
            WHEN a.publisher_type = 'administrator' THEN ad.name
          END as publisher_name
          FROM announcements a
          LEFT JOIN courses c ON a.course_code = c.course_code
          LEFT JOIN instructors i ON a.publisher_type = 'instructor' AND a.publisher_id = i.instructor_id
          LEFT JOIN administrators ad ON a.publisher_type = 'administrator' AND a.publisher_id = ad.admin_id
          WHERE a.course_code IN (SELECT course_code FROM enrollments WHERE student_id = ? AND enrollment_status = 'enrolled')
          OR a.announcement_type = 'system_notification'
          ORDER BY a.release_time DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$announcements = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📢 Announcements</h2>
            <p>View course and system announcements</p>
        </div>
    </div>

    <div class="announcements-container">
        <?php foreach ($announcements as $announcement): ?>
        <div class="announcement-card">
            <div class="announcement-header">
                <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                <span class="announcement-type-badge <?php echo $announcement['announcement_type']; ?>">
                    <?php echo $announcement['announcement_type'] === 'course_notification' ? 'Course' : 'System'; ?>
                </span>
            </div>
            <div class="announcement-meta">
                <span>📚 <?php echo htmlspecialchars($announcement['course_name'] ?? 'System'); ?></span>
                <span>👤 <?php echo htmlspecialchars($announcement['publisher_name']); ?></span>
                <span>🕒 <?php echo date('Y-m-d H:i', strtotime($announcement['release_time'])); ?></span>
            </div>
            <div class="announcement-content">
                <?php echo nl2br(htmlspecialchars($announcement['content'])); ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
.announcements-container {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}
.announcement-card {
    background: var(--card);
    border-radius: 0.75rem;
    padding: 1.5rem;
    box-shadow: var(--shadow);
    border-left: 4px solid var(--primary);
}
.announcement-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    margin-bottom: 1rem;
}
.announcement-header h3 {
    font-size: 1.25rem;
    font-weight: 600;
    color: var(--text);
    margin: 0;
}
.announcement-type-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
}
.announcement-type-badge.course_notification {
    background: rgba(59, 130, 246, 0.1);
    color: var(--primary);
}
.announcement-type-badge.system_notification {
    background: rgba(245, 158, 11, 0.1);
    color: var(--warning);
}
.announcement-meta {
    display: flex;
    gap: 1.5rem;
    font-size: 0.875rem;
    color: var(--text-light);
    margin-bottom: 1rem;
}
.announcement-content {
    color: var(--text);
    line-height: 1.6;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


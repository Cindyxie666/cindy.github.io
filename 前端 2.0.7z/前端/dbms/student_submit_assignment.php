<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Submit Assignment';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();
$assignmentId = $_GET['id'] ?? 0;

if (!$assignmentId) {
    header('Location: student_assignments.php');
    exit();
}

// Get assignment details
$stmt = $conn->prepare("SELECT a.*, c.course_name FROM assignments a 
                       JOIN courses c ON a.course_code = c.course_code
                       WHERE a.assignment_id = ?");
$stmt->bind_param("i", $assignmentId);
$stmt->execute();
$assignment = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$assignment) {
    header('Location: student_assignments.php');
    exit();
}

// Check if student is enrolled
$stmt = $conn->prepare("SELECT * FROM enrollments WHERE student_id = ? AND course_code = ? AND enrollment_status = 'enrolled'");
$stmt->bind_param("is", $studentId, $assignment['course_code']);
$stmt->execute();
if ($stmt->get_result()->num_rows === 0) {
    header('Location: student_assignments.php');
    exit();
}
$stmt->close();

$error = '';
$success = '';

// Handle submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submissionContent = $_POST['submission_content'] ?? '';
    
    if (empty($submissionContent)) {
        $error = 'Submission content is required';
    } else {
        $now = new DateTime();
        $deadline = new DateTime($assignment['deadline']);
        $isLate = $now > $deadline;
        $status = $isLate ? 'late' : 'submitted';
        
        // Check if submission exists
        $checkStmt = $conn->prepare("SELECT submission_id FROM assignment_submissions WHERE student_id = ? AND assignment_id = ?");
        $checkStmt->bind_param("ii", $studentId, $assignmentId);
        $checkStmt->execute();
        $existing = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
        
        if ($existing) {
            // Update existing submission
            $updateStmt = $conn->prepare("UPDATE assignment_submissions SET submission_content = ?, submission_time = NOW(), submission_status = ? WHERE submission_id = ?");
            $updateStmt->bind_param("ssi", $submissionContent, $status, $existing['submission_id']);
            if ($updateStmt->execute()) {
                $success = 'Submission updated successfully!';
            } else {
                $error = 'Failed to update submission';
            }
            $updateStmt->close();
        } else {
            // Create new submission
            $insertStmt = $conn->prepare("INSERT INTO assignment_submissions (submission_time, submission_content, submission_status, student_id, assignment_id) VALUES (NOW(), ?, ?, ?, ?)");
            $insertStmt->bind_param("ssii", $submissionContent, $status, $studentId, $assignmentId);
            if ($insertStmt->execute()) {
                $success = 'Assignment submitted successfully!';
            } else {
                $error = 'Failed to submit assignment';
            }
            $insertStmt->close();
        }
    }
}

// Get existing submission
$stmt = $conn->prepare("SELECT * FROM assignment_submissions WHERE student_id = ? AND assignment_id = ?");
$stmt->bind_param("ii", $studentId, $assignmentId);
$stmt->execute();
$submission = $stmt->get_result()->fetch_assoc();
$stmt->close();

$conn->close();
?>

<div class="form-container">
    <div class="page-header">
        <div>
            <h2>📝 Submit Assignment</h2>
            <p><?php echo htmlspecialchars($assignment['assignment_name']); ?></p>
        </div>
    </div>

    <div class="dashboard-card">
        <h3>Assignment Details</h3>
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Course:</span>
                <span class="info-value"><?php echo htmlspecialchars($assignment['course_name']); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Release Time:</span>
                <span class="info-value"><?php echo date('Y-m-d H:i', strtotime($assignment['release_time'])); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Deadline:</span>
                <span class="info-value"><?php echo date('Y-m-d H:i', strtotime($assignment['deadline'])); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Requirements:</span>
                <span class="info-value"><?php echo nl2br(htmlspecialchars($assignment['requirements'] ?? 'N/A')); ?></span>
            </div>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="success-box"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <div class="dashboard-card">
        <h3>Submission</h3>
        <form method="POST">
            <div class="form-group">
                <label>Submission Content</label>
                <textarea name="submission_content" rows="10" required><?php echo htmlspecialchars($submission['submission_content'] ?? ''); ?></textarea>
            </div>
            <?php if ($submission): ?>
            <div class="info-box">
                <p>Last submitted: <?php echo date('Y-m-d H:i', strtotime($submission['submission_time'])); ?></p>
                <p>Status: <?php echo ucfirst($submission['submission_status']); ?></p>
            </div>
            <?php endif; ?>
            <div class="form-actions">
                <button type="submit" class="btn-primary"><?php echo $submission ? 'Update Submission' : 'Submit Assignment'; ?></button>
                <a href="student_assignments.php" class="btn-secondary">Back to Assignments</a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


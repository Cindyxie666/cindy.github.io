<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Course Enrollment';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

$message = '';
$messageType = '';

// Check enrollment channel status
$enrollmentEnabled = isEnrollmentEnabled($conn);

// Handle enrollment/drop
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $courseCode = $_POST['course_code'] ?? '';
    $action = $_POST['action'];
    
    if (empty($courseCode)) {
        $message = "Course code is required!";
        $messageType = "error";
    } elseif (!$enrollmentEnabled) {
        $message = "Enrollment channel is currently closed.";
        $messageType = "error";
    } elseif ($action === 'enroll') {
        $checkStmt = $conn->prepare("SELECT enrollment_id FROM enrollments WHERE student_id = ? AND course_code = ?");
        $checkStmt->bind_param("is", $studentId, $courseCode);
        $checkStmt->execute();
        $existing = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
        
        if ($existing) {
            $message = "You are already enrolled in this course!";
            $messageType = "error";
        } else {
            $stmt = $conn->prepare("INSERT INTO enrollments (student_id, course_code, enrollment_time, enrollment_status) VALUES (?, ?, NOW(), 'enrolled')");
            $stmt->bind_param("is", $studentId, $courseCode);
            if ($stmt->execute()) {
                $message = "Successfully enrolled in the course!";
                $messageType = "success";
            } else {
                $message = "Error enrolling: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    } elseif ($action === 'drop') {
        $stmt = $conn->prepare("UPDATE enrollments SET enrollment_status = 'dropped' WHERE student_id = ? AND course_code = ?");
        $stmt->bind_param("is", $studentId, $courseCode);
        if ($stmt->execute()) {
            $message = "Successfully dropped the course!";
            $messageType = "success";
        } else {
            $message = "Error dropping course: " . $stmt->error;
            $messageType = "error";
        }
        $stmt->close();
    }
}

// Pagination settings
$perPage = 10;
$enrolledPage = max(1, intval($_GET['enrolled_page'] ?? 1));
$availablePage = max(1, intval($_GET['available_page'] ?? 1));
$search = $_GET['search'] ?? '';
$filterCategory = $_GET['category'] ?? '';

// ========== Enrolled Courses ==========
$countStmt = $conn->prepare("SELECT COUNT(*) as total FROM enrollments WHERE student_id = ? AND enrollment_status = 'enrolled'");
$countStmt->bind_param("i", $studentId);
$countStmt->execute();
$enrolledTotal = $countStmt->get_result()->fetch_assoc()['total'];
$countStmt->close();

$enrolledTotalPages = max(1, ceil($enrolledTotal / $perPage));
$enrolledPage = min($enrolledPage, $enrolledTotalPages);
$enrolledOffset = ($enrolledPage - 1) * $perPage;

$enrolledQuery = "SELECT c.course_code, c.course_name, c.course_category, c.credit_hours, c.semester_offered, e.enrollment_time
                  FROM courses c
                  JOIN enrollments e ON c.course_code = e.course_code
                  WHERE e.student_id = ? AND e.enrollment_status = 'enrolled'
                  ORDER BY e.enrollment_time DESC
                  LIMIT ? OFFSET ?";
$enrolledStmt = $conn->prepare($enrolledQuery);
$enrolledStmt->bind_param("iii", $studentId, $perPage, $enrolledOffset);
$enrolledStmt->execute();
$enrolledCourses = $enrolledStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$enrolledStmt->close();

// ========== Available Courses ==========
$availableWhere = "c.course_status = 'active' AND c.course_code NOT IN (SELECT course_code FROM enrollments WHERE student_id = ? AND enrollment_status = 'enrolled')";
$availableParams = [$studentId];
$availableTypes = "i";

if ($search) {
    $availableWhere .= " AND (c.course_code LIKE ? OR c.course_name LIKE ?)";
    $searchTerm = "%$search%";
    $availableParams[] = $searchTerm;
    $availableParams[] = $searchTerm;
    $availableTypes .= "ss";
}

if ($filterCategory) {
    $availableWhere .= " AND c.course_category = ?";
    $availableParams[] = $filterCategory;
    $availableTypes .= "s";
}

// Count available
$countQuery = "SELECT COUNT(*) as total FROM courses c WHERE $availableWhere";
$countStmt = $conn->prepare($countQuery);
$countStmt->bind_param($availableTypes, ...$availableParams);
$countStmt->execute();
$availableTotal = $countStmt->get_result()->fetch_assoc()['total'];
$countStmt->close();

$availableTotalPages = max(1, ceil($availableTotal / $perPage));
$availablePage = min($availablePage, $availableTotalPages);
$availableOffset = ($availablePage - 1) * $perPage;

// Get available courses
$availableQuery = "SELECT c.* FROM courses c WHERE $availableWhere ORDER BY c.course_code LIMIT ? OFFSET ?";
$availableParams[] = $perPage;
$availableParams[] = $availableOffset;
$availableTypes .= "ii";

$availableStmt = $conn->prepare($availableQuery);
$availableStmt->bind_param($availableTypes, ...$availableParams);
$availableStmt->execute();
$availableCourses = $availableStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$availableStmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📚 Course Enrollment</h2>
            <p>Manage your course enrollments</p>
        </div>
        <?php if (!$enrollmentEnabled): ?>
        <div style="background: #fef3c7; color: #92400e; padding: 0.75rem 1rem; border-radius: 0.5rem; font-weight: 500;">
            ⚠️ Enrollment channel is currently closed
        </div>
        <?php endif; ?>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 8px; background: <?php echo $messageType === 'success' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $messageType === 'success' ? '#065f46' : '#991b1b'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <div class="dashboard-grid">
        <!-- Enrolled Courses -->
        <div class="dashboard-card">
            <h3>✅ My Enrolled Courses (<?php echo $enrolledTotal; ?>)</h3>
            <div class="table-container" style="max-height: 400px; overflow-y: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Category</th>
                            <th>Credits</th>
                            <th>Enrolled On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($enrolledCourses)): ?>
                        <tr>                            <td colspan="6" style="text-align: center; padding: 2rem; color: #666;">
                                You haven't enrolled in any courses yet.
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($enrolledCourses as $course): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($course['course_code']); ?></strong></td>
                            <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                            <td><span class="category-badge"><?php echo htmlspecialchars($course['course_category'] ?? 'N/A'); ?></span></td>
                            <td><?php echo $course['credit_hours']; ?></td>
                            <td><?php echo date('Y-m-d', strtotime($course['enrollment_time'])); ?></td>
                            <td>
                                <?php if ($enrollmentEnabled): ?>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to drop this course?');">
                                    <input type="hidden" name="action" value="drop">
                                    <input type="hidden" name="course_code" value="<?php echo htmlspecialchars($course['course_code']); ?>">
                                    <button type="submit" class="btn-danger" style="padding: 0.25rem 0.75rem; font-size: 0.875rem;">Drop</button>
                                </form>
                                <?php else: ?>
                                <span style="color: #999; font-size: 0.875rem;">Closed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Enrolled Pagination -->
            <?php if ($enrolledTotalPages > 1): ?>
            <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
                <?php if ($enrolledPage > 1): ?>
                <a href="?<?php echo http_build_query(array_merge($_GET, ['enrolled_page' => $enrolledPage - 1])); ?>" class="btn-secondary" style="padding: 0.375rem 0.75rem; font-size: 0.875rem;">← Prev</a>
                <?php endif; ?>
                <span style="padding: 0.375rem 0.75rem; color: #666; font-size: 0.875rem;">
                    Page <?php echo $enrolledPage; ?> / <?php echo $enrolledTotalPages; ?>
                </span>
                <?php if ($enrolledPage < $enrolledTotalPages): ?>
                <a href="?<?php echo http_build_query(array_merge($_GET, ['enrolled_page' => $enrolledPage + 1])); ?>" class="btn-secondary" style="padding: 0.375rem 0.75rem; font-size: 0.875rem;">Next →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Available Courses -->
        <div class="dashboard-card">
            <h3>📖 Available Courses (<?php echo $availableTotal; ?>)</h3>
            
            <!-- Search and Filter -->
            <form method="GET" style="display: flex; gap: 0.75rem; margin-bottom: 1rem; flex-wrap: wrap;">
                <input type="text" name="search" placeholder="Search courses..." value="<?php echo htmlspecialchars($search); ?>" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; min-width: 150px;">
                <select name="category" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All Categories</option>
                    <option value="Major Required" <?php echo $filterCategory === 'Major Required' ? 'selected' : ''; ?>>Major Required</option>
                    <option value="Major Elective" <?php echo $filterCategory === 'Major Elective' ? 'selected' : ''; ?>>Major Elective</option>
                    <option value="General Education" <?php echo $filterCategory === 'General Education' ? 'selected' : ''; ?>>General Education</option>
                </select>
                <button type="submit" class="btn-primary" style="padding: 0.5rem 1rem;">Search</button>
                <?php if ($search || $filterCategory): ?>
                <a href="student_enroll.php" class="btn-secondary" style="padding: 0.5rem 1rem;">Clear</a>
                <?php endif; ?>
            </form>
            
            <div class="table-container" style="max-height: 400px; overflow-y: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Category</th>
                            <th>Credits</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($availableCourses)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 2rem; color: #666;">
                                No available courses found.
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($availableCourses as $course): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($course['course_code']); ?></strong></td>
                            <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                            <td><span class="category-badge"><?php echo htmlspecialchars($course['course_category'] ?? 'N/A'); ?></span></td>
                            <td><?php echo $course['credit_hours']; ?></td>
                            <td>
                                <?php if ($enrollmentEnabled): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="enroll">
                                    <input type="hidden" name="course_code" value="<?php echo htmlspecialchars($course['course_code']); ?>">
                                    <button type="submit" class="btn-primary" style="padding: 0.25rem 0.75rem; font-size: 0.875rem;">Enroll</button>
                                </form>
                                <?php else: ?>
                                <span style="color: #999; font-size: 0.875rem;">Closed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Available Pagination -->
            <?php if ($availableTotalPages > 1): ?>
            <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
                <?php if ($availablePage > 1): ?>
                <a href="?<?php echo http_build_query(array_merge($_GET, ['available_page' => $availablePage - 1])); ?>" class="btn-secondary" style="padding: 0.375rem 0.75rem; font-size: 0.875rem;">← Prev</a>
                <?php endif; ?>
                <span style="padding: 0.375rem 0.75rem; color: #666; font-size: 0.875rem;">
                    Page <?php echo $availablePage; ?> / <?php echo $availableTotalPages; ?>
                </span>
                <?php if ($availablePage < $availableTotalPages): ?>
                <a href="?<?php echo http_build_query(array_merge($_GET, ['available_page' => $availablePage + 1])); ?>" class="btn-secondary" style="padding: 0.375rem 0.75rem; font-size: 0.875rem;">Next →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.category-badge {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    background: rgba(99, 102, 241, 0.1);
    color: #6366f1;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
}

.btn-danger {
    background: #ef4444;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background 0.2s;
}

.btn-danger:hover {
    background: #dc2626;
}

.table-container {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}

.table-container::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

                

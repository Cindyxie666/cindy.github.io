<?php
require_once __DIR__ . '/config/course_database.php';
requireInstructor();

$pageTitle = 'Grade Assignments';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$instructorId = getCurrentUserId();

$message = '';
$messageType = '';

// Handle grading submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'grade') {
    $submissionId = intval($_POST['submission_id'] ?? 0);
    $score = floatval($_POST['score'] ?? 0);
    $remarks = trim($_POST['remarks'] ?? '');
    
    if ($submissionId && $score >= 0 && $score <= 100) {
        // Get submission info and verify ownership
        $verifyQuery = "SELECT s.submission_id, s.student_id, s.assignment_id, 
                               a.assignment_name, st.name as student_name
                        FROM assignment_submissions s
                        JOIN assignments a ON s.assignment_id = a.assignment_id
                        JOIN students st ON s.student_id = st.student_id
                        WHERE s.submission_id = ? AND a.instructor_id = ?";
        $verifyStmt = $conn->prepare($verifyQuery);
        $verifyStmt->bind_param("ii", $submissionId, $instructorId);
        $verifyStmt->execute();
        $submission = $verifyStmt->get_result()->fetch_assoc();
        $verifyStmt->close();
        
        if ($submission) {
            // Check if grade already exists
            $checkStmt = $conn->prepare("SELECT grade_id FROM grades WHERE submission_id = ?");
            $checkStmt->bind_param("i", $submissionId);
            $checkStmt->execute();
            $existingGrade = $checkStmt->get_result()->fetch_assoc();
            $checkStmt->close();
            
            if ($existingGrade) {
                // Update existing grade
                $updateStmt = $conn->prepare("UPDATE grades SET score = ?, grading_remarks = ?, grading_time = NOW() WHERE submission_id = ?");
                $updateStmt->bind_param("dsi", $score, $remarks, $submissionId);
                if ($updateStmt->execute()) {
                    $message = "Grade updated successfully for {$submission['student_name']}!";
                    $messageType = "success";
                } else {
                    $message = "Error updating grade: " . $updateStmt->error;
                    $messageType = "error";
                }
                $updateStmt->close();
            } else {
                // Insert new grade
                $insertStmt = $conn->prepare("INSERT INTO grades (score, grading_time, grading_remarks, submission_id, assignment_id, student_id, instructor_id) VALUES (?, NOW(), ?, ?, ?, ?, ?)");
                $insertStmt->bind_param("dsiiii", $score, $remarks, $submissionId, $submission['assignment_id'], $submission['student_id'], $instructorId);
                if ($insertStmt->execute()) {
                    // Update submission status
                    $statusStmt = $conn->prepare("UPDATE assignment_submissions SET submission_status = 'graded' WHERE submission_id = ?");
                    $statusStmt->bind_param("i", $submissionId);
                    $statusStmt->execute();
                    $statusStmt->close();
                    
                    $message = "Grade submitted successfully for {$submission['student_name']}!";
                    $messageType = "success";
                } else {
                    $message = "Error submitting grade: " . $insertStmt->error;
                    $messageType = "error";
                }
                $insertStmt->close();
            }
        } else {
            $message = "Invalid submission or you don't have permission to grade this.";
            $messageType = "error";
        }
    } else {
        $message = "Please enter a valid score between 0 and 100.";
        $messageType = "error";
    }
}

// Get filter parameters
$filterAssignment = $_GET['assignment'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;

// Get all assignments by this instructor
$assignmentsStmt = $conn->prepare("SELECT assignment_id, assignment_name, course_code FROM assignments WHERE instructor_id = ? ORDER BY deadline DESC");
$assignmentsStmt->bind_param("i", $instructorId);
$assignmentsStmt->execute();
$allAssignments = $assignmentsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$assignmentsStmt->close();

// 统计查询
$statsQuery = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN g.grade_id IS NULL THEN 1 ELSE 0 END) as ungraded,
    SUM(CASE WHEN g.grade_id IS NOT NULL THEN 1 ELSE 0 END) as graded
FROM assignment_submissions s
JOIN assignments a ON s.assignment_id = a.assignment_id
LEFT JOIN grades g ON s.submission_id = g.submission_id
WHERE a.instructor_id = ?";
$statsStmt = $conn->prepare($statsQuery);
$statsStmt->bind_param("i", $instructorId);
$statsStmt->execute();
$stats = $statsStmt->get_result()->fetch_assoc();
$statsStmt->close();

$totalSubmissions = intval($stats['total'] ?? 0);
$ungradedCount = intval($stats['ungraded'] ?? 0);
$gradedCount = intval($stats['graded'] ?? 0);

// 构建过滤条件
$filterWhere = "";
$filterParams = [$instructorId];
$filterTypes = "i";

if ($filterAssignment) {
    $filterWhere .= " AND a.assignment_id = ?";
    $filterParams[] = intval($filterAssignment);
    $filterTypes .= "i";
}

if ($filterStatus === 'graded') {
    $filterWhere .= " AND g.grade_id IS NOT NULL";
} elseif ($filterStatus === 'ungraded') {
    $filterWhere .= " AND g.grade_id IS NULL";
}

// 获取过滤后的总数
$countQuery = "SELECT COUNT(*) as total
               FROM assignment_submissions s
               JOIN assignments a ON s.assignment_id = a.assignment_id
               LEFT JOIN grades g ON s.submission_id = g.submission_id
               WHERE a.instructor_id = ? $filterWhere";
$countStmt = $conn->prepare($countQuery);
$countStmt->bind_param($filterTypes, ...$filterParams);
$countStmt->execute();
$filteredTotal = $countStmt->get_result()->fetch_assoc()['total'];
$countStmt->close();

$totalPages = max(1, ceil($filteredTotal / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

// 获取提交列表
$listParams = $filterParams;
$listTypes = $filterTypes;
$listParams[] = $perPage;
$listParams[] = $offset;
$listTypes .= "ii";

$query = "SELECT s.submission_id, s.submission_content, s.submission_time, s.submission_status,
                 a.assignment_id, a.assignment_name, a.course_code, a.deadline,
                 st.student_id, st.name as student_name, st.account as student_account,
                 g.grade_id, g.score, g.grading_remarks, g.grading_time
          FROM assignment_submissions s
          JOIN assignments a ON s.assignment_id = a.assignment_id
          JOIN students st ON s.student_id = st.student_id
          LEFT JOIN grades g ON s.submission_id = g.submission_id
          WHERE a.instructor_id = ? $filterWhere
          ORDER BY CASE WHEN g.grade_id IS NULL THEN 0 ELSE 1 END, s.submission_time DESC
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($query);
$stmt->bind_param($listTypes, ...$listParams);
$stmt->execute();
$submissions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📝 Grade Assignments</h2>
            <p>Review and grade student submissions</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 8px; background: <?php echo $messageType === 'success' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $messageType === 'success' ? '#065f46' : '#991b1b'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
        <div class="dashboard-card" style="text-align: center; padding: 1.5rem;">
            <div style="font-size: 2rem; font-weight: bold; color: #3b82f6;"><?php echo $totalSubmissions; ?></div>
            <div style="color: #666;">Total Submissions</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1.5rem;">
            <div style="font-size: 2rem; font-weight: bold; color: #f59e0b;"><?php echo $ungradedCount; ?></div>
            <div style="color: #666;">Pending Grading</div>
        </div>
        <div class="dashboard-card" style="text-align: center; padding: 1.5rem;">
            <div style="font-size: 2rem; font-weight: bold; color: #10b981;"><?php echo $gradedCount; ?></div>
            <div style="color: #666;">Graded</div>
        </div>
    </div>

    <!-- Filters -->
    <div class="dashboard-card" style="margin-bottom: 1.5rem;">
        <form method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center;">
            <div>
                <label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; color: #666;">Assignment</label>
                <select name="assignment" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; min-width: 200px;">
                    <option value="">All Assignments</option>
                    <?php foreach ($allAssignments as $a): ?>
                    <option value="<?php echo $a['assignment_id']; ?>" <?php echo $filterAssignment == $a['assignment_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($a['assignment_name']); ?> (<?php echo $a['course_code']; ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; color: #666;">Status</label>
                <select name="status" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All Status</option>
                    <option value="ungraded" <?php echo $filterStatus === 'ungraded' ? 'selected' : ''; ?>>Ungraded</option>
                    <option value="graded" <?php echo $filterStatus === 'graded' ? 'selected' : ''; ?>>Graded</option>
                </select>
            </div>
            <div style="align-self: flex-end;">
                <button type="submit" class="btn-primary">Filter</button>
                <?php if ($filterAssignment || $filterStatus): ?>
                <a href="instructor_grading.php" class="btn-secondary" style="margin-left: 0.5rem;">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Submissions List -->
    <div class="dashboard-card">
        <h3>📋 Submissions (<?php echo $filteredTotal; ?>)</h3>
        
        <div class="table-container" style="max-height: 600px; overflow-y: auto;">
            <?php if (empty($submissions)): ?>
            <div style="text-align: center; padding: 3rem; color: #666;">
                <p style="font-size: 1.25rem;">No submissions found.</p>
                <p>Students need to submit assignments before you can grade them.</p>
            </div>
            <?php else: ?>
            
            <?php foreach ($submissions as $sub): ?>
            <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; background: <?php echo $sub['grade_id'] ? '#f0fdf4' : '#fffbeb'; ?>;">
                <div style="display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 1rem;">
                    <!-- Left: Submission Info -->
                    <div style="flex: 1; min-width: 300px;">
                        <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem; flex-wrap: wrap;">
                            <span style="padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; background: <?php echo $sub['grade_id'] ? '#d1fae5' : '#fef3c7'; ?>; color: <?php echo $sub['grade_id'] ? '#059669' : '#d97706'; ?>;">
                                <?php echo $sub['grade_id'] ? '✓ Graded' : '⏳ Pending'; ?>
                            </span>
                            <span style="padding: 0.25rem 0.5rem; background: rgba(59, 130, 246, 0.1); color: #3b82f6; border-radius: 4px; font-size: 0.75rem; font-weight: 600;">
                                <?php echo htmlspecialchars($sub['course_code']); ?>
                            </span>
                            <?php if ($sub['submission_status'] === 'late' || strtotime($sub['submission_time']) > strtotime($sub['deadline'])): ?>
                            <span style="padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; background: #fee2e2; color: #dc2626;">Late</span>
                            <?php endif; ?>
                        </div>
                        
                        <h4 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">
                            <?php echo htmlspecialchars($sub['assignment_name']); ?>
                        </h4>
                        
                        <div style="display: grid; gap: 0.25rem; font-size: 0.9rem; color: #666;">
                            <div><strong>Student:</strong> <?php echo htmlspecialchars($sub['student_name']); ?> (<?php echo htmlspecialchars($sub['student_account']); ?>)</div>
                            <div><strong>Submitted:</strong> <?php echo date('Y-m-d H:i', strtotime($sub['submission_time'])); ?></div>
                            <div><strong>Deadline:</strong> <?php echo date('Y-m-d H:i', strtotime($sub['deadline'])); ?></div>
                        </div>
                        
                        <!-- Submission Content -->
                        <?php if ($sub['submission_content']): ?>
                        <div style="margin-top: 1rem;">
                            <strong>Submission Content:</strong>
                            <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 4px; padding: 0.75rem; margin-top: 0.5rem; max-height: 150px; overflow-y: auto; font-size: 0.9rem;">
                                <?php echo nl2br(htmlspecialchars($sub['submission_content'])); ?>
                            </div>
                        </div>
                        <?php else: ?>
                        <div style="margin-top: 1rem; color: #999; font-style: italic;">
                            No submission content provided.
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Right: Grading Form -->
                    <div style="min-width: 280px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem;">
                        <form method="POST">
                            <input type="hidden" name="action" value="grade">
                            <input type="hidden" name="submission_id" value="<?php echo $sub['submission_id']; ?>">
                            
                            <div style="margin-bottom: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Score (0 - 100)</label>
                                <input type="number" name="score" min="0" max="100" step="0.1"
                                       value="<?php echo $sub['score'] ?? ''; ?>" required
                                       style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; font-size: 1.1rem; box-sizing: border-box;">
                            </div>
                            
                            <div style="margin-bottom: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Remarks</label>
                                <textarea name="remarks" rows="3" placeholder="Enter feedback for the student..."
                                          style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; resize: vertical; box-sizing: border-box; min-height: 80px; max-height: 200px; overflow-y: auto;"><?php echo htmlspecialchars($sub['grading_remarks'] ?? ''); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn-primary" style="width: 100%;">
                                <?php echo $sub['grade_id'] ? '📝 Update Grade' : '✅ Submit Grade'; ?>
                            </button>
                            
                            <?php if ($sub['grade_id']): ?>
                            <div style="margin-top: 0.75rem; font-size: 0.85rem; color: #666; text-align: center;">
                                Last graded: <?php echo date('Y-m-d H:i', strtotime($sub['grading_time'])); ?>
                            </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
            <?php if ($page > 1): ?>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn-secondary" style="padding: 0.5rem 1rem;">← Previous</a>
            <?php endif; ?>
            
            <span style="padding: 0.5rem 1rem; color: #666;">
                Page <?php echo $page; ?> of <?php echo $totalPages; ?>
            </span>
            
            <?php if ($page < $totalPages): ?>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn-secondary" style="padding: 0.5rem 1rem;">Next →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.table-container {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}
.table-container::-webkit-scrollbar {
    width: 8px;
}
.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}
.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}
.table-container::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}
textarea {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}
textarea::-webkit-scrollbar {
    width: 6px;
}
textarea::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
}
textarea::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 3px;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>

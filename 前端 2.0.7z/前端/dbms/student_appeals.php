<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'My Appeals';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();

// Get all appeals for this student
$query = "SELECT ga.*, g.score, a.assignment_name, c.course_name,
          (SELECT review_result FROM appeal_reviews WHERE appeal_id = ga.appeal_id ORDER BY review_time DESC LIMIT 1) as review_result
          FROM grade_appeals ga
          JOIN grades g ON ga.grade_id = g.grade_id
          JOIN assignments a ON g.assignment_id = a.assignment_id
          JOIN courses c ON a.course_code = c.course_code
          WHERE ga.student_id = ?
          ORDER BY ga.appeal_submission_time DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$appeals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>⚖️ My Grade Appeals</h2>
            <p>View and track your grade appeals</p>
        </div>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Assignment</th>
                    <th>Course</th>
                    <th>Score</th>
                    <th>Appeal Reason</th>
                    <th>Status</th>
                    <th>Review Result</th>
                    <th>Submitted</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($appeals as $appeal): ?>
                <tr>
                    <td><?php echo htmlspecialchars($appeal['assignment_name']); ?></td>
                    <td><?php echo htmlspecialchars($appeal['course_name']); ?></td>
                    <td><?php echo number_format($appeal['score'], 2); ?></td>
                    <td><?php echo htmlspecialchars(substr($appeal['appeal_reason'], 0, 50)); ?>...</td>
                    <td>
                        <span class="status-badge <?php echo $appeal['appeal_status']; ?>">
                            <?php echo ucfirst($appeal['appeal_status']); ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($appeal['review_result']): ?>
                        <span class="status-badge <?php echo $appeal['review_result'] === 'approve' ? 'approved' : 'rejected'; ?>">
                            <?php echo ucfirst($appeal['review_result']); ?>
                        </span>
                        <?php else: ?>
                        <span class="text-muted">Pending Review</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo date('Y-m-d H:i', strtotime($appeal['appeal_submission_time'])); ?></td>
                    <td>
                        <a href="student_appeal.php?grade_id=<?php echo $appeal['grade_id']; ?>" class="action-btn">View Details</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


<?php
require_once __DIR__ . '/config/course_database.php';
requireStudent();

$pageTitle = 'Grade Appeal';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$studentId = getCurrentUserId();
$gradeId = $_GET['grade_id'] ?? 0;

if (!$gradeId) {
    header('Location: student_grades.php');
    exit();
}

// Get grade details
$stmt = $conn->prepare("SELECT g.*, a.assignment_name, c.course_name FROM grades g
                       JOIN assignments a ON g.assignment_id = a.assignment_id
                       JOIN courses c ON a.course_code = c.course_code
                       WHERE g.grade_id = ? AND g.student_id = ?");
$stmt->bind_param("ii", $gradeId, $studentId);
$stmt->execute();
$grade = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$grade) {
    header('Location: student_grades.php');
    exit();
}

$error = '';
$success = '';

// Handle appeal submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $appealReason = $_POST['appeal_reason'] ?? '';
    $appealMaterials = $_POST['appeal_materials'] ?? '';
    
    if (empty($appealReason)) {
        $error = 'Appeal reason is required';
    } else {
        // Check if appeal already exists
        $checkStmt = $conn->prepare("SELECT appeal_id FROM grade_appeals WHERE grade_id = ? AND student_id = ?");
        $checkStmt->bind_param("ii", $gradeId, $studentId);
        $checkStmt->execute();
        $existing = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
        
        if ($existing) {
            $error = 'An appeal for this grade already exists';
        } else {
            $insertStmt = $conn->prepare("INSERT INTO grade_appeals (appeal_reason, appeal_submission_time, appeal_status, appeal_materials, student_id, grade_id) VALUES (?, NOW(), 'pending', ?, ?, ?)");
            $insertStmt->bind_param("ssii", $appealReason, $appealMaterials, $studentId, $gradeId);
            if ($insertStmt->execute()) {
                $success = 'Appeal submitted successfully! It will be reviewed by your instructor.';
            } else {
                $error = 'Failed to submit appeal';
            }
            $insertStmt->close();
        }
    }
}

// Get existing appeal
$stmt = $conn->prepare("SELECT * FROM grade_appeals WHERE grade_id = ? AND student_id = ?");
$stmt->bind_param("ii", $gradeId, $studentId);
$stmt->execute();
$appeal = $stmt->get_result()->fetch_assoc();
$stmt->close();

$conn->close();
?>

<div class="form-container">
    <div class="page-header">
        <div>
            <h2>⚖️ Grade Appeal</h2>
            <p>Submit an appeal for grade review</p>
        </div>
    </div>

    <div class="dashboard-card">
        <h3>Grade Information</h3>
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Assignment:</span>
                <span class="info-value"><?php echo htmlspecialchars($grade['assignment_name']); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Course:</span>
                <span class="info-value"><?php echo htmlspecialchars($grade['course_name']); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Score:</span>
                <span class="info-value"><?php echo number_format($grade['score'], 2); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Grading Remarks:</span>
                <span class="info-value"><?php echo htmlspecialchars($grade['grading_remarks'] ?? 'N/A'); ?></span>
            </div>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="success-box"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <?php if ($appeal): ?>
    <div class="dashboard-card">
        <h3>Existing Appeal</h3>
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Status:</span>
                <span class="info-value">
                    <span class="status-badge <?php echo $appeal['appeal_status']; ?>">
                        <?php echo ucfirst($appeal['appeal_status']); ?>
                    </span>
                </span>
            </div>
            <div class="info-item">
                <span class="info-label">Submitted:</span>
                <span class="info-value"><?php echo date('Y-m-d H:i', strtotime($appeal['appeal_submission_time'])); ?></span>
            </div>
            <div class="info-item full-width">
                <span class="info-label">Reason:</span>
                <span class="info-value"><?php echo nl2br(htmlspecialchars($appeal['appeal_reason'])); ?></span>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="dashboard-card">
        <h3>Submit Appeal</h3>
        <form method="POST">
            <div class="form-group">
                <label>Appeal Reason *</label>
                <textarea name="appeal_reason" rows="5" required placeholder="Explain why you believe your grade should be reviewed..."></textarea>
            </div>
            <div class="form-group">
                <label>Supporting Materials</label>
                <textarea name="appeal_materials" rows="3" placeholder="Any additional information or evidence..."></textarea>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-primary">Submit Appeal</button>
                <a href="student_grades.php" class="btn-secondary">Back to Grades</a>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


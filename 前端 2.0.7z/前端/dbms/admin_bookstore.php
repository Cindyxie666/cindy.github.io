<?php
require_once __DIR__ . '/config/course_database.php';
requireAdministrator();

$pageTitle = 'Bookstore Management';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$adminId = getCurrentUserId();

$message = '';
$messageType = '';

// Handle supplier approval
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'approve_supplier') {
        $supplierId = $_POST['supplier_id'] ?? 0;
        $approvalResult = $_POST['approval_result'] ?? '';
        $remarks = $_POST['approval_remarks'] ?? '';
        
        if ($supplierId && $approvalResult) {
            $stmt = $conn->prepare("INSERT INTO supplier_approvals (admin_id, supplier_id, approval_time, approval_result, approval_remarks) VALUES (?, ?, NOW(), ?, ?)");
            $stmt->bind_param("iiss", $adminId, $supplierId, $approvalResult, $remarks);
            $stmt->execute();
            $stmt->close();
            
            $status = $approvalResult === 'approve' ? 'active' : 'suspended';
            $updateStmt = $conn->prepare("UPDATE suppliers SET cooperation_status = ? WHERE supplier_id = ?");
            $updateStmt->bind_param("si", $status, $supplierId);
            $updateStmt->execute();
            $updateStmt->close();
            
            $message = "Supplier " . ($approvalResult === 'approve' ? 'approved' : 'rejected') . " successfully!";
            $messageType = "success";
        }
    } elseif ($_POST['action'] === 'add_supplier') {
        $supplierName = $_POST['supplier_name'] ?? '';
        $contactPerson = $_POST['contact_person'] ?? '';
        $contactInfo = $_POST['contact_info'] ?? '';
        $textbookTypes = $_POST['textbook_types_supplied'] ?? '';
        
        if ($supplierName) {
            $stmt = $conn->prepare("INSERT INTO suppliers (supplier_name, contact_person, contact_info, textbook_types_supplied, cooperation_status) VALUES (?, ?, ?, ?, 'pending')");
            $stmt->bind_param("ssss", $supplierName, $contactPerson, $contactInfo, $textbookTypes);
            $stmt->execute();
            $stmt->close();
            
            $message = "Supplier added successfully!";
            $messageType = "success";
        }
    } elseif ($_POST['action'] === 'add_textbook') {
        $title = $_POST['title'] ?? '';
        $author = $_POST['author'] ?? '';
        $isbn = $_POST['isbn'] ?? '';
        $publisher = $_POST['publisher'] ?? '';
        $price = floatval($_POST['price'] ?? 0);
        $stockQuantity = intval($_POST['stock_quantity'] ?? 0);
        $courseCode = $_POST['course_code'] ?? '';
        $supplierId = intval($_POST['supplier_id'] ?? 0);
        
        if ($title && $price > 0) {
            $stmt = $conn->prepare("INSERT INTO textbooks (title, author, isbn, publisher, price, stock_quantity, course_code, supplier_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $courseCodeParam = $courseCode ?: null;
            $supplierIdParam = $supplierId ?: null;
            $stmt->bind_param("ssssdisi", $title, $author, $isbn, $publisher, $price, $stockQuantity, $courseCodeParam, $supplierIdParam);
            $stmt->execute();
            $stmt->close();
            
            $message = "Textbook added successfully!";
            $messageType = "success";
        }
    } elseif ($_POST['action'] === 'update_order_status') {
        $orderId = $_POST['order_id'] ?? 0;
        $newStatus = $_POST['new_status'] ?? '';
        
        if ($orderId && $newStatus) {
            $stmt = $conn->prepare("UPDATE textbook_orders SET order_status = ? WHERE order_id = ?");
            $stmt->bind_param("si", $newStatus, $orderId);
            $stmt->execute();
            $stmt->close();
            
            $message = "Order status updated successfully!";
            $messageType = "success";
        }
    } 
    // ============================================
    // 删除供应商
    // ============================================
    elseif ($_POST['action'] === 'delete_supplier') {
        $supplierId = intval($_POST['supplier_id'] ?? 0);
        
        if ($supplierId) {
            // 检查是否有关联的教科书
            $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM textbooks WHERE supplier_id = ?");
            $checkStmt->bind_param("i", $supplierId);
            $checkStmt->execute();
            $result = $checkStmt->get_result()->fetch_assoc();
            $checkStmt->close();
            
            if ($result['count'] > 0) {
                $message = "Cannot delete supplier: There are {$result['count']} textbook(s) associated with this supplier. Please reassign or delete those textbooks first.";
                $messageType = "error";
            } else {
                // 先删除相关的审批记录
                $deleteApprovals = $conn->prepare("DELETE FROM supplier_approvals WHERE supplier_id = ?");
                $deleteApprovals->bind_param("i", $supplierId);
                $deleteApprovals->execute();
                $deleteApprovals->close();
                
                // 删除供应商
                $stmt = $conn->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
                $stmt->bind_param("i", $supplierId);
                if ($stmt->execute()) {
                    $message = "Supplier deleted successfully!";
                    $messageType = "success";
                } else {
                    $message = "Error deleting supplier: " . $stmt->error;
                    $messageType = "error";
                }
                $stmt->close();
            }
        }
    }
    // ============================================
    // 删除教科书
    // ============================================
    elseif ($_POST['action'] === 'delete_textbook') {
        $textbookId = intval($_POST['textbook_id'] ?? 0);
        
        if ($textbookId) {
            // 检查是否有关联的订单
            $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM textbook_orders WHERE textbook_id = ?");
            $checkStmt->bind_param("i", $textbookId);
            $checkStmt->execute();
            $result = $checkStmt->get_result()->fetch_assoc();
            $checkStmt->close();
            
            if ($result['count'] > 0) {
                $message = "Cannot delete textbook: There are {$result['count']} order(s) for this textbook. Please delete those orders first.";
                $messageType = "error";
            } else {
                $stmt = $conn->prepare("DELETE FROM textbooks WHERE textbook_id = ?");
                $stmt->bind_param("i", $textbookId);
                if ($stmt->execute()) {
                    $message = "Textbook deleted successfully!";
                    $messageType = "success";
                } else {
                    $message = "Error deleting textbook: " . $stmt->error;
                    $messageType = "error";
                }
                $stmt->close();
            }
        }
    }
    // ============================================
    // 删除订单
    // ============================================
    elseif ($_POST['action'] === 'delete_order') {
        $orderId = intval($_POST['order_id'] ?? 0);
        
        if ($orderId) {
            $stmt = $conn->prepare("DELETE FROM textbook_orders WHERE order_id = ?");
            $stmt->bind_param("i", $orderId);
            if ($stmt->execute()) {
                $message = "Order deleted successfully!";
                $messageType = "success";
            } else {
                $message = "Error deleting order: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    }
}

// ============================================
// 获取供应商数据（带搜索和分页）
// ============================================
$supplierSearch = $_GET['supplier_search'] ?? '';
$supplierStatus = $_GET['supplier_status'] ?? '';
$supplierPage = max(1, intval($_GET['supplier_page'] ?? 1));
$perPage = 10;

$supplierWhere = [];
$supplierParams = [];
$supplierTypes = '';

if ($supplierSearch) {
    $supplierWhere[] = "(supplier_name LIKE ? OR contact_person LIKE ?)";
    $supplierParams[] = "%$supplierSearch%";
    $supplierParams[] = "%$supplierSearch%";
    $supplierTypes .= "ss";
}

if ($supplierStatus) {
    $supplierWhere[] = "cooperation_status = ?";
    $supplierParams[] = $supplierStatus;
    $supplierTypes .= "s";
}

$supplierWhereClause = !empty($supplierWhere) ? "WHERE " . implode(" AND ", $supplierWhere) : "";

// 获取供应商总数
$countQuery = "SELECT COUNT(*) as total FROM suppliers $supplierWhereClause";
if (!empty($supplierParams)) {
    $countStmt = $conn->prepare($countQuery);
    $countStmt->bind_param($supplierTypes, ...$supplierParams);
    $countStmt->execute();
    $supplierTotal = $countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
} else {
    $supplierTotal = $conn->query($countQuery)->fetch_assoc()['total'];
}

$supplierTotalPages = ceil($supplierTotal / $perPage);
$supplierOffset = ($supplierPage - 1) * $perPage;

// 获取供应商列表
$supplierQuery = "SELECT * FROM suppliers $supplierWhereClause ORDER BY supplier_id DESC LIMIT $perPage OFFSET $supplierOffset";
if (!empty($supplierParams)) {
    $supplierStmt = $conn->prepare($supplierQuery);
    $supplierStmt->bind_param($supplierTypes, ...$supplierParams);
    $supplierStmt->execute();
    $suppliers = $supplierStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $supplierStmt->close();
} else {
    $suppliers = $conn->query($supplierQuery)->fetch_all(MYSQLI_ASSOC);
}

// ============================================
// 获取教科书数据（带搜索和分页）
// ============================================
$textbookSearch = $_GET['textbook_search'] ?? '';
$textbookCourse = $_GET['textbook_course'] ?? '';
$textbookPage = max(1, intval($_GET['textbook_page'] ?? 1));

$textbookWhere = [];
$textbookParams = [];
$textbookTypes = '';

if ($textbookSearch) {
    $textbookWhere[] = "(t.title LIKE ? OR t.author LIKE ? OR t.isbn LIKE ?)";
    $textbookParams[] = "%$textbookSearch%";
    $textbookParams[] = "%$textbookSearch%";
    $textbookParams[] = "%$textbookSearch%";
    $textbookTypes .= "sss";
}

if ($textbookCourse) {
    $textbookWhere[] = "t.course_code = ?";
    $textbookParams[] = $textbookCourse;
    $textbookTypes .= "s";
}

$textbookWhereClause = !empty($textbookWhere) ? "WHERE " . implode(" AND ", $textbookWhere) : "";

// 获取教科书总数
$countQuery = "SELECT COUNT(*) as total FROM textbooks t $textbookWhereClause";
if (!empty($textbookParams)) {
    $countStmt = $conn->prepare($countQuery);
    $countStmt->bind_param($textbookTypes, ...$textbookParams);
    $countStmt->execute();
    $textbookTotal = $countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
} else {
    $textbookTotal = $conn->query($countQuery)->fetch_assoc()['total'];
}

$textbookTotalPages = ceil($textbookTotal / $perPage);
$textbookOffset = ($textbookPage - 1) * $perPage;

// 获取教科书列表
$textbookQuery = "SELECT t.*, c.course_name, s.supplier_name 
                  FROM textbooks t 
                  LEFT JOIN courses c ON t.course_code = c.course_code 
                  LEFT JOIN suppliers s ON t.supplier_id = s.supplier_id 
                  $textbookWhereClause 
                  ORDER BY t.textbook_id DESC 
                  LIMIT $perPage OFFSET $textbookOffset";
if (!empty($textbookParams)) {
    $textbookStmt = $conn->prepare($textbookQuery);
    $textbookStmt->bind_param($textbookTypes, ...$textbookParams);
    $textbookStmt->execute();
    $textbooks = $textbookStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $textbookStmt->close();
} else {
    $textbooks = $conn->query($textbookQuery)->fetch_all(MYSQLI_ASSOC);
}

// ============================================
// 获取订单数据（带搜索和分页）
// ============================================
$orderSearch = $_GET['order_search'] ?? '';
$orderStatus = $_GET['order_status'] ?? '';
$orderPage = max(1, intval($_GET['order_page'] ?? 1));

$orderWhere = [];
$orderParams = [];
$orderTypes = '';

if ($orderSearch) {
    $orderWhere[] = "(s.name LIKE ? OR t.title LIKE ?)";
    $orderParams[] = "%$orderSearch%";
    $orderParams[] = "%$orderSearch%";
    $orderTypes .= "ss";
}

if ($orderStatus) {
    $orderWhere[] = "o.order_status = ?";
    $orderParams[] = $orderStatus;
    $orderTypes .= "s";
}

$orderWhereClause = !empty($orderWhere) ? "WHERE " . implode(" AND ", $orderWhere) : "";

// 获取订单总数
$countQuery = "SELECT COUNT(*) as total FROM textbook_orders o 
               JOIN students s ON o.student_id = s.student_id 
               JOIN textbooks t ON o.textbook_id = t.textbook_id 
               $orderWhereClause";
if (!empty($orderParams)) {
    $countStmt = $conn->prepare($countQuery);
    $countStmt->bind_param($orderTypes, ...$orderParams);
    $countStmt->execute();
    $orderTotal = $countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
} else {
    $orderTotal = $conn->query($countQuery)->fetch_assoc()['total'];
}

$orderTotalPages = ceil($orderTotal / $perPage);
$orderOffset = ($orderPage - 1) * $perPage;

// 获取订单列表
$orderQuery = "SELECT o.*, s.name as student_name, t.title as textbook_title, t.isbn 
               FROM textbook_orders o 
               JOIN students s ON o.student_id = s.student_id 
               JOIN textbooks t ON o.textbook_id = t.textbook_id 
               $orderWhereClause 
               ORDER BY o.order_time DESC 
               LIMIT $perPage OFFSET $orderOffset";
if (!empty($orderParams)) {
    $orderStmt = $conn->prepare($orderQuery);
    $orderStmt->bind_param($orderTypes, ...$orderParams);
    $orderStmt->execute();
    $orders = $orderStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $orderStmt->close();
} else {
    $orders = $conn->query($orderQuery)->fetch_all(MYSQLI_ASSOC);
}

// 获取课程列表（用于下拉选择）
$courses = $conn->query("SELECT course_code, course_name FROM courses WHERE course_status = 'active' ORDER BY course_code")->fetch_all(MYSQLI_ASSOC);

// 获取活跃供应商列表（用于下拉选择）
$activeSuppliers = $conn->query("SELECT supplier_id, supplier_name FROM suppliers WHERE cooperation_status = 'active' ORDER BY supplier_name")->fetch_all(MYSQLI_ASSOC);

$conn->close();

// 构建分页URL参数
function buildPaginationUrl($params, $pageKey, $pageValue) {
    $params[$pageKey] = $pageValue;
    return '?' . http_build_query($params);
}

$currentParams = $_GET;
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📚 Bookstore Management</h2>
            <p>Manage suppliers, textbooks, and orders</p>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 1rem; padding: 1rem; border-radius: 4px; background: <?php echo $messageType === 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $messageType === 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- ============================================
         供应商管理
         ============================================ -->
    <div class="dashboard-card" style="margin-bottom: 2rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3>🏢 Suppliers (<?php echo $supplierTotal; ?>)</h3>
            <button onclick="document.getElementById('addSupplierModal').style.display='flex'" class="btn-primary">+ Add Supplier</button>
        </div>
        
        <!-- 搜索和筛选 -->
        <form method="GET" style="display: flex; gap: 1rem; margin-bottom: 1rem; flex-wrap: wrap;">
            <input type="text" name="supplier_search" placeholder="Search suppliers..." value="<?php echo htmlspecialchars($supplierSearch); ?>" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; min-width: 200px;">
            <select name="supplier_status" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">All Status</option>
                <option value="active" <?php echo $supplierStatus === 'active' ? 'selected' : ''; ?>>Active</option>
                <option value="pending" <?php echo $supplierStatus === 'pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="suspended" <?php echo $supplierStatus === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
            </select>
            <!-- 保留其他分页参数 -->
            <input type="hidden" name="textbook_search" value="<?php echo htmlspecialchars($textbookSearch); ?>">
            <input type="hidden" name="textbook_course" value="<?php echo htmlspecialchars($textbookCourse); ?>">
            <input type="hidden" name="textbook_page" value="<?php echo $textbookPage; ?>">
            <input type="hidden" name="order_search" value="<?php echo htmlspecialchars($orderSearch); ?>">
            <input type="hidden" name="order_status" value="<?php echo htmlspecialchars($orderStatus); ?>">
            <input type="hidden" name="order_page" value="<?php echo $orderPage; ?>">
            <button type="submit" class="btn-primary">Search</button>
            <?php if ($supplierSearch || $supplierStatus): ?>
            <a href="admin_bookstore.php" class="btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
        
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Supplier Name</th>
                        <th>Contact Person</th>
                        <th>Contact Info</th>
                        <th>Textbook Types</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($suppliers)): ?>
                    <tr><td colspan="7" style="text-align: center; padding: 2rem; color: #666;">No suppliers found</td></tr>
                    <?php else: ?>
                    <?php foreach ($suppliers as $supplier): ?>
                    <tr>
                        <td><?php echo $supplier['supplier_id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($supplier['supplier_name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($supplier['contact_person'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($supplier['contact_info'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars(substr($supplier['textbook_types_supplied'] ?? '', 0, 30)); ?><?php echo strlen($supplier['textbook_types_supplied'] ?? '') > 30 ? '...' : ''; ?></td>
                        <td>
                            <span class="status-badge <?php echo $supplier['cooperation_status']; ?>">
                                <?php echo ucfirst($supplier['cooperation_status']); ?>
                            </span>
                        </td>
                        <td>
                            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                <?php if ($supplier['cooperation_status'] === 'pending'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="approve_supplier">
                                    <input type="hidden" name="supplier_id" value="<?php echo $supplier['supplier_id']; ?>">
                                    <input type="hidden" name="approval_result" value="approve">
                                    <button type="submit" class="action-btn success" title="Approve">✓ Approve</button>
                                </form>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="approve_supplier">
                                    <input type="hidden" name="supplier_id" value="<?php echo $supplier['supplier_id']; ?>">
                                    <input type="hidden" name="approval_result" value="reject">
                                    <button type="submit" class="action-btn warning" title="Reject">✗ Reject</button>
                                </form>
                                <?php endif; ?>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this supplier? This action cannot be undone.');">
                                    <input type="hidden" name="action" value="delete_supplier">
                                    <input type="hidden" name="supplier_id" value="<?php echo $supplier['supplier_id']; ?>">
                                    <button type="submit" class="btn-danger small" title="Delete">🗑 Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- 分页 -->
        <?php if ($supplierTotalPages > 1): ?>
        <div class="pagination" style="margin-top: 1rem; display: flex; gap: 0.5rem; justify-content: center;">
            <?php if ($supplierPage > 1): ?>
            <a href="<?php echo buildPaginationUrl($currentParams, 'supplier_page', $supplierPage - 1); ?>" class="btn-secondary">← Prev</a>
            <?php endif; ?>
            <span style="padding: 0.5rem 1rem;">Page <?php echo $supplierPage; ?> of <?php echo $supplierTotalPages; ?></span>
            <?php if ($supplierPage < $supplierTotalPages): ?>
            <a href="<?php echo buildPaginationUrl($currentParams, 'supplier_page', $supplierPage + 1); ?>" class="btn-secondary">Next →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- ============================================
         教科书管理
         ============================================ -->
    <div class="dashboard-card" style="margin-bottom: 2rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3>📖 Textbooks (<?php echo $textbookTotal; ?>)</h3>
            <button onclick="document.getElementById('addTextbookModal').style.display='flex'" class="btn-primary">+ Add Textbook</button>
        </div>
        
        <!-- 搜索和筛选 -->
        <form method="GET" style="display: flex; gap: 1rem; margin-bottom: 1rem; flex-wrap: wrap;">
            <input type="text" name="textbook_search" placeholder="Search textbooks..." value="<?php echo htmlspecialchars($textbookSearch); ?>" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; min-width: 200px;">
            <select name="textbook_course" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">All Courses</option>
                <?php foreach ($courses as $course): ?>
                <option value="<?php echo htmlspecialchars($course['course_code']); ?>" <?php echo $textbookCourse === $course['course_code'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($course['course_name']); ?></option>
                <?php endforeach; ?>
            </select>
            <!-- 保留其他分页参数 -->
            <input type="hidden" name="supplier_search" value="<?php echo htmlspecialchars($supplierSearch); ?>">
            <input type="hidden" name="supplier_status" value="<?php echo htmlspecialchars($supplierStatus); ?>">
            <input type="hidden" name="supplier_page" value="<?php echo $supplierPage; ?>">
                      <input type="hidden" name="order_search" value="<?php echo htmlspecialchars($orderSearch); ?>">
            <input type="hidden" name="order_status" value="<?php echo htmlspecialchars($orderStatus); ?>">
            <input type="hidden" name="order_page" value="<?php echo $orderPage; ?>">
            <button type="submit" class="btn-primary">Search</button>
            <?php if ($textbookSearch || $textbookCourse): ?>
            <a href="admin_bookstore.php" class="btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
        
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>ISBN</th>
                        <th>Publisher</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Course</th>
                        <th>Supplier</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($textbooks)): ?>
                    <tr><td colspan="10" style="text-align: center; padding: 2rem; color: #666;">No textbooks found</td></tr>
                    <?php else: ?>
                    <?php foreach ($textbooks as $textbook): ?>
                    <tr>
                        <td><?php echo $textbook['textbook_id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($textbook['title']); ?></strong></td>
                        <td><?php echo htmlspecialchars($textbook['author'] ?? 'N/A'); ?></td>
                        <td style="font-family: monospace; font-size: 0.85rem;"><?php echo htmlspecialchars($textbook['isbn'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($textbook['publisher'] ?? 'N/A'); ?></td>
                        <td style="color: #059669; font-weight: 600;">$<?php echo number_format($textbook['price'], 2); ?></td>
                        <td>
                            <span style="<?php echo $textbook['stock_quantity'] < 10 ? 'color: #dc2626;' : ''; ?>">
                                <?php echo $textbook['stock_quantity']; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($textbook['course_code'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($textbook['supplier_name'] ?? 'N/A'); ?></td>
                        <td>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this textbook? This action cannot be undone.');">
                                <input type="hidden" name="action" value="delete_textbook">
                                <input type="hidden" name="textbook_id" value="<?php echo $textbook['textbook_id']; ?>">
                                <button type="submit" class="btn-danger small" title="Delete">🗑 Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- 分页 -->
        <?php if ($textbookTotalPages > 1): ?>
        <div class="pagination" style="margin-top: 1rem; display: flex; gap: 0.5rem; justify-content: center;">
            <?php if ($textbookPage > 1): ?>
            <a href="<?php echo buildPaginationUrl($currentParams, 'textbook_page', $textbookPage - 1); ?>" class="btn-secondary">← Prev</a>
            <?php endif; ?>
            <span style="padding: 0.5rem 1rem;">Page <?php echo $textbookPage; ?> of <?php echo $textbookTotalPages; ?></span>
            <?php if ($textbookPage < $textbookTotalPages): ?>
            <a href="<?php echo buildPaginationUrl($currentParams, 'textbook_page', $textbookPage + 1); ?>" class="btn-secondary">Next →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- ============================================
         订单管理
         ============================================ -->
    <div class="dashboard-card" style="margin-bottom: 2rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3>📦 Recent Orders (<?php echo $orderTotal; ?>)</h3>
        </div>
        
        <!-- 搜索和筛选 -->
        <form method="GET" style="display: flex; gap: 1rem; margin-bottom: 1rem; flex-wrap: wrap;">
            <input type="text" name="order_search" placeholder="Search by student or textbook..." value="<?php echo htmlspecialchars($orderSearch); ?>" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; min-width: 200px;">
            <select name="order_status" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">All Status</option>
                <option value="pending" <?php echo $orderStatus === 'pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="confirmed" <?php echo $orderStatus === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                <option value="shipped" <?php echo $orderStatus === 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                <option value="delivered" <?php echo $orderStatus === 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                <option value="cancelled" <?php echo $orderStatus === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>
            <!-- 保留其他分页参数 -->
            <input type="hidden" name="supplier_search" value="<?php echo htmlspecialchars($supplierSearch); ?>">
            <input type="hidden" name="supplier_status" value="<?php echo htmlspecialchars($supplierStatus); ?>">
            <input type="hidden" name="supplier_page" value="<?php echo $supplierPage; ?>">
            <input type="hidden" name="textbook_search" value="<?php echo htmlspecialchars($textbookSearch); ?>">
            <input type="hidden" name="textbook_course" value="<?php echo htmlspecialchars($textbookCourse); ?>">
            <input type="hidden" name="textbook_page" value="<?php echo $textbookPage; ?>">
            <button type="submit" class="btn-primary">Search</button>
            <?php if ($orderSearch || $orderStatus): ?>
            <a href="admin_bookstore.php" class="btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
        
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Student</th>
                        <th>Textbook</th>
                        <th>ISBN</th>
                        <th>Quantity</th>
                        <th>Total Amount</th>
                        <th>Order Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                    <tr><td colspan="9" style="text-align: center; padding: 2rem; color: #666;">No orders found</td></tr>
                    <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>#<?php echo $order['order_id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($order['student_name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($order['textbook_title']); ?></td>
                        <td style="font-family: monospace; font-size: 0.85rem;"><?php echo htmlspecialchars($order['isbn'] ?? 'N/A'); ?></td>
                        <td><?php echo $order['quantity_purchased']; ?></td>
                        <td style="color: #059669; font-weight: 600;">$<?php echo number_format($order['total_amount'], 2); ?></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($order['order_time'])); ?></td>
                        <td>
                            <span class="status-badge <?php echo $order['order_status']; ?>">
                                <?php echo ucfirst($order['order_status']); ?>
                            </span>
                        </td>
                        <td>
                            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                <?php if ($order['order_status'] !== 'delivered' && $order['order_status'] !== 'cancelled'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_order_status">
                                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                    <select name="new_status" onchange="this.form.submit()" style="padding: 0.25rem; border-radius: 4px; border: 1px solid #ddd; font-size: 0.85rem;">
                                        <option value="">Update...</option>
                                        <?php if ($order['order_status'] === 'pending'): ?>
                                        <option value="confirmed">→ Confirmed</option>
                                        <option value="cancelled">→ Cancelled</option>
                                        <?php elseif ($order['order_status'] === 'confirmed'): ?>
                                        <option value="shipped">→ Shipped</option>
                                        <option value="cancelled">→ Cancelled</option>
                                        <?php elseif ($order['order_status'] === 'shipped'): ?>
                                        <option value="delivered">→ Delivered</option>
                                        <?php endif; ?>
                                    </select>
                                </form>
                                <?php endif; ?>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this order? This action cannot be undone.');">
                                    <input type="hidden" name="action" value="delete_order">
                                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                    <button type="submit" class="btn-danger small" title="Delete">🗑 Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- 分页 -->
        <?php if ($orderTotalPages > 1): ?>
        <div class="pagination" style="margin-top: 1rem; display: flex; gap: 0.5rem; justify-content: center;">
            <?php if ($orderPage > 1): ?>
            <a href="<?php echo buildPaginationUrl($currentParams, 'order_page', $orderPage - 1); ?>" class="btn-secondary">← Prev</a>
            <?php endif; ?>
            <span style="padding: 0.5rem 1rem;">Page <?php echo $orderPage; ?> of <?php echo $orderTotalPages; ?></span>
            <?php if ($orderPage < $orderTotalPages): ?>
            <a href="<?php echo buildPaginationUrl($currentParams, 'order_page', $orderPage + 1); ?>" class="btn-secondary">Next →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- ============================================
     添加供应商模态框
     ============================================ -->
<div id="addSupplierModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000;">
    <div class="modal-content" style="background: white; padding: 2rem; border-radius: 8px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
            <h3>🏢 Add New Supplier</h3>
            <button onclick="document.getElementById('addSupplierModal').style.display='none'" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add_supplier">
            
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Supplier Name *</label>
                <input type="text" name="supplier_name" required style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
            </div>
            
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Contact Person</label>
                <input type="text" name="contact_person" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
            </div>
            
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Contact Info</label>
                <input type="text" name="contact_info" placeholder="Email or phone" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
            </div>
            
            <div class="form-group" style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Textbook Types Supplied</label>
                <textarea name="textbook_types_supplied" rows="3" placeholder="e.g., Computer Science, Mathematics, Physics" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; resize: vertical;"></textarea>
            </div>
            
            <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                <button type="button" onclick="document.getElementById('addSupplierModal').style.display='none'" class="btn-secondary">Cancel</button>
                <button type="submit" class="btn-primary">Add Supplier</button>
            </div>
        </form>
    </div>
</div>

<!-- ============================================
     添加教科书模态框
     ============================================ -->
<div id="addTextbookModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000;">
    <div class="modal-content" style="background: white; padding: 2rem; border-radius: 8px; width: 90%; max-width: 600px; max-height: 90vh; overflow-y: auto;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
            <h3>📖 Add New Textbook</h3>
            <button onclick="document.getElementById('addTextbookModal').style.display='none'" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add_textbook">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Title *</label>
                    <input type="text" name="title" required style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Author</label>
                    <input type="text" name="author" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">ISBN</label>
                    <input type="text" name="isbn" placeholder="978-XXXXXXXXXX" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Publisher</label>
                    <input type="text" name="publisher" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Price ($) *</label>
                    <input type="number" name="price" step="0.01" min="0" required style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Stock Quantity</label>
                    <input type="number" name="stock_quantity" min="0" value="0" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Course</label>
                    <select name="course_code" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                        <option value="">-- Select Course --</option>
                        <?php foreach ($courses as $course): ?>
                        <option value="<?php echo htmlspecialchars($course['course_code']); ?>"><?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Supplier</label>
                    <select name="supplier_id" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;">
                        <option value="">-- Select Supplier --</option>
                        <?php foreach ($activeSuppliers as $supplier): ?>
                        <option value="<?php echo $supplier['supplier_id']; ?>"><?php echo htmlspecialchars($supplier['supplier_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1.5rem;">
                <button type="button" onclick="document.getElementById('addTextbookModal').style.display='none'" class="btn-secondary">Cancel</button>
                <button type="submit" class="btn-primary">Add Textbook</button>
            </div>
        </form>
    </div>
</div>

<style>
/* 状态徽章样式 */
.status-badge {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-badge.active,
.status-badge.delivered {
    background: #d1fae5;
    color: #059669;
}

.status-badge.pending {
    background: #fef3c7;
    color: #d97706;
}

.status-badge.suspended,
.status-badge.cancelled {
    background: #fee2e2;
    color: #dc2626;
}

.status-badge.confirmed {
    background: #dbeafe;
    color: #2563eb;
}

.status-badge.shipped {
    background: #e0e7ff;
    color: #4f46e5;
}

/* 操作按钮样式 */
.action-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.375rem 0.75rem;
    border: none;
    border-radius: 0.375rem;
    font-size: 0.75rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
}

.action-btn.success {
    background: #d1fae5;
    color: #059669;
}

.action-btn.success:hover {
    background: #a7f3d0;
}

.action-btn.warning {
    background: #fee2e2;
    color: #dc2626;
}

.action-btn.warning:hover {
    background: #fecaca;
}

/* 删除按钮样式 */
.btn-danger {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.375rem 0.75rem;
    background: #ef4444;
    color: white;
    border: none;
    border-radius: 0.375rem;
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s;
    text-decoration: none;
}

.btn-danger:hover {
    background: #dc2626;
}

.btn-danger.small {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
}

/* 模态框滚动条 */
.modal-content {
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}

.modal-content::-webkit-scrollbar {
    width: 8px;
}

.modal-content::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.modal-content::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}

.modal-content::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}

/* 表格容器滚动条 */
.table-container {
    overflow-x: auto;
    overflow-y: auto;
    max-height: 500px;
    scrollbar-width: thin;
    scrollbar-color: #c1c1c1 #f1f1f1;
}

.table-container::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}
</style>

<script>
// 点击模态框外部关闭
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.style.display = 'none';
        }
    });
});

// ESC 键关闭模态框
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
    }
});
</script>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


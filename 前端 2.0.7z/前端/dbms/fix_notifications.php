<?php
// 直接连接数据库（不依赖配置文件）
$conn = new mysqli('localhost', 'root', '', 'course_management_system');

if ($conn->connect_error) {
    die("<h2 style='color:red;'>❌ 数据库连接失败: " . $conn->connect_error . "</h2>");
}

echo "<h1>🔧 创建 Notifications 表</h1>";

// 创建表
$sql = "CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    notification_content TEXT NOT NULL,
    notification_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read TINYINT(1) DEFAULT 0,
    student_id INT NOT NULL,
    instructor_id INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql)) {
    echo "<p style='color:green; font-size:24px;'>✅ 表创建成功！</p>";
    
    // 检查是否已有数据
    $check = $conn->query("SELECT COUNT(*) as cnt FROM notifications");
    $count = $check->fetch_assoc()['cnt'];
    
    if ($count == 0) {
        // 插入测试数据
        $result = $conn->query("INSERT INTO notifications (notification_content, notification_time, is_read, student_id) 
            SELECT CONCAT('Welcome, ', name, '! This is your notification center.'), NOW(), 0, student_id 
            FROM students LIMIT 10");
        
        if ($result) {
            echo "<p style='color:blue;'>📬 已创建测试通知数据</p>";
        }
    } else {
        echo "<p>📊 表中已有 $count 条通知</p>";
    }
    
    echo "<br><a href='student_notifications.php' style='display:inline-block; padding:15px 30px; background:#4CAF50; color:white; text-decoration:none; border-radius:5px; font-size:18px;'>✅ 前往通知页面</a>";
    
} else {
    echo "<p style='color:red; font-size:20px;'>❌ 创建失败: " . $conn->error . "</p>";
}

$conn->close();
?>

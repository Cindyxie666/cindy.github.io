# Database Setup Guide - Course Management System

## Quick Answer

**No, you do NOT need to manually create the database.** The `course_management_schema.sql` file contains a `CREATE DATABASE` statement that will automatically create the database for you.

## Setup Methods

### Method 1: Import SQL File Directly (Easiest)

1. Open phpMyAdmin: http://localhost/phpmyadmin
2. Click the **"Import"** tab at the top
3. Click **"Choose File"** and select `course_management_schema.sql`
4. Click **"Go"** button
5. Done! The database `course_management_system` and all tables will be created automatically

### Method 2: Create Database First, Then Import

If you prefer to create the database manually first:

1. Open phpMyAdmin: http://localhost/phpmyadmin
2. Click **"New"** in the left sidebar
3. Enter database name: `course_management_system`
4. Choose collation: `utf8mb4_general_ci` (optional)
5. Click **"Create"**
6. Select the `course_management_system` database from left sidebar
7. Click **"Import"** tab
8. Select `course_management_schema.sql` file
9. Click **"Go"**

### Method 3: Using Command Line

```bash
# Navigate to project directory
cd /path/to/dbms

# Import SQL file (creates database automatically)
mysql -u root -p < course_management_schema.sql

# Or specify database name explicitly
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS course_management_system;"
mysql -u root -p course_management_system < course_management_schema.sql
```

## What the SQL File Does

The `course_management_schema.sql` file contains:

1. `CREATE DATABASE IF NOT EXISTS course_management_system;` - Creates the database
2. `USE course_management_system;` - Selects the database
3. Multiple `CREATE TABLE` statements - Creates all 13 entity tables
4. Relationship tables - Creates all 14+ relationship tables
5. Foreign key constraints - Sets up relationships with CASCADE delete
6. Indexes - Optimizes query performance

## Verification

After importing, verify the database was created:

1. In phpMyAdmin, check the left sidebar - you should see `course_management_system`
2. Click on `course_management_system` to see all tables:
   - students
   - instructors
   - administrators
   - courses
   - assignments
   - assignment_submissions
   - grades
   - grade_appeals
   - announcements
   - textbooks
   - textbook_orders
   - suppliers
   - teaching_evaluations
   - enrollments
   - teaching
   - course_management
   - appeal_reviews
   - supplier_approvals
   - evaluation_releases

## Troubleshooting

### Error: "Database already exists"
- This is fine! The `IF NOT EXISTS` clause prevents errors
- You can proceed or drop the existing database first

### Error: "Access denied"
- Check MySQL username and password in `config/course_database.php`
- Default XAMPP MySQL user is `root` with no password

### Error: "Table already exists"
- Drop the existing database: `DROP DATABASE course_management_system;`
- Then import the SQL file again

## Next Steps

After database setup:

1. **Generate sample data** (optional but recommended):
   ```bash
   php generate_course_data.php
   ```

2. **Access the application**:
   - URL: http://localhost/dbms/course_login.php
   - Student: `student1` / `password`
   - Instructor: `instructor1` / `password`
   - Admin: `admin` / `password`

<?php
require_once __DIR__ . '/config/course_database.php';
requireInstructor();

$pageTitle = 'My Courses';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$instructorId = getCurrentUserId();

$message = '';
$messageType = '';

// Function to generate next course code for a category
// This function should be called within a transaction
function generateCourseCode($conn, $category) {
    // Find the maximum sequence number for this category
    // Use FOR UPDATE to lock rows and prevent concurrent access
    $stmt = $conn->prepare("SELECT course_code FROM courses WHERE course_code LIKE ? ORDER BY CAST(SUBSTRING_INDEX(course_code, '-', -1) AS UNSIGNED) DESC, course_code DESC LIMIT 1 FOR UPDATE");
    $pattern = $category . '-%';
    $stmt->bind_param("s", $pattern);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    $nextNumber = 1;
    
    if ($result) {
        // Extract the number part from the existing course code (e.g., "MR-001" -> 1)
        $existingCode = $result['course_code'];
        $parts = explode('-', $existingCode);
        if (count($parts) == 2 && is_numeric($parts[1])) {
            $nextNumber = intval($parts[1]) + 1;
        }
    }
    
    // Format as category-XXX (e.g., MR-001, ME-042)
    $courseCode = $category . '-' . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
    
    // Double-check to ensure uniqueness (in case of race condition)
    $checkStmt = $conn->prepare("SELECT course_code FROM courses WHERE course_code = ?");
    $checkStmt->bind_param("s", $courseCode);
    $checkStmt->execute();
    $exists = $checkStmt->get_result()->fetch_assoc();
    $checkStmt->close();
    
    // If exists, increment and try again
    while ($exists) {
        $nextNumber++;
        $courseCode = $category . '-' . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
        $checkStmt = $conn->prepare("SELECT course_code FROM courses WHERE course_code = ?");
        $checkStmt->bind_param("s", $courseCode);
        $checkStmt->execute();
        $exists = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
    }
    
    return $courseCode;
}

// Handle create course
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_course') {
    $courseCategory = trim($_POST['course_category'] ?? '');
    $courseName = trim($_POST['course_name'] ?? '');
    $creditHours = intval($_POST['credit_hours'] ?? 3);
    $description = trim($_POST['course_description'] ?? '');
    $semesterYear = trim($_POST['semester_year'] ?? '');
    $semesterTerm = trim($_POST['semester_term'] ?? '');
    
    // Combine year and term into semester string
    $semester = '';
    if (!empty($semesterYear) && !empty($semesterTerm)) {
        $semester = $semesterTerm . ' ' . $semesterYear;
    }
    
    if (empty($courseCategory) || !in_array($courseCategory, ['MR', 'ME', 'GE', 'FE'])) {
        $message = "Please select a valid course category!";
        $messageType = "error";
    } elseif (empty($courseName)) {
        $message = "Course name is required!";
        $messageType = "error";
    } elseif ($creditHours < 1 || $creditHours > 6) {
        $message = "Credit hours must be between 1 and 6!";
        $messageType = "error";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Generate course code automatically
            $courseCode = generateCourseCode($conn, $courseCategory);
            
            // Insert course with category
            $stmt = $conn->prepare("INSERT INTO courses (course_code, course_category, course_name, credit_hours, course_description, semester_offered, course_status) VALUES (?, ?, ?, ?, ?, ?, 'draft')");
            $stmt->bind_param("sssiss", $courseCode, $courseCategory, $courseName, $creditHours, $description, $semester);
            
            if (!$stmt->execute()) {
                throw new Exception("Error creating course: " . $stmt->error);
            }
            $stmt->close();
            
            // Add teaching relationship
            $teachingClass = ''; // Default empty class
            $teachStmt = $conn->prepare("INSERT INTO teaching (instructor_id, course_code, teaching_semester, teaching_class) VALUES (?, ?, ?, ?)");
            $teachStmt->bind_param("isss", $instructorId, $courseCode, $semester, $teachingClass);
            
            if (!$teachStmt->execute()) {
                throw new Exception("Error creating teaching relationship: " . $teachStmt->error);
            }
            $teachStmt->close();
            
            // Save course schedules (time slots)
            if (isset($_POST['schedule_slots']) && is_array($_POST['schedule_slots'])) {
                $scheduleStmt = $conn->prepare("INSERT INTO course_schedules (course_code, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)");
                
                foreach ($_POST['schedule_slots'] as $slot) {
                    // Format: "Monday-08:00" -> day="Monday", time="08:00"
                    $parts = explode('-', $slot);
                    if (count($parts) == 2) {
                        $day = $parts[0];
                        $startTime = $parts[1] . ':00'; // Add seconds
                        
                        // Calculate end time (50 minutes later)
                        $startTimestamp = strtotime($startTime);
                        $endTimestamp = $startTimestamp + (50 * 60); // 50 minutes
                        $endTime = date('H:i:s', $endTimestamp);
                        
                        // Validate day
                        if (in_array($day, ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'])) {
                            $scheduleStmt->bind_param("ssss", $courseCode, $day, $startTime, $endTime);
                            if (!$scheduleStmt->execute()) {
                                throw new Exception("Error saving course schedule: " . $scheduleStmt->error);
                            }
                        }
                    }
                }
                $scheduleStmt->close();
            }
            
            // Commit transaction
            $conn->commit();
            
            // Redirect to prevent form resubmission with generated course code
            header('Location: instructor_courses.php?success=1&code=' . urlencode($courseCode));
            exit();
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $message = $e->getMessage();
            $messageType = "error";
        }
    }
}

// Handle success message from redirect
if (isset($_GET['success']) && $_GET['success'] == '1') {
    $generatedCode = $_GET['code'] ?? '';
    if ($generatedCode) {
        $message = "Course created successfully! Course Code: " . htmlspecialchars($generatedCode);
    } else {
        $message = "Course created successfully!";
    }
    $messageType = "success";
}

// Get courses taught by this instructor
$query = "SELECT c.*, t.teaching_semester, t.teaching_class,
          (SELECT COUNT(*) FROM enrollments WHERE course_code = c.course_code) as enrollment_count,
          (SELECT COUNT(*) FROM assignments WHERE course_code = c.course_code) as assignment_count
          FROM courses c
          JOIN teaching t ON c.course_code = t.course_code
          WHERE t.instructor_id = ?
          ORDER BY c.course_category, c.course_code";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $instructorId);
$stmt->execute();
$courses = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get schedules for all courses
$courseCodes = array_column($courses, 'course_code');
$schedules = [];
if (!empty($courseCodes)) {
    $placeholders = str_repeat('?,', count($courseCodes) - 1) . '?';
    $scheduleQuery = "SELECT course_code, day_of_week, start_time, end_time 
                      FROM course_schedules 
                      WHERE course_code IN ($placeholders)
                      ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'), start_time";
    $scheduleStmt = $conn->prepare($scheduleQuery);
    $scheduleStmt->bind_param(str_repeat('s', count($courseCodes)), ...$courseCodes);
    $scheduleStmt->execute();
    $scheduleResults = $scheduleStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $scheduleStmt->close();
    
    // Group schedules by course_code
    foreach ($scheduleResults as $schedule) {
        $schedules[$schedule['course_code']][] = $schedule;
    }
}
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📚 My Courses</h2>
            <p>Create and manage your courses</p>
        </div>
        <button onclick="showCreateModal()" class="btn-primary">+ Create Course</button>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin: 1rem 0; padding: 1rem; border-radius: 4px; background: <?php echo $messageType === 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $messageType === 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Category</th>
                    <th>Course Name</th>
                    <th>Credit Hours</th>
                    <th>Semester</th>
                    <th>Schedule</th>
                    <th>Enrollments</th>
                    <th>Assignments</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $course): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($course['course_code']); ?></strong></td>
                    <td>
                        <span class="role-badge" style="background: <?php 
                            $category = $course['course_category'] ?? 'MR';
                            echo $category === 'MR' ? '#3b82f6' : ($category === 'ME' ? '#10b981' : ($category === 'GE' ? '#f59e0b' : '#ef4444'));
                        ?>; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.875rem;">
                            <?php echo htmlspecialchars($category); ?>
                        </span>
                    </td>
                    <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                    <td><?php echo $course['credit_hours']; ?></td>
                    <td><?php echo htmlspecialchars($course['teaching_semester'] ?? 'N/A'); ?></td>
                    <td style="font-size: 0.875rem;">
                        <?php 
                        if (isset($schedules[$course['course_code']]) && !empty($schedules[$course['course_code']])) {
                            $scheduleList = [];
                            foreach ($schedules[$course['course_code']] as $schedule) {
                                $dayAbbr = substr($schedule['day_of_week'], 0, 3);
                                $startTime = date('H:i', strtotime($schedule['start_time']));
                                $endTime = date('H:i', strtotime($schedule['end_time']));
                                $scheduleList[] = $dayAbbr . ' ' . $startTime . '-' . $endTime;
                            }
                            echo implode(', ', $scheduleList);
                        } else {
                            echo '<span style="color: #999; font-style: italic;">Not set</span>';
                        }
                        ?>
                    </td>
                    <td><?php echo $course['enrollment_count']; ?></td>
                    <td><?php echo $course['assignment_count']; ?></td>
                    <td>
                        <span class="status-badge <?php echo $course['course_status']; ?>">
                            <?php echo ucfirst($course['course_status']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="instructor_assignments.php?course=<?php echo urlencode($course['course_code']); ?>" class="action-btn">Manage</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Create Course Modal -->
<div id="createModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); align-items: center; justify-content: center; overflow-y: auto;">
    <div class="modal-content" style="background-color: #fefefe; margin: 2rem auto; padding: 2rem; border: 1px solid #888; width: 90%; max-width: 600px; max-height: 90vh; border-radius: 8px; position: relative; overflow-y: auto; overflow-x: hidden;">
        <span class="close" onclick="closeCreateModal()" style="color: #aaa; font-size: 28px; font-weight: bold; cursor: pointer; position: sticky; float: right; right: 0; top: 0; z-index: 10; background: #fefefe; padding: 0.25rem 0.5rem; margin: -1.5rem -1.5rem 0.5rem 0.5rem; border-radius: 4px; line-height: 1;">&times;</span>
        <h2 style="margin-top: 0;">Create Course</h2>
        <form method="POST" id="createCourseForm">
            <input type="hidden" name="action" value="create_course">
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Course Category *</label>
                <select name="course_category" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">-- Select Category --</option>
                    <option value="MR">MR (Major Required)</option>
                    <option value="ME">ME (Major Elective)</option>
                    <option value="GE">GE (General Education)</option>
                    <option value="FE">FE (Free Elective)</option>
                </select>
                <small style="color: #666; font-size: 0.875rem;">Course code will be automatically generated (e.g., MR-001, ME-001)</small>
            </div>
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Course Name *</label>
                <input type="text" name="course_name" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;" placeholder="e.g., Introduction to Computer Science">
            </div>
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Credit Hours *</label>
                <input type="number" name="credit_hours" value="3" min="1" max="6" required style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Semester</label>
                <div style="display: flex; gap: 0.5rem;">
                    <select name="semester_term" style="flex: 1; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- Select Term --</option>
                        <option value="Spring">Spring</option>
                        <option value="Fall">Fall</option>
                    </select>
                    <select name="semester_year" style="flex: 1; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- Select Year --</option>
                        <?php
                        $currentYear = date('Y');
                        for ($year = $currentYear - 2; $year <= $currentYear + 5; $year++):
                        ?>
                        <option value="<?php echo $year; ?>" <?php echo $year == $currentYear ? 'selected' : ''; ?>><?php echo $year; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Description</label>
                <textarea name="course_description" rows="3" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; resize: vertical;"></textarea>
            </div>
            <div class="form-group" style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Course Schedule</label>
                <small style="color: #666; font-size: 0.875rem; display: block; margin-bottom: 0.5rem;">Select time slots for this course. Each slot is 50 minutes with 10-minute breaks.</small>
                <div style="overflow-x: auto; border: 1px solid #ddd; border-radius: 4px; padding: 0.5rem;">
                    <table id="scheduleTable" style="width: 100%; border-collapse: collapse; font-size: 0.875rem;">
                        <thead>
                            <tr>
                                <th style="padding: 0.5rem; text-align: left; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold;">Time</th>
                                <th style="padding: 0.5rem; text-align: center; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold;">Mon</th>
                                <th style="padding: 0.5rem; text-align: center; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold;">Tue</th>
                                <th style="padding: 0.5rem; text-align: center; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold;">Wed</th>
                                <th style="padding: 0.5rem; text-align: center; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold;">Thu</th>
                                <th style="padding: 0.5rem; text-align: center; background: #f3f4f6; border: 1px solid #ddd; font-weight: bold;">Fri</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Generate time slots: 8:00-8:50, 9:00-9:50, ..., 17:00-17:50
                            $timeSlots = [];
                            for ($hour = 8; $hour <= 17; $hour++) {
                                $startTime = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00';
                                $endTime = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':50';
                                $timeSlots[] = [
                                    'start' => $startTime,
                                    'end' => $endTime,
                                    'display' => $startTime . '-' . $endTime
                                ];
                            }
                            $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
                            $dayAbbr = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
                            
                            foreach ($timeSlots as $slot):
                            ?>
                            <tr>
                                <td style="padding: 0.5rem; border: 1px solid #ddd; font-weight: bold; background: #f9fafb;"><?php echo $slot['display']; ?></td>
                                <?php foreach ($days as $index => $day): ?>
                                <td style="padding: 0.5rem; border: 1px solid #ddd; text-align: center;">
                                    <input type="checkbox" 
                                           name="schedule_slots[]" 
                                           value="<?php echo $day . '-' . $slot['start']; ?>"
                                           id="slot_<?php echo strtolower($day) . '_' . str_replace(':', '', $slot['start']); ?>"
                                           style="cursor: pointer; width: 18px; height: 18px;">
                                </td>
                                <?php endforeach; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="form-actions" style="margin-top: 1.5rem; display: flex; gap: 0.5rem;">
                <button type="submit" class="btn-primary" style="padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">Create Course</button>
                <button type="button" class="btn-secondary" onclick="closeCreateModal()" style="padding: 0.5rem 1rem; background: #6b7280; color: white; border: none; border-radius: 4px; cursor: pointer;">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showCreateModal() {
    document.getElementById('createModal').style.display = 'flex';
    // Reset form
    document.getElementById('createCourseForm').reset();
    // Clear all schedule checkboxes
    document.querySelectorAll('input[name="schedule_slots[]"]').forEach(cb => cb.checked = false);
}

function closeCreateModal() {
    document.getElementById('createModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('createModal');
    if (event.target == modal) {
        closeCreateModal();
    }
}

// Make table cells clickable to toggle checkboxes
document.addEventListener('DOMContentLoaded', function() {
    const scheduleTable = document.getElementById('scheduleTable');
    if (scheduleTable) {
        const cells = scheduleTable.querySelectorAll('tbody td');
        cells.forEach(cell => {
            const checkbox = cell.querySelector('input[type="checkbox"]');
            if (checkbox) {
                // Make cell clickable
                cell.style.cursor = 'pointer';
                cell.addEventListener('click', function(e) {
                    if (e.target !== checkbox) {
                        checkbox.checked = !checkbox.checked;
                        // Update cell background color
                        updateCellStyle(cell, checkbox.checked);
                    }
                });
                
                // Update cell style on checkbox change
                checkbox.addEventListener('change', function() {
                    updateCellStyle(cell, checkbox.checked);
                });
                
                // Initial style
                updateCellStyle(cell, checkbox.checked);
            }
        });
    }
});

function updateCellStyle(cell, isChecked) {
    if (isChecked) {
        cell.style.background = '#dbeafe';
        cell.style.borderColor = '#3b82f6';
    } else {
        cell.style.background = '';
        cell.style.borderColor = '#ddd';
    }
}
</script>

<style>
#scheduleTable tbody td:hover {
    background-color: #f0f9ff !important;
}

#scheduleTable tbody td input[type="checkbox"]:checked + label,
#scheduleTable tbody td:has(input[type="checkbox"]:checked) {
    background-color: #dbeafe !important;
}
</style>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


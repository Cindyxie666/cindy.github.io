<?php
/**
 * 生成分页HTML
 * @param int $currentPage 当前页码
 * @param int $totalPages 总页数
 * @param string $baseUrl 基础URL
 * @param array $extraParams 额外的URL参数
 * @param string $pageParam 页码参数名
 * @return string HTML
 */
function renderPagination($currentPage, $totalPages, $baseUrl = '', $extraParams = [], $pageParam = 'page') {
    if ($totalPages <= 1) return '';
    
    $html = '<div class="pagination" style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">';
    
    // Previous button
    if ($currentPage > 1) {
        $prevParams = array_merge($extraParams, [$pageParam => $currentPage - 1]);
        $prevUrl = $baseUrl . '?' . http_build_query($prevParams);
        $html .= '<a href="' . htmlspecialchars($prevUrl) . '" class="btn-secondary" style="padding: 0.5rem 1rem;">← Previous</a>';
    }
    
    // Page info
    $html .= '<span style="padding: 0.5rem 1rem; color: #666;">Page ' . $currentPage . ' of ' . $totalPages . '</span>';
    
    // Next button
    if ($currentPage < $totalPages) {
        $nextParams = array_merge($extraParams, [$pageParam => $currentPage + 1]);
        $nextUrl = $baseUrl . '?' . http_build_query($nextParams);
        $html .= '<a href="' . htmlspecialchars($nextUrl) . '" class="btn-secondary" style="padding: 0.5rem 1rem;">Next →</a>';
    }
    
    $html .= '</div>';
    
    return $html;
}
?>

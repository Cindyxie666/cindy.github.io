<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$userType = getUserType();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' : ''; ?>Course Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/components.css">
</head>
<body>
    <div class="layout">
        <?php if (isCourseLoggedIn()): ?>
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>📚 CMS</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="course_index.php" class="nav-item <?php echo $currentPage === 'course_index.php' ? 'active' : ''; ?>">
                    <span>📊</span> Dashboard
                </a>
                
                <?php if ($userType === 'student'): ?>
                <a href="student_enroll.php" class="nav-item <?php echo strpos($currentPage, 'student_enroll') !== false ? 'active' : ''; ?>">
                    <span>📝</span> Course Enrollment
                </a>
                <a href="student_courses.php" class="nav-item <?php echo strpos($currentPage, 'student_courses') !== false ? 'active' : ''; ?>">
                    <span>📚</span> My Courses
                </a>
                <a href="student_assignments.php" class="nav-item <?php echo strpos($currentPage, 'student_assignments') !== false ? 'active' : ''; ?>">
                    <span>📝</span> Assignments
                </a>
                <a href="student_grades.php" class="nav-item <?php echo strpos($currentPage, 'student_grades') !== false ? 'active' : ''; ?>">
                    <span>📊</span> Grades
                </a>
                <a href="student_appeals.php" class="nav-item <?php echo strpos($currentPage, 'student_appeals') !== false ? 'active' : ''; ?>">
                    <span>⚖️</span> Appeals
                </a>
                <a href="student_announcements.php" class="nav-item <?php echo strpos($currentPage, 'student_announcements') !== false ? 'active' : ''; ?>">
                    <span>📢</span> Announcements
                </a>
                <a href="student_textbooks.php" class="nav-item <?php echo strpos($currentPage, 'student_textbooks') !== false ? 'active' : ''; ?>">
                    <span>📖</span> Textbooks
                </a>
                <!-- 在 student_textbooks 链接后面添加 -->
                <a href="student_notifications.php" class="nav-item <?php echo strpos($currentPage, 'student_notifications') !== false ? 'active' : ''; ?>">
                     <span>🔔</span> Notifications
                </a>
                <!-- 在 student_notifications 链接后面添加 -->
                 <a href="student_evaluations.php" class="nav-item <?php echo strpos($currentPage, 'student_evaluations') !== false ? 'active' : ''; ?>">
                       <span>⭐</span> Evaluations
                 </a>


                <a href="student_profile.php" class="nav-item <?php echo strpos($currentPage, 'student_profile') !== false ? 'active' : ''; ?>">
                    <span>👤</span> Profile
                </a>
                <a href="course_schedule.php" class="nav-item <?php echo strpos($currentPage, 'course_schedule') !== false ? 'active' : ''; ?>">
                    <span>📅</span> Schedule
                </a>
                
                <?php elseif ($userType === 'instructor'): ?>
                <a href="instructor_courses.php" class="nav-item <?php echo strpos($currentPage, 'instructor_courses') !== false ? 'active' : ''; ?>">
                    <span>📚</span> Courses
                </a>
                <a href="instructor_assignments.php" class="nav-item <?php echo strpos($currentPage, 'instructor_assignments') !== false ? 'active' : ''; ?>">
                    <span>📝</span> Assignments
                </a>
                <a href="instructor_grading.php" class="nav-item <?php echo strpos($currentPage, 'instructor_grading') !== false ? 'active' : ''; ?>">
                    <span>✓</span> Grading
                </a>
                <a href="instructor_appeals.php" class="nav-item <?php echo strpos($currentPage, 'instructor_appeals') !== false ? 'active' : ''; ?>">
                    <span>⚖️</span> Appeals
                </a>
                <a href="instructor_announcements.php" class="nav-item <?php echo strpos($currentPage, 'instructor_announcements') !== false ? 'active' : ''; ?>">
                    <span>📢</span> Announcements
                </a>
                <a href="instructor_profile.php" class="nav-item <?php echo strpos($currentPage, 'instructor_profile') !== false ? 'active' : ''; ?>">
                    <span>👤</span> Profile
                </a>
                <a href="course_schedule.php" class="nav-item <?php echo strpos($currentPage, 'course_schedule') !== false ? 'active' : ''; ?>">
                    <span>📅</span> Schedule
                </a>
                
                <?php elseif ($userType === 'administrator'): ?>
                <a href="admin_accounts.php" class="nav-item <?php echo strpos($currentPage, 'admin_accounts') !== false ? 'active' : ''; ?>">
                    <span>👥</span> Accounts
                </a>
                <a href="admin_courses.php" class="nav-item <?php echo strpos($currentPage, 'admin_courses') !== false ? 'active' : ''; ?>">
                    <span>📚</span> Courses
                </a>
                <a href="admin_evaluations.php" class="nav-item <?php echo strpos($currentPage, 'admin_evaluations') !== false ? 'active' : ''; ?>">
                    <span>📊</span> Evaluations
                </a>
                <a href="admin_bookstore.php" class="nav-item <?php echo strpos($currentPage, 'admin_bookstore') !== false ? 'active' : ''; ?>">
                    <span>🏪</span> Bookstore
                </a>
                <a href="admin_profile.php" class="nav-item <?php echo strpos($currentPage, 'admin_profile') !== false ? 'active' : ''; ?>">
                    <span>👤</span> Profile
                </a>
                <?php endif; ?>
            </nav>
            <div class="sidebar-footer">
                <a href="course_logout.php" class="logout-btn">
                    <span>🚪</span> Logout
                </a>
            </div>
        </aside>
        <?php endif; ?>
        
        <main class="main-content">
            <?php if (isCourseLoggedIn()): ?>
            <header class="topbar">
                <h1>Course Management System</h1>
                <div class="user-info" style="display: flex; align-items: center; gap: 0.75rem;">
                    <img src="view_avatar.php?type=<?php echo $userType; ?>&id=<?php echo getCurrentUserId(); ?>" 
                         alt="Avatar" 
                         style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid #3b82f6;"
                         onerror="this.style.display='none'">
                    <span><?php echo htmlspecialchars($_SESSION['username']); ?> (<?php echo ucfirst($userType); ?>)</span>
                </div>
            </header>
            <?php endif; ?>
            
            <div class="content-wrapper">


<?php
// Course Management System Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'course_management_system');

// Create connection
function getCourseDBConnection() {
    // 修复：Windows 不需要 socket
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// 其余代码保持不变...
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isCourseLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_type']);
}

function getUserType() {
    return $_SESSION['user_type'] ?? null;
}

function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

function isStudent() {
    return getUserType() === 'student';
}

function isInstructor() {
    return getUserType() === 'instructor';
}

function isAdministrator() {
    return getUserType() === 'administrator';
}

function requireCourseLogin() {
    if (!isCourseLoggedIn()) {
        header('Location: course_login.php');
        exit();
    }
}

function requireStudent() {
    requireCourseLogin();
    if (!isStudent()) {
        header('Location: course_index.php');
        exit();
    }
}

function requireInstructor() {
    requireCourseLogin();
    if (!isInstructor()) {
        header('Location: course_index.php');
        exit();
    }
}

function requireAdministrator() {
    requireCourseLogin();
    if (!isAdministrator()) {
        header('Location: course_index.php');
        exit();
    }
}

function courseLogout() {
    session_unset();
    session_destroy();
    header('Location: course_login.php');
    exit();
}

function isEnrollmentEnabled($conn = null) {
    if ($conn === null) {
        $conn = getCourseDBConnection();
        $closeConn = true;
    } else {
        $closeConn = false;
    }
    
    $stmt = $conn->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'enrollment_enabled'");
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($closeConn) {
        $conn->close();
    }
    
    return $result ? ($result['setting_value'] == '1') : true;
}
?>

<?php
require_once __DIR__ . '/config/course_database.php';
requireAdministrator();

$pageTitle = 'Teaching Evaluations';
include __DIR__ . '/includes/course_header.php';

$conn = getCourseDBConnection();
$adminId = getCurrentUserId();

// Handle release evaluation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'release') {
    $evaluationId = $_POST['evaluation_id'] ?? 0;
    $collectionDeadline = $_POST['collection_deadline'] ?? '';
    
    if ($evaluationId && $collectionDeadline) {
        $stmt = $conn->prepare("INSERT INTO evaluation_releases (admin_id, evaluation_id, release_time, collection_deadline) VALUES (?, ?, NOW(), ?)");
        $stmt->bind_param("iis", $adminId, $evaluationId, $collectionDeadline);
        $stmt->execute();
        $stmt->close();
        
        // Redirect to preserve filters
        $redirectParams = [];
        if (!empty($_GET['search'])) $redirectParams['search'] = $_GET['search'];
        if (!empty($_GET['filter_rating'])) $redirectParams['filter_rating'] = $_GET['filter_rating'];
        if (!empty($_GET['filter_status'])) $redirectParams['filter_status'] = $_GET['filter_status'];
        if (!empty($_GET['filter_course'])) $redirectParams['filter_course'] = $_GET['filter_course'];
        if (!empty($_GET['filter_instructor'])) $redirectParams['filter_instructor'] = $_GET['filter_instructor'];
        if (!empty($_GET['page'])) $redirectParams['page'] = $_GET['page'];
        $redirectParams['message'] = 'released';
        header('Location: admin_evaluations.php?' . http_build_query($redirectParams));
        exit();
    }
}

// Handle redirect messages
$message = '';
$messageType = '';
if (isset($_GET['message']) && $_GET['message'] === 'released') {
    $message = "Evaluation released successfully!";
    $messageType = "success";
}

// Get filter and search parameters
$search = $_GET['search'] ?? '';
$filterRating = $_GET['filter_rating'] ?? '';
$filterStatus = $_GET['filter_status'] ?? '';
$filterCourse = $_GET['filter_course'] ?? '';
$filterInstructor = $_GET['filter_instructor'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build WHERE conditions
$where = [];
$params = [];
$types = '';

if ($search) {
    $where[] = "(s.name LIKE ? OR c.course_name LIKE ? OR i.name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types .= "sss";
}

if ($filterRating) {
    $where[] = "e.rating = ?";
    $params[] = $filterRating;
    $types .= "i";
}

if ($filterStatus === 'released') {
    $where[] = "(SELECT COUNT(*) FROM evaluation_releases WHERE evaluation_id = e.evaluation_id) > 0";
} elseif ($filterStatus === 'not_released') {
    $where[] = "(SELECT COUNT(*) FROM evaluation_releases WHERE evaluation_id = e.evaluation_id) = 0";
}

if ($filterCourse) {
    $where[] = "e.course_code = ?";
    $params[] = $filterCourse;
    $types .= "s";
}

if ($filterInstructor) {
    $where[] = "e.instructor_id = ?";
    $params[] = $filterInstructor;
    $types .= "i";
}

$whereClause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

// Get total count for pagination
$countQuery = "SELECT COUNT(*) as total 
               FROM teaching_evaluations e
               JOIN students s ON e.student_id = s.student_id
               JOIN courses c ON e.course_code = c.course_code
               JOIN instructors i ON e.instructor_id = i.instructor_id
               $whereClause";

if (!empty($params)) {
    $countStmt = $conn->prepare($countQuery);
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $totalCount = $countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
} else {
    $totalCount = $conn->query($countQuery)->fetch_assoc()['total'];
}

$totalPages = ceil($totalCount / $perPage);

// Get teaching evaluations with pagination
$evaluationsQuery = "SELECT e.*, s.name as student_name, c.course_name, i.name as instructor_name,
                     (SELECT COUNT(*) FROM evaluation_releases WHERE evaluation_id = e.evaluation_id) as released
                     FROM teaching_evaluations e
                     JOIN students s ON e.student_id = s.student_id
                     JOIN courses c ON e.course_code = c.course_code
                     JOIN instructors i ON e.instructor_id = i.instructor_id
                     $whereClause
                     ORDER BY e.evaluation_time DESC
                     LIMIT ? OFFSET ?";

if (!empty($params)) {
    $evaluationsStmt = $conn->prepare($evaluationsQuery);
    $params[] = $perPage;
    $params[] = $offset;
    $types .= "ii";
    $evaluationsStmt->bind_param($types, ...$params);
    $evaluationsStmt->execute();
    $evaluations = $evaluationsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $evaluationsStmt->close();
} else {
    $evaluations = $conn->query("SELECT e.*, s.name as student_name, c.course_name, i.name as instructor_name,
                                (SELECT COUNT(*) FROM evaluation_releases WHERE evaluation_id = e.evaluation_id) as released
                                FROM teaching_evaluations e
                                JOIN students s ON e.student_id = s.student_id
                                JOIN courses c ON e.course_code = c.course_code
                                JOIN instructors i ON e.instructor_id = i.instructor_id
                                $whereClause
                                ORDER BY e.evaluation_time DESC
                                LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);
}

// Get unique values for filter dropdowns
$courses = $conn->query("SELECT DISTINCT c.course_code, c.course_name FROM courses c 
                        JOIN teaching_evaluations e ON c.course_code = e.course_code 
                        ORDER BY c.course_name")->fetch_all(MYSQLI_ASSOC);
$instructors = $conn->query("SELECT DISTINCT i.instructor_id, i.name FROM instructors i 
                            JOIN teaching_evaluations e ON i.instructor_id = e.instructor_id 
                            ORDER BY i.name")->fetch_all(MYSQLI_ASSOC);

// Get evaluation statistics (with filters applied)
// Build stats params separately (without LIMIT/OFFSET)
$statsParams = [];
$statsTypes = '';

if ($search) {
    $statsParams[] = "%$search%";
    $statsParams[] = "%$search%";
    $statsParams[] = "%$search%";
    $statsTypes .= "sss";
}

if ($filterRating) {
    $statsParams[] = $filterRating;
    $statsTypes .= "i";
}

if ($filterCourse) {
    $statsParams[] = $filterCourse;
    $statsTypes .= "s";
}

if ($filterInstructor) {
    $statsParams[] = $filterInstructor;
    $statsTypes .= "i";
}

$statsQuery = "SELECT 
                AVG(e.rating) as avg_rating,
                COUNT(*) as total_evaluations,
                COUNT(DISTINCT e.instructor_id) as instructors_evaluated,
                COUNT(DISTINCT e.course_code) as courses_evaluated
                FROM teaching_evaluations e
                JOIN students s ON e.student_id = s.student_id
                JOIN courses c ON e.course_code = c.course_code
                JOIN instructors i ON e.instructor_id = i.instructor_id
                $whereClause";

if (!empty($statsParams)) {
    $statsStmt = $conn->prepare($statsQuery);
    $statsStmt->bind_param($statsTypes, ...$statsParams);
    $statsStmt->execute();
    $stats = $statsStmt->get_result()->fetch_assoc();
    $statsStmt->close();
} else {
    $stats = $conn->query($statsQuery)->fetch_assoc();
}

$conn->close();
?>

<div class="table-list">
    <div class="page-header">
        <div>
            <h2>📊 Teaching Evaluations</h2>
            <p>Release evaluation surveys and collect responses</p>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: #3b82f6;">⭐</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['avg_rating'], 2); ?></div>
                <div class="stat-label">Average Rating</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">📝</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['total_evaluations']); ?></div>
                <div class="stat-label">Total Evaluations</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(139, 92, 246, 0.1); color: #8b5cf6;">👨‍🏫</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['instructors_evaluated']); ?></div>
                <div class="stat-label">Instructors Evaluated</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: #f59e0b;">📚</div>
            <div class="stat-content">
                <div class="stat-value"><?php echo number_format($stats['courses_evaluated']); ?></div>
                <div class="stat-label">Courses Evaluated</div>
            </div>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin: 1rem 0; padding: 1rem; border-radius: 4px; background: <?php echo $messageType === 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $messageType === 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Search and Filter Form -->
    <div style="background: white; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <form method="GET" action="admin_evaluations.php" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; align-items: end;">
            <!-- Search -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Search (Student/Course/Instructor)</label>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Enter name..." style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <!-- Filter Rating -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Rating</label>
                <select name="filter_rating" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <option value="5" <?php echo $filterRating === '5' ? 'selected' : ''; ?>>5 Stars</option>
                    <option value="4" <?php echo $filterRating === '4' ? 'selected' : ''; ?>>4 Stars</option>
                    <option value="3" <?php echo $filterRating === '3' ? 'selected' : ''; ?>>3 Stars</option>
                    <option value="2" <?php echo $filterRating === '2' ? 'selected' : ''; ?>>2 Stars</option>
                    <option value="1" <?php echo $filterRating === '1' ? 'selected' : ''; ?>>1 Star</option>
                </select>
            </div>
            
            <!-- Filter Status -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Status</label>
                <select name="filter_status" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <option value="released" <?php echo $filterStatus === 'released' ? 'selected' : ''; ?>>Released</option>
                    <option value="not_released" <?php echo $filterStatus === 'not_released' ? 'selected' : ''; ?>>Not Released</option>
                </select>
            </div>
            
            <!-- Filter Course -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Course</label>
                <select name="filter_course" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?php echo htmlspecialchars($course['course_code']); ?>" <?php echo $filterCourse === $course['course_code'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($course['course_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Filter Instructor -->
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold; color: #333;">Instructor</label>
                <select name="filter_instructor" style="width: 100%; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">All</option>
                    <?php foreach ($instructors as $instructor): ?>
                        <option value="<?php echo $instructor['instructor_id']; ?>" <?php echo $filterInstructor == $instructor['instructor_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($instructor['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Buttons -->
            <div style="display: flex; gap: 0.5rem;">
                <button type="submit" style="padding: 0.5rem 1.5rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">Search</button>
                <a href="admin_evaluations.php" style="padding: 0.5rem 1.5rem; background: #6b7280; color: white; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; text-align: center; font-weight: bold;">Reset</a>
            </div>
        </form>
    </div>

    <!-- Results Info -->
    <div style="margin-bottom: 1rem; color: #666; font-size: 0.9rem;">
        Found <strong><?php echo $totalCount; ?></strong> evaluation(s), showing <strong><?php echo min($offset + 1, $totalCount); ?></strong> - <strong><?php echo min($offset + count($evaluations), $totalCount); ?></strong>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Course</th>
                    <th>Instructor</th>
                    <th>Rating</th>
                    <th>Evaluation Content</th>
                    <th>Evaluation Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($evaluations as $evaluation): ?>
                <tr>
                    <td><?php echo htmlspecialchars($evaluation['student_name']); ?></td>
                    <td><?php echo htmlspecialchars($evaluation['course_name']); ?></td>
                    <td><?php echo htmlspecialchars($evaluation['instructor_name']); ?></td>
                    <td>
                        <span class="rating-badge">
                            <?php echo str_repeat('⭐', $evaluation['rating']); ?> (<?php echo $evaluation['rating']; ?>/5)
                        </span>
                    </td>
                    <td><?php echo htmlspecialchars(substr($evaluation['evaluation_content'], 0, 50)); ?>...</td>
                    <td><?php echo date('Y-m-d H:i', strtotime($evaluation['evaluation_time'])); ?></td>
                    <td>
                        <?php if ($evaluation['released'] > 0): ?>
                        <span class="status-badge completed">Released</span>
                        <?php else: ?>
                        <span class="status-badge pending">Not Released</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($evaluations)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 2rem; color: #999;">
                        No matching evaluations found
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div style="margin-top: 2rem; display: flex; justify-content: center; align-items: center; gap: 0.5rem;">
        <?php
        // Build query string for pagination links
        $queryParams = [];
        if ($search) $queryParams['search'] = $search;
        if ($filterRating) $queryParams['filter_rating'] = $filterRating;
        if ($filterStatus) $queryParams['filter_status'] = $filterStatus;
        if ($filterCourse) $queryParams['filter_course'] = $filterCourse;
        if ($filterInstructor) $queryParams['filter_instructor'] = $filterInstructor;
        $queryString = !empty($queryParams) ? '&' . http_build_query($queryParams) : '';
        ?>
        
        <!-- First Page -->
        <?php if ($page > 1): ?>
            <a href="admin_evaluations.php?page=1<?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">First</a>
        <?php endif; ?>
        
        <!-- Previous Page -->
        <?php if ($page > 1): ?>
            <a href="admin_evaluations.php?page=<?php echo $page - 1; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Previous</a>
        <?php endif; ?>
        
        <!-- Page Numbers -->
        <?php
        $startPage = max(1, $page - 2);
        $endPage = min($totalPages, $page + 2);
        
        for ($i = $startPage; $i <= $endPage; $i++):
        ?>
            <a href="admin_evaluations.php?page=<?php echo $i; ?><?php echo $queryString; ?>" 
               style="padding: 0.5rem 1rem; background: <?php echo $i === $page ? '#3b82f6' : 'white'; ?>; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: <?php echo $i === $page ? 'white' : '#333'; ?>; font-weight: <?php echo $i === $page ? 'bold' : 'normal'; ?>;">
                <?php echo $i; ?>
            </a>
        <?php endfor; ?>
        
        <!-- Next Page -->
        <?php if ($page < $totalPages): ?>
            <a href="admin_evaluations.php?page=<?php echo $page + 1; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Next</a>
        <?php endif; ?>
        
        <!-- Last Page -->
        <?php if ($page < $totalPages): ?>
            <a href="admin_evaluations.php?page=<?php echo $totalPages; ?><?php echo $queryString; ?>" style="padding: 0.5rem 1rem; background: white; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #333;">Last</a>
        <?php endif; ?>
        
        <span style="margin-left: 1rem; color: #666;">
            Page <?php echo $page; ?> / <?php echo $totalPages; ?>
        </span>
        
        <!-- Jump to Page -->
        <div style="margin-left: 1rem; display: flex; align-items: center; gap: 0.5rem;">
            <span style="color: #666; font-size: 0.875rem;">Go to:</span>
            <input type="number" id="jumpPage" min="1" max="<?php echo $totalPages; ?>" value="<?php echo $page; ?>" style="width: 60px; padding: 0.25rem 0.5rem; border: 1px solid #ddd; border-radius: 4px; font-size: 0.875rem;">
            <button onclick="jumpToPage('admin_evaluations.php', <?php echo $totalPages; ?>, '<?php echo htmlspecialchars($queryString, ENT_QUOTES); ?>')" style="padding: 0.25rem 0.75rem; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 0.875rem;">Go</button>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.rating-badge {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    background: rgba(245, 158, 11, 0.1);
    color: var(--warning);
    border-radius: 0.375rem;
    font-weight: 500;
}
</style>

<script>
function jumpToPage(baseUrl, maxPages, queryString) {
    const pageInput = document.getElementById('jumpPage');
    const page = parseInt(pageInput.value);
    if (page >= 1 && page <= maxPages) {
        window.location.href = baseUrl + '?page=' + page + queryString;
    } else {
        alert('Please enter a valid page number between 1 and ' + maxPages);
        pageInput.focus();
    }
}
</script>

<?php include __DIR__ . '/includes/course_footer.php'; ?>


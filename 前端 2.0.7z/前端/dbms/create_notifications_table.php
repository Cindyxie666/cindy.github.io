<?php
require_once __DIR__ . '/config/course_database.php';

$conn = getCourseDBConnection();

$sql = "
CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    notification_content TEXT NOT NULL,
    notification_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read TINYINT(1) DEFAULT 0,
    student_id INT NOT NULL,
    instructor_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE SET NULL,
    INDEX idx_student (student_id),
    INDEX idx_read (is_read),
    INDEX idx_time (notification_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if ($conn->query($sql)) {
    echo "<h2 style='color:green;'>✅ notifications 表创建成功！</h2>";
    
    // 插入测试数据
    $testSql = "
    INSERT INTO notifications (notification_content, notification_time, is_read, student_id, instructor_id) 
    SELECT 
        CONCAT('Welcome to the course management system, ', s.name, '!'),
        NOW(),
        0,
        s.student_id,
        NULL
    FROM students s
    WHERE s.student_id NOT IN (SELECT student_id FROM notifications)
    LIMIT 10
    ";
    
    if ($conn->query($testSql)) {
        echo "<p>✅ 测试通知数据已插入</p>";
    }
    
    echo "<p><a href='student_notifications.php'>→ 前往通知页面</a></p>";
} else {
    echo "<h2 style='color:red;'>❌ 创建失败: " . $conn->error . "</h2>";
}

$conn->close();
?>
